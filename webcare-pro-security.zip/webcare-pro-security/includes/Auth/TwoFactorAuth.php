<?php
namespace WebCareProScanner\Auth;

use WebCareProScanner\System\SettingsManager;
use WebCareProScanner\Security\SecretVault;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Two-Factor Authentication (2FA) Service
 *
 * Implements RFC 6238 TOTP (Time-based One-Time Password) algorithm in pure PHP.
 * Supports Google Authenticator, Authy, 1Password, Microsoft Authenticator.
 */
class TwoFactorAuth {

    const META_ENABLED         = '_webcareproscan_2fa_enabled';
    const META_SECRET          = '_webcareproscan_2fa_secret';
    const META_ALGORITHM       = '_webcareproscan_2fa_algorithm';
    const META_DIGITS          = '_webcareproscan_2fa_digits';
    const META_BACKUP_CODES    = '_webcareproscan_2fa_backup_codes';
    const META_TRUSTED_DEVICES = '_webcareproscan_2fa_trusted_devices';
    const META_GRACE_START     = '_webcareproscan_2fa_grace_start';
    const SESSION_TRANSIENT    = 'webcareproscan_2fa_pending_';
    const COOKIE_DEVICE        = 'webcareproscan_2fa_trusted_device';

    /**
     * Initialize 2FA hooks
     */
    public static function init() {
        // Intercept WordPress authentication
        add_filter('authenticate', [__CLASS__, 'filter_authenticate'], 50, 3);
        add_action('login_form_webcareproscan_2fa', [__CLASS__, 'render_2fa_challenge_screen']);
        // Revoke trusted devices on password reset for security
        add_action('password_reset', [__CLASS__, 'on_password_reset'], 10, 2);
        // Intercept admin dashboard if 2FA is strictly enforced and user grace period expired
        add_action('admin_init', [__CLASS__, 'enforce_admin_dashboard_access']);
        add_filter('rest_pre_dispatch', [__CLASS__, 'enforce_rest_2fa_onboarding'], 10, 3);
        // Display admin notice during grace period
        add_action('admin_notices', [__CLASS__, 'render_enforcement_grace_notice']);
    }

    /**
     * Check if 2FA is globally enabled in settings
     */
    public static function is_globally_enabled(): bool {
        $settings = SettingsManager::get_settings();
        return !empty($settings['auth_2fa_enabled']);
    }

    /**
     * Check if 2FA is enforced for administrators
     */
    public static function is_enforced_for_admins(): bool {
        if (!self::is_globally_enabled()) {
            return false;
        }
        $settings = SettingsManager::get_settings();
        return !empty($settings['auth_2fa_enforce_admins']);
    }

    /**
     * Get 2FA enforcement policy mode ('immediate' | 'grace_period' | 'remind_login')
     */
    public static function get_enforcement_policy_mode(): string {
        $settings = SettingsManager::get_settings();
        $mode = $settings['auth_2fa_policy_mode'] ?? 'remind_login';
        return in_array($mode, ['immediate', 'grace_period', 'remind_login'], true) ? $mode : 'remind_login';
    }

    /**
     * Get 2FA grace period in days (0 = immediate)
     */
    public static function get_enforcement_grace_days(): int {
        $settings = SettingsManager::get_settings();
        return max(0, min(90, (int) ($settings['auth_2fa_grace_days'] ?? 0)));
    }

    /**
     * Check compliance status for a specific user
     * Returns: 'compliant' | 'grace_period' | 'remind_login' | 'enforcement_required' | 'not_enforced'
     */
    public static function get_user_compliance_status(int $user_id): array {
        $is_enabled = self::is_user_enabled($user_id);
        if ($is_enabled) {
            return [
                'status'         => 'compliant',
                'label'          => __('2FA Active & Compliant', 'webcare-pro-security'),
                'is_compliant'   => true,
                'grace_remaining'=> 0,
                'days_left'      => 0,
            ];
        }

        if (!self::is_enforced_for_admins()) {
            return [
                'status'         => 'not_enforced',
                'label'          => __('2FA Optional / Disabled', 'webcare-pro-security'),
                'is_compliant'   => false,
                'grace_remaining'=> 0,
                'days_left'      => 0,
            ];
        }

        $user = get_user_by('id', $user_id);
        if (!$user || !in_array('administrator', (array) $user->roles, true)) {
            return [
                'status'         => 'not_enforced',
                'label'          => __('Non-Admin (Exempt)', 'webcare-pro-security'),
                'is_compliant'   => true,
                'grace_remaining'=> 0,
                'days_left'      => 0,
            ];
        }

        $mode       = self::get_enforcement_policy_mode();
        $grace_days = self::get_enforcement_grace_days();

        // 1. Immediate Enforcement
        if ($mode === 'immediate' || ($mode === 'grace_period' && $grace_days <= 0)) {
            return [
                'status'         => 'enforcement_required',
                'label'          => __('Enforced Immediately (Action Required)', 'webcare-pro-security'),
                'is_compliant'   => false,
                'grace_remaining'=> 0,
                'days_left'      => 0,
                'mode'           => 'immediate',
            ];
        }

        // 2. Check user grace start
        $grace_start = (int) get_user_meta($user_id, self::META_GRACE_START, true);
        if ($grace_start <= 0) {
            $settings = SettingsManager::get_settings();
            $grace_start = !empty($settings['auth_2fa_enforce_since']) ? (int) $settings['auth_2fa_enforce_since'] : time();
            update_user_meta($user_id, self::META_GRACE_START, $grace_start);
        }

        $grace_expires = $grace_start + ($grace_days * DAY_IN_SECONDS);
        $now = time();

        if ($now >= $grace_expires) {
            return [
                'status'         => 'enforcement_required',
                'label'          => __('Grace Period Expired (Locked)', 'webcare-pro-security'),
                'is_compliant'   => false,
                'grace_remaining'=> 0,
                'days_left'      => 0,
                'mode'           => $mode,
            ];
        }

        $seconds_left = $grace_expires - $now;
        $days_left    = max(1, (int) ceil($seconds_left / DAY_IN_SECONDS));

        // 3. Remind on Next Login (with Grace Period)
        if ($mode === 'remind_login') {
            return [
                'status'         => 'remind_login',
                'label'          => sprintf(
                    /* translators: %d: count of remaining grace period days */
                    __('Remind on Login (%dd grace left)', 'webcare-pro-security'),
                    $days_left
                ),
                'is_compliant'   => false,
                'grace_remaining'=> $seconds_left,
                'days_left'      => $days_left,
                'expires_at'     => $grace_expires,
                'mode'           => 'remind_login',
            ];
        }

        // 4. Standard Grace Period
        return [
            'status'         => 'grace_period',
            'label'          => sprintf(
                /* translators: %d: count of remaining grace period days */
                __('Grace Period: %d day(s) left', 'webcare-pro-security'),
                $days_left
            ),
            'is_compliant'   => false,
            'grace_remaining'=> $seconds_left,
            'days_left'      => $days_left,
            'expires_at'     => $grace_expires,
            'mode'           => 'grace_period',
        ];
    }

    /**
     * Determine whether an authenticated administrator must complete 2FA onboarding before
     * accessing dashboard screens, admin-ajax actions, or administrative REST API routes.
     */
    public static function needs_forced_2fa_onboarding(int $user_id): bool {
        if ($user_id <= 0 || !user_can($user_id, 'administrator')) {
            return false;
        }
        if (self::is_user_enabled($user_id)) {
            return false;
        }
        if (!empty(get_user_meta($user_id, 'webcareproscan_force_2fa_setup', true))) {
            return true;
        }
        if (!self::is_enforced_for_admins()) {
            return false;
        }
        $compliance = self::get_user_compliance_status($user_id);
        return ($compliance['status'] ?? '') === 'enforcement_required';
    }

    /**
     * Enforce admin dashboard and admin-ajax access for administrators requiring forced 2FA onboarding.
     */
    public static function enforce_admin_dashboard_access() {
        $user_id = get_current_user_id();
        if (!self::needs_forced_2fa_onboarding($user_id)) {
            return;
        }

        if (wp_doing_ajax()) {
            // phpcs:ignore WordPress.Security.NonceVerification.Recommended
            $ajax_action = isset($_REQUEST['action']) ? sanitize_key(wp_unslash($_REQUEST['action'])) : '';
            $allowed_ajax = ['heartbeat', 'wp-remove-post-lock'];
            if (in_array($ajax_action, $allowed_ajax, true) || str_starts_with($ajax_action, 'webcareproscan_2fa_')) {
                return;
            }
            wp_send_json_error(
                ['message' => __('Two-Factor Authentication setup is required before performing administrative actions.', 'webcare-pro-security')],
                403
            );
        }

        if (defined('REST_REQUEST') && REST_REQUEST) {
            return;
        }

        // Allow access ONLY to the 2FA configuration page
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        $current_page = isset($_GET['page']) ? sanitize_text_field(wp_unslash($_GET['page'])) : '';
        $is_auth_page = ($current_page === 'webcare-pro-login') || ($current_page === 'webcare-pro-auth');
        if (!$is_auth_page) {
            wp_safe_redirect(\WebCareProScanner\Admin\RouteRegistry::url('webcare-pro-login', '2fa', '', ['forced' => '1']));
            exit;
        }
    }

    /**
     * Block un-enrolled administrators requiring forced 2FA onboarding from invoking
     * non-2FA REST endpoints (including core /wp/v2/users and /settings).
     */
    public static function enforce_rest_2fa_onboarding($result, $server, $request) {
        if ($result !== null) {
            return $result;
        }

        $user_id = get_current_user_id();
        if (!self::needs_forced_2fa_onboarding($user_id)) {
            return $result;
        }

        $route = ($request instanceof \WP_REST_Request) ? (string) $request->get_route() : '';
        $allowed_prefixes = [
            '/webcare-pro-security/v1/auth/2fa',
            '/webcare-pro-security/v1/auth/status',
            '/webcare-pro-security/v1/auth/webauthn',
        ];
        foreach ($allowed_prefixes as $prefix) {
            if ($route === $prefix || str_starts_with($route, $prefix . '/')) {
                return $result;
            }
        }

        return new \WP_Error(
            'webcare_2fa_onboarding_required',
            __('Two-Factor Authentication enrollment is required before accessing administrative REST endpoints.', 'webcare-pro-security'),
            ['status' => 403]
        );
    }

    /**
     * Render Grace Period Warning Notice in WP Admin Header
     */
    public static function render_enforcement_grace_notice() {
        $user_id = get_current_user_id();
        if (!$user_id || !current_user_can('administrator')) {
            return;
        }

        if (self::is_user_enabled($user_id) || !self::is_enforced_for_admins()) {
            return;
        }

        $compliance = self::get_user_compliance_status($user_id);
        if ($compliance['status'] === 'remind_login') {
            $days_left = $compliance['days_left'] ?? 1;
            $setup_url = \WebCareProScanner\Admin\RouteRegistry::url('webcare-pro-login', '2fa', '', ['setup' => '1']);
            ?>
            <div class="notice notice-info is-dismissible" style="border-left-color: #0284c7; padding: 12px 16px;">
                <p style="margin: 0; font-size: 13.5px; font-weight: 500; color: #1e293b;">
                    <strong style="color: #0284c7;">🔔 <?php esc_html_e('Security Reminder: Configure Administrator 2FA', 'webcare-pro-security'); ?></strong> —
                    <?php
                    /* translators: %d: count of remaining days */
                    printf(esc_html__('Two-factor authentication is recommended for your account. You have %d day(s) before enforcement is finalized.', 'webcare-pro-security'), (int) $days_left);
                    ?>
                    <a href="<?php echo esc_url($setup_url); ?>" class="button button-primary" style="margin-left: 10px; background: #0284c7; border-color: #0284c7; font-weight: 600;">
                        <?php esc_html_e('Configure 2FA', 'webcare-pro-security'); ?> &rarr;
                    </a>
                </p>
            </div>
            <?php
        } elseif ($compliance['status'] === 'grace_period') {
            $days_left = $compliance['days_left'] ?? 1;
            $setup_url = \WebCareProScanner\Admin\RouteRegistry::url('webcare-pro-login', '2fa', '', ['setup' => '1']);
            ?>
            <div class="notice notice-warning is-dismissible" style="border-left-color: #f59e0b; padding: 12px 16px;">
                <p style="margin: 0; font-size: 13.5px; font-weight: 500; color: #1e293b;">
                    <strong style="color: #b45309;">⚠️ <?php esc_html_e('Action Required: Administrator 2FA Policy Enforced', 'webcare-pro-security'); ?></strong> —
                    <?php
                    /* translators: %d: count of remaining days */
                    printf(esc_html__('Two-factor authentication is mandatory for all administrator accounts. You have %d day(s) remaining before your account is restricted.', 'webcare-pro-security'), (int) $days_left);
                    ?>
                    <a href="<?php echo esc_url($setup_url); ?>" class="button button-secondary" style="margin-left: 10px; font-weight: 600;">
                        <?php esc_html_e('Setup 2FA Now', 'webcare-pro-security'); ?> &rarr;
                    </a>
                </p>
            </div>
            <?php
        } elseif ($compliance['status'] === 'enforcement_required') {
            $setup_url = \WebCareProScanner\Admin\RouteRegistry::url('webcare-pro-login', '2fa', '', ['setup' => '1']);
            ?>
            <div class="notice notice-error" style="border-left-color: #ef4444; padding: 12px 16px;">
                <p style="margin: 0; font-size: 13.5px; font-weight: 600; color: #991b1b;">
                    🛑 <?php esc_html_e('Mandatory Security Enforcement: Administrator 2FA Required', 'webcare-pro-security'); ?> —
                    <?php esc_html_e('Your grace period has expired. You must configure two-factor authentication to restore full administrator privileges.', 'webcare-pro-security'); ?>
                    <a href="<?php echo esc_url($setup_url); ?>" class="button button-primary" style="margin-left: 10px; background: #dc2626; border-color: #dc2626; font-weight: 600;">
                        <?php esc_html_e('Enable 2FA Now', 'webcare-pro-security'); ?>
                    </a>
                </p>
            </div>
            <?php
        }
    }

    /**
     * Get user configured TOTP algorithm ('sha1' or 'sha512')
     */
    public static function get_user_algorithm(int $user_id): string {
        $algo = (string) get_user_meta($user_id, self::META_ALGORITHM, true);
        if (in_array(strtolower($algo), ['sha1', 'sha256', 'sha512'], true)) {
            return strtolower($algo);
        }
        $settings = SettingsManager::get_settings();
        $globalAlgo = !empty($settings['auth_2fa_algorithm']) ? strtolower((string) $settings['auth_2fa_algorithm']) : 'sha1';
        return in_array($globalAlgo, ['sha1', 'sha256', 'sha512'], true) ? $globalAlgo : 'sha1';
    }

    /**
     * Get user configured TOTP digits (6 or 8)
     */
    public static function get_user_digits(int $user_id): int {
        $digits = (int) get_user_meta($user_id, self::META_DIGITS, true);
        if ($digits === 6 || $digits === 8) {
            return $digits;
        }
        $algo = self::get_user_algorithm($user_id);
        if ($algo === 'sha512') {
            return 8;
        }
        $settings = SettingsManager::get_settings();
        return (!empty($settings['auth_2fa_digits']) && (int) $settings['auth_2fa_digits'] === 8) ? 8 : 6;
    }

    /**
     * Check if a specific user has 2FA enabled
     */
    public static function is_user_enabled(int $user_id): bool {
        if (!self::is_globally_enabled()) {
            return false;
        }
        return (bool) get_user_meta($user_id, self::META_ENABLED, true);
    }

    /**
     * Get user secret key (automatically decrypts encrypted secret)
     */
    public static function get_user_secret(int $user_id): ?string {
        $stored = get_user_meta($user_id, self::META_SECRET, true);
        if (empty($stored)) {
            return null;
        }

        $raw = (string) $stored;
        if (SecretVault::is_encrypted($raw)) {
            $decrypted = SecretVault::decrypt($raw);
            return !empty($decrypted) ? $decrypted : null;
        }

        return $raw;
    }

    /**
     * Generate a cryptographically secure Base32 secret key (16 characters)
     */
    public static function generate_secret(int $length = 16): string {
        $alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
        $secret   = '';
        $bytes    = random_bytes($length);

        for ($i = 0; $i < $length; $i++) {
            $secret .= $alphabet[ord($bytes[$i]) % 32];
        }

        return $secret;
    }

    /**
     * Decode a Base32 string into binary
     */
    public static function base32_decode(string $b32): string {
        $alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
        $b32      = strtoupper(trim($b32));
        $buffer   = 0;
        $bitsLeft = 0;
        $output   = '';

        for ($i = 0; $i < strlen($b32); $i++) {
            $val = strpos($alphabet, $b32[$i]);
            if ($val === false) {
                continue; // Skip padding or invalid characters
            }

            $buffer = ($buffer << 5) | $val;
            $bitsLeft += 5;

            if ($bitsLeft >= 8) {
                $bitsLeft -= 8;
                $output .= chr(($buffer >> $bitsLeft) & 0xFF);
            }
        }

        return $output;
    }

    /**
     * Calculate TOTP 6-digit code for a given timestamp
     */
    public static function calculate_code(string $secret, ?int $timestamp = null, string $algo = 'sha1', int $digits = 6): string {
        if ($timestamp === null) {
            $timestamp = time();
        }

        $algo   = in_array(strtolower($algo), ['sha1', 'sha256', 'sha512'], true) ? strtolower($algo) : 'sha1';
        $digits = ($digits === 8) ? 8 : 6;

        $timeSlice    = (int) floor($timestamp / 30);
        $binarySecret = self::base32_decode($secret);

        // Pack 64-bit int into big-endian binary
        $binaryTime = pack('N*', 0) . pack('N*', $timeSlice);
        $hash       = hash_hmac($algo, $binaryTime, $binarySecret, true);

        // Dynamic truncation (RFC 4226 / RFC 6238)
        $hashLen = strlen($hash);
        $offset  = ord($hash[$hashLen - 1]) & 0x0F;
        $binary  = (
            ((ord($hash[$offset]) & 0x7F) << 24) |
            ((ord($hash[$offset + 1]) & 0xFF) << 16) |
            ((ord($hash[$offset + 2]) & 0xFF) << 8) |
            (ord($hash[$offset + 3]) & 0xFF)
        );

        $modulo = (int) pow(10, $digits);
        $otp    = $binary % $modulo;
        return str_pad((string) $otp, $digits, '0', STR_PAD_LEFT);
    }

    /**
     * Verify a 6-digit TOTP code with clock drift tolerance
     */
    public static function verify_code(string $secret, string $code, int $window = 1, string $algo = 'sha1', int $digits = 6): bool {
        $code   = trim($code);
        $algo   = in_array(strtolower($algo), ['sha1', 'sha256', 'sha512'], true) ? strtolower($algo) : 'sha1';
        $digits = ($digits === 8 || $algo === 'sha512') ? 8 : 6;

        if (strlen($code) !== $digits || !ctype_digit($code)) {
            return false;
        }

        $currentTime = time();

        for ($i = -$window; $i <= $window; $i++) {
            $checkTime = $currentTime + ($i * 30);
            if (hash_equals(self::calculate_code($secret, $checkTime, $algo, $digits), $code)) {
                return true;
            }
        }

        return false;
    }

    /**
     * Unified TOTP verification with monotonic timestep tracking and 120s hash-based replay cache.
     *
     * @param int    $user_id
     * @param string $code
     * @return array{valid: bool, error: string, type: string}
     */
    public static function verify_totp_attempt(int $user_id, string $code): array {
        $secret = self::get_user_secret($user_id);
        if (!$secret) {
            return ['valid' => false, 'error' => __('2FA secret not configured.', 'webcare-pro-security'), 'type' => ''];
        }

        $code   = trim($code);
        $algo   = self::get_user_algorithm($user_id);
        $digits = self::get_user_digits($user_id);

        if (strlen($code) !== $digits || !ctype_digit($code)) {
            return ['valid' => false, 'error' => __('Invalid code format.', 'webcare-pro-security'), 'type' => ''];
        }

        $last_step = (int) get_user_meta($user_id, 'webcareproscan_totp_last_step', true);
        $current_time = time();
        $matched_step = null;

        for ($i = -1; $i <= 1; $i++) {
            $step = (int) floor(($current_time + ($i * 30)) / 30);
            if ($step <= $last_step) {
                continue;
            }
            $calculated = self::calculate_code($secret, $step * 30, $algo, $digits);
            if (hash_equals($calculated, $code)) {
                $matched_step = $step;
                break;
            }
        }

        if ($matched_step === null) {
            return ['valid' => false, 'error' => __('Invalid or expired verification code.', 'webcare-pro-security'), 'type' => ''];
        }

        $replay_hash_key = 'webcareproscan_totp_hash_' . hash('sha256', $user_id . ':' . $code);
        if (get_transient($replay_hash_key)) {
            return [
                'valid' => false,
                'error' => __('This authentication code has already been used. Please wait for the next rotating code in your authenticator app.', 'webcare-pro-security'),
                'type'  => '',
            ];
        }

        update_user_meta($user_id, 'webcareproscan_totp_last_step', $matched_step);
        set_transient($replay_hash_key, 1, 120);

        return ['valid' => true, 'error' => '', 'type' => 'totp'];
    }

    /**
     * Generate 8 single-use emergency backup codes
     */
    public static function generate_backup_codes(int $count = 8): array {
        $plain  = [];
        $hashed = [];

        for ($i = 0; $i < $count; $i++) {
            $part1   = strtolower(wp_generate_password(4, false, false));
            $part2   = strtolower(wp_generate_password(4, false, false));
            $code    = $part1 . '-' . $part2;
            $plain[] = $code;
            $hashed[] = wp_hash_password($code);
        }

        return [
            'plain'  => $plain,
            'hashed' => $hashed,
        ];
    }

    /**
     * Verify and consume a backup code for a user
     */
    public static function verify_and_consume_backup_code(int $user_id, string $code): bool {
        $code = strtolower(trim($code));
        $stored = get_user_meta($user_id, self::META_BACKUP_CODES, true);

        if (!is_array($stored) || empty($stored)) {
            return false;
        }

        foreach ($stored as $index => $hashed_code) {
            if (wp_check_password($code, $hashed_code)) {
                // Consume code
                unset($stored[$index]);
                update_user_meta($user_id, self::META_BACKUP_CODES, array_values($stored));
                return true;
            }
        }

        return false;
    }

    /**
     * Get remaining backup codes count for a user
     */
    public static function get_remaining_backup_codes_count(int $user_id): int {
        $stored = get_user_meta($user_id, self::META_BACKUP_CODES, true);
        return is_array($stored) ? count($stored) : 0;
    }

    /**
     * Regenerate emergency backup codes for a user with 2FA enabled
     */
    public static function regenerate_backup_codes(int $user_id, int $count = 8): array {
        if (!self::is_user_enabled($user_id)) {
            throw new \Exception(esc_html__('Two-factor authentication is not enabled for this account.', 'webcare-pro-security'));
        }

        $bundle = self::generate_backup_codes($count);
        update_user_meta($user_id, self::META_BACKUP_CODES, $bundle['hashed']);

        return [
            'backup_codes' => $bundle['plain'],
            'count'        => count($bundle['plain']),
        ];
    }


    /**
     * Enable 2FA for a user
     */
    public static function enable_user(int $user_id, string $secret, array $hashed_backup_codes, string $algo = 'sha1', int $digits = 6): bool {
        $encrypted_secret = SecretVault::encrypt($secret);
        update_user_meta($user_id, self::META_SECRET, $encrypted_secret);
        update_user_meta($user_id, self::META_BACKUP_CODES, $hashed_backup_codes);
        update_user_meta($user_id, self::META_ALGORITHM, in_array(strtolower($algo), ['sha1', 'sha256', 'sha512'], true) ? strtolower($algo) : 'sha1');
        update_user_meta($user_id, self::META_DIGITS, ($digits === 8 || strtolower($algo) === 'sha512') ? 8 : 6);
        update_user_meta($user_id, self::META_ENABLED, 1);
        delete_user_meta($user_id, 'webcareproscan_force_2fa_setup');

        if (class_exists('\\WebCareProScanner\\Notifications\\NotificationDispatcher')) {
            $user = get_userdata($user_id);
            \WebCareProScanner\Notifications\NotificationDispatcher::trigger('auth_2fa_enabled', [
                'severity' => 'info',
                'message'  => sprintf(
                    /* translators: %s: username or user identifier */
                    __('Two-Factor Authentication (2FA) was activated for user "%s".', 'webcare-pro-security'),
                    $user ? $user->user_login : 'user #' . $user_id
                ),
                'details'  => [
                    'user_id'    => $user_id,
                    'user_login' => $user ? $user->user_login : 'unknown',
                    'user_roles' => $user ? implode(', ', $user->roles) : '',
                ],
            ]);
        }

        return true;
    }

    /**
     * Disable 2FA for a user
     */
    public static function disable_user(int $user_id): bool {
        delete_user_meta($user_id, self::META_ENABLED);
        delete_user_meta($user_id, self::META_SECRET);
        delete_user_meta($user_id, self::META_BACKUP_CODES);
        delete_user_meta($user_id, self::META_ALGORITHM);
        delete_user_meta($user_id, self::META_DIGITS);
        delete_user_meta($user_id, self::META_TRUSTED_DEVICES);
        delete_user_meta($user_id, self::META_GRACE_START);
        self::clear_trusted_device_cookie();

        if (class_exists('\\WebCareProScanner\\Notifications\\NotificationDispatcher')) {
            $user = get_userdata($user_id);
            \WebCareProScanner\Notifications\NotificationDispatcher::trigger('auth_2fa_disabled', [
                'severity' => 'high',
                'message'  => sprintf(
                    /* translators: %s: username or user identifier */
                    __('Two-Factor Authentication (2FA) was deactivated for user "%s".', 'webcare-pro-security'),
                    $user ? $user->user_login : 'user #' . $user_id
                ),
                'details'  => [
                    'user_id'    => $user_id,
                    'user_login' => $user ? $user->user_login : 'unknown',
                    'user_roles' => $user ? implode(', ', $user->roles) : '',
                ],
            ]);
        }

        return true;
    }

    /**
     * Reset 2FA for a user and generate new provisioning package
     */
    public static function reset_user_2fa(int $user_id): array {
        self::disable_user($user_id);
        $user = get_user_by('id', $user_id);
        if (!$user) {
            throw new \Exception(esc_html__('User not found.', 'webcare-pro-security'));
        }

        $settings         = SettingsManager::get_settings();
        $algo             = !empty($settings['auth_2fa_algorithm']) ? (string) $settings['auth_2fa_algorithm'] : 'sha1';
        $digits           = (!empty($settings['auth_2fa_digits']) && (int) $settings['auth_2fa_digits'] === 8 || $algo === 'sha512') ? 8 : 6;
        $secretLen        = ($algo === 'sha512') ? 64 : 16;
        $secret           = self::generate_secret($secretLen);
        $provisioning_uri = self::get_provisioning_uri($secret, $user->user_login, $algo, $digits);
        $qr_data_uri      = self::get_qr_data_uri($provisioning_uri);
        $backup_bundle    = self::generate_backup_codes(8);

        // Auto-enable with the generated secret and backup codes
        self::enable_user($user_id, $secret, $backup_bundle['hashed'], $algo, $digits);

        return [
            'user_id'          => $user_id,
            'user_login'       => $user->user_login,
            'secret'           => $secret,
            'algorithm'        => $algo,
            'digits'           => $digits,
            'provisioning_uri' => $provisioning_uri,
            'qr_code_url'      => $qr_data_uri,
            'backup_codes'     => $backup_bundle['plain'],
        ];
    }

    /**
     * Clear all login failures/lockouts for a user's associated IP addresses or username
     */
    public static function unlock_user_lockouts(int $user_id): array {
        $user = get_user_by('id', $user_id);
        if (!$user) {
            return ['unlocked_ips' => [], 'cleared_attempts' => false];
        }

        $unlocked_ips = [];
        $username = $user->user_login;

        if (class_exists('\\WebCareProScanner\\Auth\\LoginHardening')) {
            $lockouts = \WebCareProScanner\Auth\LoginHardening::get_locked_ips();
            foreach ($lockouts as $ip => $data) {
                if (isset($data['username']) && strtolower($data['username']) === strtolower($username)) {
                    \WebCareProScanner\Auth\LoginHardening::unlock_ip($ip);
                    $unlocked_ips[] = $ip;
                }
            }
        }

        return [
            'unlocked_ips'     => $unlocked_ips,
            'cleared_attempts' => true,
        ];
    }

    /**
     * Get all administrator users with 2FA status, compliance, lockouts, and session forensics
     */
    public static function get_administrators_status(): array {
        $admins = get_users(['role' => 'administrator', 'orderby' => 'registered', 'order' => 'ASC']);
        $result = [];

        $locked_ips = class_exists('\\WebCareProScanner\\Auth\\LoginHardening') ? \WebCareProScanner\Auth\LoginHardening::get_locked_ips() : [];
        $locked_usernames = [];
        foreach ($locked_ips as $ip => $data) {
            if (!empty($data['username'])) {
                $locked_usernames[strtolower($data['username'])][] = $ip;
            }
        }

        $current_user_id = get_current_user_id();

        foreach ($admins as $user) {
            $uid = (int) $user->ID;
            $compliance = self::get_user_compliance_status($uid);
            $devices    = self::get_trusted_devices($uid);
            $last_login = get_user_meta($uid, '_webcareproscan_last_login', true);

            $user_locked_ips = $locked_usernames[strtolower($user->user_login)] ?? [];

            $result[] = [
                'user_id'          => $uid,
                'user_login'       => $user->user_login,
                'display_name'     => $user->display_name ?: $user->user_login,
                'user_email'       => $user->user_email,
                'avatar_url'       => get_avatar_url($user->user_email, ['size' => 64]),
                'is_current_user'  => ($uid === $current_user_id),
                'is_2fa_enabled'   => self::is_user_enabled($uid),
                'two_fa_algorithm' => self::get_user_algorithm($uid),
                'two_fa_digits'    => self::get_user_digits($uid),
                'compliance'       => $compliance,
                'trusted_devices'  => count($devices),
                'backup_codes_count' => self::get_remaining_backup_codes_count($uid),
                'registered_at'    => $user->user_registered,
                'last_login'       => !empty($last_login) ? $last_login : null,
                'is_locked'        => !empty($user_locked_ips),
                'locked_ips'       => $user_locked_ips,
            ];
        }

        return $result;
    }

    /**
     * Hook: On user password reset, purge all trusted devices
     */
    public static function on_password_reset($user, $new_pass = '') {
        if ($user instanceof \WP_User) {
            self::revoke_all_trusted_devices($user->ID);

            if (class_exists('\\WebCareProScanner\\Notifications\\NotificationDispatcher')) {
                $is_admin = in_array('administrator', (array) $user->roles, true);
                \WebCareProScanner\Notifications\NotificationDispatcher::trigger('auth_admin_password_reset', [
                    'severity' => $is_admin ? 'high' : 'info',
                    'message'  => sprintf(
                        /* translators: 1: username, 2: role description or empty */
                        __('Password was reset for user "%1$s"%2$s.', 'webcare-pro-security'),
                        $user->user_login,
                        $is_admin ? ' (Administrator account)' : ''
                    ),
                    'details'  => [
                        'user_id'    => $user->ID,
                        'user_login' => $user->user_login,
                        'user_roles' => implode(', ', $user->roles),
                        'ip_address' => class_exists('\\WebCareProScanner\\Firewall\\FirewallEngine') ? \WebCareProScanner\Firewall\FirewallEngine::get_client_ip() : (!empty($_SERVER['REMOTE_ADDR']) ? sanitize_text_field(wp_unslash($_SERVER['REMOTE_ADDR'])) : 'unknown'),
                    ],
                ]);
            }
        }
    }

    /**
     * Check if "Remember Device" feature is allowed in settings
     */
    public static function is_remember_device_enabled(): bool {
        $settings = SettingsManager::get_settings();
        return !empty($settings['auth_2fa_remember_device']);
    }

    /**
     * Get number of days to remember trusted devices (default 7 days)
     */
    public static function get_remember_device_days(): int {
        $settings = SettingsManager::get_settings();
        $days     = (int) ($settings['auth_2fa_remember_days'] ?? 7);
        return max(1, min(90, $days));
    }

    /**
     * Check if the current client request is an authenticated trusted device for a user
     */
    public static function is_trusted_device(int $user_id): bool {
        if (!self::is_remember_device_enabled()) {
            return false;
        }

        if (empty($_COOKIE[self::COOKIE_DEVICE])) {
            return false;
        }

        $raw_cookie = sanitize_text_field(wp_unslash($_COOKIE[self::COOKIE_DEVICE]));
        if (empty($raw_cookie) || strpos($raw_cookie, ':') === false) {
            return false;
        }

        list($cookie_user_id, $token) = explode(':', $raw_cookie, 2);
        if ((int) $cookie_user_id !== $user_id || empty($token)) {
            return false;
        }

        $devices = get_user_meta($user_id, self::META_TRUSTED_DEVICES, true);
        if (!is_array($devices) || empty($devices)) {
            return false;
        }

        $now          = time();
        $token_hash   = hash('sha256', $token);
        $found        = false;
        $active_list  = [];

        foreach ($devices as $id => $device) {
            // Prune expired devices
            if (empty($device['expires_at']) || $device['expires_at'] < $now) {
                continue;
            }

            if (hash_equals($device['token_hash'], $token_hash)) {
                $found = true;
                // Update last used timestamp
                $device['last_used'] = current_time('mysql');
            }

            $active_list[$id] = $device;
        }

        // Persist cleaned up list if any expired were pruned or last_used was updated
        if (count($active_list) !== count($devices) || $found) {
            update_user_meta($user_id, self::META_TRUSTED_DEVICES, $active_list);
        }

        return $found;
    }

    /**
     * Issue a cryptographically secure trusted device cookie and save hash in user meta
     */
    public static function set_trusted_device(int $user_id, int $days = 7): bool {
        if (!self::is_remember_device_enabled()) {
            return false;
        }

        $token        = wp_generate_password(48, false);
        $token_hash   = hash('sha256', $token);
        $days         = $days > 0 ? $days : self::get_remember_device_days();
        $expires_at   = time() + ($days * DAY_IN_SECONDS);
        $user_agent   = isset($_SERVER['HTTP_USER_AGENT']) ? sanitize_text_field(wp_unslash($_SERVER['HTTP_USER_AGENT'])) : 'Unknown';
        $ip           = class_exists('\\WebCareProScanner\\Firewall\\FirewallEngine')
            ? \WebCareProScanner\Firewall\FirewallEngine::get_client_ip()
            : (isset($_SERVER['REMOTE_ADDR']) ? sanitize_text_field(wp_unslash($_SERVER['REMOTE_ADDR'])) : '');
        $device_id    = wp_generate_password(16, false);

        $devices = get_user_meta($user_id, self::META_TRUSTED_DEVICES, true);
        if (!is_array($devices)) {
            $devices = [];
        }

        // Prune expired devices & keep maximum 10 active devices per user
        $now         = time();
        $active_list = [];
        foreach ($devices as $id => $d) {
            if (!empty($d['expires_at']) && $d['expires_at'] > $now) {
                $active_list[$id] = $d;
            }
        }

        if (count($active_list) >= 10) {
            // Remove oldest
            array_shift($active_list);
        }

        $active_list[$device_id] = [
            'id'          => $device_id,
            'token_hash'  => $token_hash,
            'expires_at'  => $expires_at,
            'created_at'  => current_time('mysql'),
            'last_used'   => current_time('mysql'),
            'ip'          => $ip,
            'user_agent'  => $user_agent,
            'days'        => $days,
        ];

        update_user_meta($user_id, self::META_TRUSTED_DEVICES, $active_list);

        // Set hardened cookie: HttpOnly, Secure, SameSite=Lax
        $cookie_value = $user_id . ':' . $token;
        $cookie_path  = COOKIEPATH ?: '/';
        $cookie_domain = COOKIE_DOMAIN ?: '';
        $is_ssl       = is_ssl();

        if (PHP_VERSION_ID >= 70300) {
            setcookie(self::COOKIE_DEVICE, $cookie_value, [
                'expires'  => $expires_at,
                'path'     => $cookie_path,
                'domain'   => $cookie_domain,
                'secure'   => $is_ssl,
                'httponly' => true,
                'samesite' => 'Lax',
            ]);
        } else {
            setcookie(self::COOKIE_DEVICE, $cookie_value, $expires_at, $cookie_path, $cookie_domain, $is_ssl, true);
        }

        return true;
    }

    /**
     * Clear the trusted device cookie from the browser
     */
    public static function clear_trusted_device_cookie() {
        $cookie_path   = COOKIEPATH ?: '/';
        $cookie_domain = COOKIE_DOMAIN ?: '';
        if (PHP_VERSION_ID >= 70300) {
            setcookie(self::COOKIE_DEVICE, '', [
                'expires'  => time() - 3600,
                'path'     => $cookie_path,
                'domain'   => $cookie_domain,
                'secure'   => is_ssl(),
                'httponly' => true,
                'samesite' => 'Lax',
            ]);
        } else {
            setcookie(self::COOKIE_DEVICE, '', time() - 3600, $cookie_path, $cookie_domain, is_ssl(), true);
        }
    }

    /**
     * Revoke all trusted devices for a user
     */
    public static function revoke_all_trusted_devices(int $user_id): bool {
        delete_user_meta($user_id, self::META_TRUSTED_DEVICES);
        self::clear_trusted_device_cookie();
        return true;
    }

    /**
     * Get active trusted devices list for a user
     */
    public static function get_trusted_devices(int $user_id): array {
        $devices = get_user_meta($user_id, self::META_TRUSTED_DEVICES, true);
        if (!is_array($devices)) {
            return [];
        }

        $now    = time();
        $output = [];
        foreach ($devices as $d) {
            if (!empty($d['expires_at']) && $d['expires_at'] > $now) {
                $output[] = [
                    'id'         => $d['id'] ?? '',
                    'ip'         => $d['ip'] ?? '',
                    'user_agent' => $d['user_agent'] ?? '',
                    'created_at' => $d['created_at'] ?? '',
                    'last_used'  => $d['last_used'] ?? '',
                    'expires_at' => $d['expires_at'] ?? 0,
                    'days'       => $d['days'] ?? 7,
                ];
            }
        }
        return $output;
    }


    /**
     * Build provisioning URI for QR code generators
     */
    public static function get_provisioning_uri(string $secret, string $username, string $algo = 'SHA1', int $digits = 6): string {
        $issuer = get_bloginfo('name') ?: 'WordPress';
        $issuer = sanitize_text_field($issuer);
        $cleanAlgo = strtoupper(trim($algo));
        if (!in_array($cleanAlgo, ['SHA1', 'SHA256', 'SHA512'], true)) {
            $cleanAlgo = 'SHA1';
        }
        $cleanDigits = ($digits === 8 || $cleanAlgo === 'SHA512') ? 8 : 6;
        return sprintf(
            'otpauth://totp/%s:%s?secret=%s&issuer=%s&algorithm=%s&digits=%d&period=30',
            rawurlencode($issuer),
            rawurlencode($username),
            $secret,
            rawurlencode($issuer),
            $cleanAlgo,
            $cleanDigits
        );
    }

    /**
     * Generate an inline SVG QR Code representation locally (zero external dependencies)
     */
    public static function get_qr_data_uri(string $content): string {
        try {
            return QRCodeGenerator::get_data_uri($content, 200);
        } catch (\Throwable $e) {
            $escaped = esc_html($content);
            return 'data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="200" height="200"><rect width="100%" height="100%" fill="%23f1f5f9"/><text x="10" y="100" font-size="10" fill="%23334155">' . rawurlencode($escaped) . '</text></svg>';
        }
    }

    /**
     * Intercept WordPress Login Authentication
     */
    public static function filter_authenticate($user, $username, $password) {
        // If credentials already failed, let core handle it
        if (is_wp_error($user) || empty($username) || empty($password)) {
            return $user;
        }

        if (!($user instanceof \WP_User)) {
            return $user;
        }

        // Check if user has 2FA enabled
        if (!self::is_user_enabled($user->ID)) {
            // Redirect to mandatory self-enrollment if enforced globally or explicitly forced after admin reset
            if (self::needs_forced_2fa_onboarding($user->ID)) {
                add_filter('login_redirect', function ($url, $requested, $user_obj) {
                    return \WebCareProScanner\Admin\RouteRegistry::url('webcare-pro-login', '2fa', '', ['setup' => '1', 'forced' => '1']);
                }, 99, 3);
            }
            return $user;
        }

        // Check if current browser is a verified trusted device (e.g. remembered for 7 days)
        if (self::is_trusted_device($user->ID)) {
            if (class_exists('\\WebCareProScanner\\Auth\\SessionSentinel')) {
                \WebCareProScanner\Auth\SessionSentinel::$pending_auth_type = '2fa';
                \WebCareProScanner\Auth\SessionSentinel::$pending_auth_label = __('2FA (Remembered Trusted Device)', 'webcare-pro-security');
                \WebCareProScanner\Auth\SessionSentinel::$pending_auth_details = [
                    'type' => 'trusted_device',
                ];
            }
            return $user; // Trusted device bypass granted!
        }

        // Bound active pending 2FA challenges per (user_id, IP) to prevent unlimited key generation
        $client_ip = class_exists('\\WebCareProScanner\\Firewall\\FirewallEngine')
            ? \WebCareProScanner\Firewall\FirewallEngine::get_client_ip()
            : (isset($_SERVER['REMOTE_ADDR']) ? sanitize_text_field(wp_unslash($_SERVER['REMOTE_ADDR'])) : '127.0.0.1');
        $pending_cnt_key = 'webcareproscan_2fa_pending_cnt_' . hash('sha256', $user->ID . '|' . $client_ip);
        $pending_cnt     = (int) get_transient($pending_cnt_key);
        if ($pending_cnt >= 5) {
            return new \WP_Error(
                'webcareproscan_2fa_rate_limited',
                __('Too many two-factor verification challenges created recently. Please wait 5 minutes before signing in again.', 'webcare-pro-security')
            );
        }
        set_transient($pending_cnt_key, $pending_cnt + 1, 300);

        // All 2FA verifications must pass through the rate-limited 2FA challenge screen
        $pending_key = wp_generate_password(32, false);
        // phpcs:ignore WordPress.Security.NonceVerification.Missing
        $remember_val = !empty($_POST['rememberme']);
        set_transient(self::SESSION_TRANSIENT . $pending_key, [
            'user_id'         => $user->ID,
            'user_login'      => $user->user_login,
            'remember'        => $remember_val,
            'pending_cnt_key' => $pending_cnt_key,
        ], 300); // 5 minutes window

        // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        $redirect_to = !empty($_REQUEST['redirect_to']) ? esc_url_raw(wp_unslash($_REQUEST['redirect_to'])) : admin_url();
        $challenge_url = add_query_arg([
            'action'      => 'webcareproscan_2fa',
            'pending_key' => $pending_key,
            'redirect_to' => urlencode($redirect_to),
        ], wp_login_url());

        wp_safe_redirect($challenge_url);
        exit;
    }

    /**
     * Render the 2FA Challenge Screen on wp-login.php
     */
    public static function render_2fa_challenge_screen() {
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        $pending_key = isset($_GET['pending_key']) ? sanitize_text_field(wp_unslash($_GET['pending_key'])) : '';
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        $redirect_to = isset($_GET['redirect_to']) ? esc_url_raw(wp_unslash($_GET['redirect_to'])) : admin_url();
        $session     = get_transient(self::SESSION_TRANSIENT . $pending_key);

        if (!$session || empty($session['user_id'])) {
            wp_die(
                esc_html__('Your two-factor verification session has expired. Please log in again.', 'webcare-pro-security'),
                esc_html__('Session Expired', 'webcare-pro-security'),
                ['response' => 403, 'back_link' => true]
            );
        }

        $user_id = (int) $session['user_id'];
        $user    = get_user_by('id', $user_id);
        if (!$user) {
            wp_die(esc_html__('Invalid user session.', 'webcare-pro-security'));
        }

        $remember_device_allowed = self::is_remember_device_enabled();
        $remember_days           = self::get_remember_device_days();
        $error_msg               = '';

        // Handle Form Submission
        $request_method = isset($_SERVER['REQUEST_METHOD']) ? strtoupper(sanitize_key(wp_unslash($_SERVER['REQUEST_METHOD']))) : '';
        if ($request_method === 'POST' && isset($_POST['webcareproscan_2fa_code'])) {
            check_admin_referer('webcareproscan_2fa_verify_' . $pending_key);

            // Rate-limit brute-force attempts on this pending verification session (max 5 attempts)
            $attempt_transient = 'webcareproscan_2fa_attempts_' . $pending_key;
            $failed_attempts = (int) get_transient($attempt_transient);
            if ($failed_attempts >= 5) {
                delete_transient(self::SESSION_TRANSIENT . $pending_key);
                delete_transient($attempt_transient);
                wp_die(
                    esc_html__('Too many incorrect verification attempts. For your security, this login session has been terminated. Please log in again.', 'webcare-pro-security'),
                    esc_html__('Too Many Attempts', 'webcare-pro-security'),
                    ['response' => 429, 'back_link' => true]
                );
            }

            $code   = sanitize_text_field(wp_unslash($_POST['webcareproscan_2fa_code']));
            $secret = self::get_user_secret($user_id);
            $valid  = false;

            $code_type  = 'totp';
            $userAlgo   = self::get_user_algorithm($user_id);
            $userDigits = self::get_user_digits($user_id);

            // Check TOTP code via monotonic verification and 120s hash replay cache
            $totp_res = self::verify_totp_attempt($user_id, $code);
            if (!empty($totp_res['valid'])) {
                $valid     = true;
                $code_type = 'totp';
            } elseif (!empty($totp_res['error']) && strpos($totp_res['error'], 'already been used') !== false) {
                $valid     = false;
                $error_msg = $totp_res['error'];
            } elseif (self::verify_and_consume_backup_code($user_id, $code)) {
                $valid     = true;
                $code_type = 'backup_code';
            }

            if ($valid) {
                // Delete session and attempt transients
                delete_transient(self::SESSION_TRANSIENT . $pending_key);
                delete_transient($attempt_transient);
                if (!empty($session['pending_cnt_key']) && is_string($session['pending_cnt_key'])) {
                    delete_transient($session['pending_cnt_key']);
                }

                if (class_exists('\\WebCareProScanner\\Auth\\SessionSentinel')) {
                    \WebCareProScanner\Auth\SessionSentinel::$pending_auth_type = '2fa';
                    \WebCareProScanner\Auth\SessionSentinel::$pending_auth_label = ($code_type === 'backup_code')
                        ? __('2FA (Emergency Recovery Code)', 'webcare-pro-security')
                        : __('2FA (TOTP Authenticator)', 'webcare-pro-security');
                    \WebCareProScanner\Auth\SessionSentinel::$pending_auth_details = [
                        'type' => $code_type,
                    ];
                }

                // Handle "Remember this device"
                if (!empty($_POST['webcareproscan_2fa_remember_device']) && $remember_device_allowed) {
                    self::set_trusted_device($user_id, $remember_days);
                }

                // Complete authentication
                wp_set_auth_cookie($user_id, !empty($session['remember']));
                // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Standard WordPress core login hook invocation
                do_action('wp_login', $user->user_login, $user);

                wp_safe_redirect($redirect_to);
                exit;
            } else {
                set_transient($attempt_transient, $failed_attempts + 1, 300);
                $fail_err = new \WP_Error('invalid_2fa_code', __('Invalid two-factor verification code.', 'webcare-pro-security'));
                if (has_action('wp_login_failed', [\WebCareProScanner\Auth\LoginHardening::class, 'record_failed_attempt'])) {
                    // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Core WordPress failed login telemetry hook
                    do_action('wp_login_failed', $user->user_login, $fail_err);
                } elseif (class_exists('\\WebCareProScanner\\Auth\\LoginHardening')) {
                    \WebCareProScanner\Auth\LoginHardening::record_failed_attempt($user->user_login, $fail_err);
                }
                if (empty($error_msg)) {
                    $attempts_left = max(0, 5 - ($failed_attempts + 1));
                    /* translators: %d: number of remaining verification attempts */
                    $error_msg = sprintf(__('Invalid two-factor code (%d attempts remaining). Please check your authenticator app or enter a recovery code.', 'webcare-pro-security'), $attempts_left);
                }
            }
        }

        // Render HTML Challenge Page
        login_header(__('Two-Factor Authentication', 'webcare-pro-security'));
        ?>
        <div style="margin-bottom: 20px; text-align: center;">
            <div style="display: inline-block; background: #e0f2fe; padding: 12px; border-radius: 50%; margin-bottom: 12px;">
                <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#0284c7" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <rect width="18" height="11" x="3" y="11" rx="2" ry="2"/>
                    <path d="M7 11V7a5 5 0 0 1 10 0v4"/>
                </svg>
            </div>
            <h2 style="font-size: 18px; margin: 0 0 6px 0; color: #0f172a; font-weight: 700;">
                <?php esc_html_e('Two-Factor Verification', 'webcare-pro-security'); ?>
            </h2>
            <?php
            $userDigits = self::get_user_digits($user_id);
            $userAlgo   = self::get_user_algorithm($user_id);
            ?>
            <p style="font-size: 13px; color: #64748b; margin: 0;">
                <?php
                /* translators: 1: username in strong tags, 2: digit count */
                printf(esc_html__('Logged in as %1$s. Enter the %2$d-digit code from your authenticator app to complete sign-in.', 'webcare-pro-security'), '<strong>' . esc_html($user->user_login) . '</strong>', (int) $userDigits);
                ?>
            </p>
        </div>

        <?php if (!empty($error_msg)): ?>
            <div id="login_error" style="border-left-color: #dc2626; margin-bottom: 20px;">
                <strong><?php esc_html_e('Verification Failed:', 'webcare-pro-security'); ?></strong> <?php echo esc_html($error_msg); ?>
            </div>
        <?php endif; ?>

        <form name="webcare2faform" id="webcare2faform" action="" method="post" style="padding-bottom: 16px;">
            <?php wp_nonce_field('webcareproscan_2fa_verify_' . $pending_key); ?>
            <p>
                <label for="webcareproscan_2fa_code" style="font-weight: 600; font-size: 13px; color: #334155;">
                    <?php esc_html_e('Security Code or Recovery Code', 'webcare-pro-security'); ?>
                </label>
                <input type="text" name="webcareproscan_2fa_code" id="webcareproscan_2fa_code" class="input" value="" size="20" autocomplete="one-time-code" autofocus inputmode="text" placeholder="<?php echo esc_attr(str_repeat('0', (int) $userDigits)); ?>" maxlength="12" style="font-size: 22px; letter-spacing: 4px; text-align: center; font-weight: 700; border-radius: 8px; border: 1px solid #cbd5e1; padding: 10px;" required />
            </p>

            <?php if ($remember_device_allowed): ?>
                <p style="margin: 14px 0 6px 0; display: flex; align-items: center; gap: 8px;">
                    <label for="webcareproscan_2fa_remember_device" style="font-size: 13px; color: #334155; cursor: pointer; display: inline-flex; align-items: center; gap: 8px;">
                        <input type="checkbox" name="webcareproscan_2fa_remember_device" id="webcareproscan_2fa_remember_device" value="1" checked style="accent-color: #0284c7; width: 16px; height: 16px; margin: 0;" />
                        <span><?php
                        /* translators: %d: count of remember device days */
                        printf(esc_html__('Remember this device for %d days', 'webcare-pro-security'), (int) $remember_days);
                        ?></span>
                    </label>
                </p>
            <?php endif; ?>

            <p class="submit" style="margin-top: 18px;">
                <input type="submit" name="wp-submit" id="wp-submit" class="button button-primary button-large" value="<?php esc_attr_e('Verify & Continue', 'webcare-pro-security'); ?>" style="width: 100%; border-radius: 8px; background: #0284c7; border-color: #0284c7; height: 42px; font-weight: 600;" />
            </p>
        </form>

        <p id="backtoblog" style="text-align: center; margin-top: 20px;">
            <a href="<?php echo esc_url(wp_login_url()); ?>" style="font-size: 13px; color: #64748b;">
                &larr; <?php esc_html_e('Cancel and Return to Login', 'webcare-pro-security'); ?>
            </a>
        </p>
        <?php
        login_footer();
        exit;
    }
}

