<?php
namespace WebCareProScanner\Admin;

if (!defined('ABSPATH')) {
    exit;
}

class AdminMenu {
    public static function register() {
        add_action('admin_menu', [__CLASS__, 'add_menu_page']);
        add_action('admin_enqueue_scripts', [__CLASS__, 'enqueue_assets']);
        add_filter('plugin_action_links_' . plugin_basename(WEBCAREPROSCAN_FILE), [__CLASS__, 'add_plugin_action_links']);
        add_action('admin_enqueue_scripts', [__CLASS__, 'enqueue_brand_styles']);
        add_action('admin_notices', [__CLASS__, 'render_user_recovery_notice']);
        add_action('admin_init', [__CLASS__, 'handle_user_recovery_action']);
        add_action('admin_init', [__CLASS__, 'handle_wizard_activation_redirect']);
        add_action('admin_init', [__CLASS__, 'ensure_admin_screen_title']);
        add_action('current_screen', [__CLASS__, 'ensure_admin_screen_title']);
        add_action('admin_footer', [__CLASS__, 'render_plugins_uninstall_modal']);
        add_action('wp_ajax_webcareproscan_set_uninstall_purge', [__CLASS__, 'ajax_set_uninstall_purge']);
        add_action('wp_ajax_webcareproscan_dismiss_quarantined_notice', [__CLASS__, 'ajax_dismiss_quarantined_notice']);
        add_filter('script_loader_tag', [__CLASS__, 'add_charset_to_scripts'], 10, 2);
    }

    /**
     * Ensure WebCare scripts are parsed explicitly with UTF-8 character encoding across all browsers and locales.
     *
     * @param string $tag The <script> tag for the enqueued script.
     * @param string $handle The script's registered handle.
     * @return string
     */
    public static function add_charset_to_scripts($tag, $handle) {
        if (in_array($handle, ['webcare-pro-app', 'webcare-global-script', 'webcare-popover-dialogs'], true) && strpos($tag, 'charset=') === false) {
            $tag = str_replace('<script ', '<script charset="UTF-8" ', $tag);
        }
        return $tag;
    }

    /**
     * Get the menu icon as an inline base64-encoded SVG data URI with fallback to URL.
     * Prevents broken image icons if static asset requests are delayed, misconfigured, or blocked.
     *
     * @return string
     */
    public static function get_menu_icon(): string {
        $png_icon = plugin_dir_path(WEBCAREPROSCAN_FILE) . 'assets/logo-96x96.png';
        if (!file_exists($png_icon)) {
            $png_icon = plugin_dir_path(WEBCAREPROSCAN_FILE) . 'assets/logo.png';
        }
        if (file_exists($png_icon)) {
            $png_content = @file_get_contents($png_icon);
            if ($png_content !== false && !empty($png_content)) {
                $png_data_uri = 'data:image/png;base64,' . base64_encode($png_content);
                $svg_wrapper = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 96 96" width="20" height="20">'
                    . '<image href="' . $png_data_uri . '" width="96" height="96"/>'
                    . '</svg>';
                return 'data:image/svg+xml;base64,' . base64_encode($svg_wrapper);
            }
        }
        $icon_file = plugin_dir_path(WEBCAREPROSCAN_FILE) . 'assets/icon.svg';
        if (file_exists($icon_file)) {
            $svg_content = @file_get_contents($icon_file);
            if ($svg_content !== false && !empty($svg_content)) {
                return 'data:image/svg+xml;base64,' . base64_encode($svg_content);
            }
        }
        return 'dashicons-shield';
    }

    public static function add_menu_page() {
        $menu_icon = self::get_menu_icon();

        // Main Menu: Dashboard
        add_menu_page(
            __('WebCare Pro Security & Firewall', 'webcare-pro-security'),
            __('WebCare Pro', 'webcare-pro-security'),
            'manage_options',
            'webcare-pro-security',
            [__CLASS__, 'render_app_container'],
            $menu_icon,
            80
        );

        // =========================================================================
        // PRIMARY VISIBLE MENU PILLARS (Strictly Consolidated 6 SOC Pillars)
        // =========================================================================

        // 1. Submenu: Dashboard
        add_submenu_page(
            'webcare-pro-security',
            __('WebCare Pro Dashboard', 'webcare-pro-security'),
            __('Dashboard', 'webcare-pro-security'),
            'manage_options',
            'webcare-pro-security',
            [__CLASS__, 'render_app_container']
        );

        // 2. Submenu: Firewall & Logs
        add_submenu_page(
            'webcare-pro-security',
            __('Web Application Firewall, Rules & Traffic Defense', 'webcare-pro-security'),
            __('Firewall & Logs', 'webcare-pro-security'),
            'manage_options',
            'webcare-pro-firewall',
            [__CLASS__, 'render_app_container']
        );

        // 3. Submenu: Scanner & CVEs
        add_submenu_page(
            'webcare-pro-security',
            __('Deep Security Scanner & Vulnerability Findings', 'webcare-pro-security'),
            __('Scanner & CVEs', 'webcare-pro-security'),
            'manage_options',
            'webcare-pro-scan',
            [__CLASS__, 'render_app_container']
        );

        // 4. Submenu: Login & Access
        add_submenu_page(
            'webcare-pro-security',
            __('Zero-Trust Identity, 2FA & Access Control', 'webcare-pro-security'),
            __('Login & Access', 'webcare-pro-security'),
            'manage_options',
            'webcare-pro-auth',
            [__CLASS__, 'render_app_container']
        );

        // 5. Submenu: Vault & Backups
        add_submenu_page(
            'webcare-pro-security',
            __('Quarantine Vault, Database Backups & Storage', 'webcare-pro-security'),
            __('Vault & Backups', 'webcare-pro-security'),
            'manage_options',
            'webcare-pro-vault',
            [__CLASS__, 'render_app_container']
        );

        // 6. Submenu: Settings & Doctor
        add_submenu_page(
            'webcare-pro-security',
            __('Security Settings, Doctor Diagnostics & Governance', 'webcare-pro-security'),
            __('Settings & Doctor', 'webcare-pro-security'),
            'manage_options',
            'webcare-pro-settings',
            [__CLASS__, 'render_app_container']
        );

        // =========================================================================
        // COMPANION SUB-PAGES (Accessible via Tabs, Direct Deep-Links & Mega-Menu)
        // =========================================================================

        // Sub-Page: Modular Intelligence Firewall (Redirects to Firewall & Logs)
        add_submenu_page(
            null,
            __('Modular Intelligence Firewall', 'webcare-pro-security'),
            __('Modular WAF', 'webcare-pro-security'),
            'manage_options',
            'webcare-pro-modular-waf',
            [__CLASS__, 'render_app_container']
        );

        // Sub-Page: Virtual Patching & 0-Day Exploit Studio
        add_submenu_page(
            null,
            __('Virtual Patching & 0-Day Exploit Studio', 'webcare-pro-security'),
            __('Virtual Patching', 'webcare-pro-security'),
            'manage_options',
            'webcare-pro-vpatch',
            [__CLASS__, 'render_app_container']
        );

        // Sub-Page: About & Services
        add_submenu_page(
            null,
            __('About WebCare Pro & Direct Support', 'webcare-pro-security'),
            __('About & Support', 'webcare-pro-security'),
            'manage_options',
            'webcare-pro-about',
            [__CLASS__, 'render_app_container']
        );

        // Sub-Page: Targeted Scans
        add_submenu_page(
            null,
            __('Targeted Security Audits', 'webcare-pro-security'),
            __('Targeted Scans', 'webcare-pro-security'),
            'manage_options',
            'webcare-pro-tools',
            [__CLASS__, 'render_app_container']
        );

        // Sub-Page: Scan Logs & History
        add_submenu_page(
            null,
            __('Scan Logs & Audit History', 'webcare-pro-security'),
            __('Scan Logs', 'webcare-pro-security'),
            'manage_options',
            'webcare-pro-logs',
            [__CLASS__, 'render_app_container']
        );

        // Sub-Page: System Forensics & Deep Diagnostics
        add_submenu_page(
            null,
            __('System Forensics & Deep Diagnostics', 'webcare-pro-security'),
            __('System Forensics', 'webcare-pro-security'),
            'manage_options',
            'webcare-pro-forensics',
            [__CLASS__, 'render_app_container']
        );

        // Sub-Page: File Integrity Monitoring (FIM) & Code Diff
        add_submenu_page(
            null,
            __('File Integrity Monitoring (FIM) & Code Diff', 'webcare-pro-security'),
            __('File Integrity (FIM)', 'webcare-pro-security'),
            'manage_options',
            'webcare-pro-fim',
            [__CLASS__, 'render_app_container']
        );

        // Sub-Page: Vulnerabilities & Updates (Outdated Themes/Plugins/Core with CVEs)
        add_submenu_page(
            null,
            __('Vulnerabilities & Updates', 'webcare-pro-security'),
            __('Vulnerabilities', 'webcare-pro-security'),
            'manage_options',
            'webcare-pro-vulnerabilities',
            [__CLASS__, 'render_app_container']
        );

        // Sub-Page: Onboarding & Protection Quickstart Wizard
        add_submenu_page(
            null,
            __('WebCare Pro Protection Quickstart Wizard', 'webcare-pro-security'),
            __('Protection Wizard', 'webcare-pro-security'),
            'manage_options',
            'webcare-pro-wizard',
            [__CLASS__, 'render_app_container']
        );

        // Sub-Page: Database Backup Vault
        add_submenu_page(
            null,
            __('Database Backup Vault', 'webcare-pro-security'),
            __('Database Backup', 'webcare-pro-security'),
            'manage_options',
            'webcare-pro-backup',
            [__CLASS__, 'render_app_container']
        );

        // Sub-Page: Server & Host Infrastructure Telemetry
        add_submenu_page(
            null,
            __('Server & Host Infrastructure Telemetry', 'webcare-pro-security'),
            __('Host Telemetry', 'webcare-pro-security'),
            'manage_options',
            'webcare-pro-server',
            [__CLASS__, 'render_app_container']
        );

        // Sub-Page: WAF Incident Logs & Telemetry
        add_submenu_page(
            null,
            __('WAF Incident Logs & Attack Forensics', 'webcare-pro-security'),
            __('WAF Logs', 'webcare-pro-security'),
            'manage_options',
            'webcare-pro-waf-logs',
            [__CLASS__, 'render_app_container']
        );

        // Sub-Page: Notifications & Alerts
        add_submenu_page(
            null,
            __('Notifications & Security Alerts', 'webcare-pro-security'),
            __('Notifications', 'webcare-pro-security'),
            'manage_options',
            'webcare-pro-notifications',
            [__CLASS__, 'render_app_container']
        );

        // Sub-Page: Activity & Audit Logs
        add_submenu_page(
            null,
            __('Plugin Activity & Audit Logs', 'webcare-pro-security'),
            __('Activity Logs', 'webcare-pro-security'),
            'manage_options',
            'webcare-pro-activity-logs',
            [__CLASS__, 'render_app_container']
        );

        // Sub-Page: Cron & Scheduled Tasks Control Center
        add_submenu_page(
            null,
            __('Cron & Scheduled Tasks Control Center', 'webcare-pro-security'),
            __('Cron Manager', 'webcare-pro-security'),
            'manage_options',
            'webcare-pro-cron-manager',
            [__CLASS__, 'render_app_container']
        );

        // Sub-Page: Context-Adaptive Firewall (CAF)
        add_submenu_page(
            null,
            __('Context-Adaptive Firewall (CAF) & StackGuard', 'webcare-pro-security'),
            __('CAF Defense', 'webcare-pro-security'),
            'manage_options',
            'webcare-pro-caf',
            [__CLASS__, 'render_app_container']
        );

        // Sub-Page: Quarantine Vault
        add_submenu_page(
            null,
            __('Quarantine Vault & Safety Recoveries', 'webcare-pro-security'),
            __('Quarantine Vault', 'webcare-pro-security'),
            'manage_options',
            'webcare-pro-quarantine',
            [__CLASS__, 'render_app_container']
        );
    }

    /**
     * Ensure global $title is a valid string for all WebCare admin screens before WordPress core admin-header.php runs.
     * Prevents PHP 8.4 deprecation: strip_tags(): Passing null to parameter #1 ($string) is deprecated.
     */
    public static function ensure_admin_screen_title(): void {
        global $title;
        if (empty($title)) {
            // phpcs:ignore WordPress.Security.NonceVerification.Recommended
            $page = isset($_GET['page']) ? sanitize_key(wp_unslash($_GET['page'])) : '';
            $title_map = [
                'webcare-pro-security'       => __('WebCare Pro Security & Firewall', 'webcare-pro-security'),
                'webcare-pro-wizard'         => __('WebCare Pro Setup Studio', 'webcare-pro-security'),
                'webcare-pro-scan'           => __('Security Scan & Findings', 'webcare-pro-security'),
                'webcare-pro-firewall'       => __('Web Application Firewall (WAF Lite)', 'webcare-pro-security'),
                'webcare-pro-caf'            => __('Context-Adaptive Firewall (CAF) & StackGuard', 'webcare-pro-security'),
                'webcare-pro-vpatch'         => __('Virtual Patching & 0-Day Exploit Studio', 'webcare-pro-security'),
                'webcare-pro-auth'           => __('Multi-Factor Authentication (2FA) & Login Security', 'webcare-pro-security'),
                'webcare-pro-vault'          => __('WebCare Pro Vault & Safety Recoveries', 'webcare-pro-security'),
                'webcare-pro-settings'       => __('Scanner Settings & AI Configuration', 'webcare-pro-security'),
                'webcare-pro-about'          => __('About WebCare Pro & Services', 'webcare-pro-security'),
                'webcare-pro-tools'          => __('Targeted Security Audits', 'webcare-pro-security'),
                'webcare-pro-logs'           => __('Scan Logs & Audit History', 'webcare-pro-security'),
                'webcare-pro-forensics'      => __('System Forensics & Deep Diagnostics', 'webcare-pro-security'),
                'webcare-pro-fim'            => __('File Integrity Monitoring (FIM) & Code Diff', 'webcare-pro-security'),
                'webcare-pro-vulnerabilities'=> __('Vulnerabilities & Updates', 'webcare-pro-security'),
                'webcare-pro-backup'         => __('Database Backup Vault', 'webcare-pro-security'),
                'webcare-pro-server'         => __('Server & Host Infrastructure Telemetry', 'webcare-pro-security'),
                'webcare-pro-waf-logs'       => __('WAF Incident Logs & Attack Forensics', 'webcare-pro-security'),
                'webcare-pro-notifications'  => __('Notifications & Security Alerts', 'webcare-pro-security'),
                'webcare-pro-activity-logs'  => __('Plugin Activity & Audit Logs', 'webcare-pro-security'),
                'webcare-pro-cron-manager'   => __('Cron & Scheduled Tasks Control Center', 'webcare-pro-security'),
                'webcare-pro-modular-waf'    => __('Modular WAF Engine', 'webcare-pro-security'),
            ];

            if (isset($title_map[$page])) {
                $title = $title_map[$page];
            } elseif (strpos($page, 'webcare-') !== false || $page === 'webcare-pro-security') {
                $title = __('WebCare Pro Security & Firewall', 'webcare-pro-security');
            }
        }
    }

    public static function render_app_container() {
        echo '<div class="wrap"><div id="webcare-scanner-root" class="webcare-scanner-root"></div></div>';
    }

    public static function enqueue_assets($hook) {
        $valid_hooks = [
            'toplevel_page_webcare-pro-security',
            'webcare-pro-security_page_webcare-pro-scan',
            'webcare-pro-security_page_webcare-pro-vault',
            'webcare-pro-security_page_webcare-pro-tools',
            'webcare-pro-security_page_webcare-pro-logs',
            'webcare-pro-security_page_webcare-pro-forensics',
            'webcare-pro-security_page_webcare-pro-quarantine',
            'webcare-pro-security_page_webcare-pro-backup',
            'webcare-pro-security_page_webcare-pro-server',
            'webcare-pro-security_page_webcare-pro-vulnerabilities',
            'webcare-pro-security_page_webcare-pro-firewall',
            'webcare-pro-security_page_webcare-pro-caf',
            'webcare-pro-security_page_webcare-pro-vpatch',
            'webcare-pro-security_page_webcare-pro-waf-logs',
            'webcare-pro-security_page_webcare-pro-fim',
            'webcare-pro-security_page_webcare-pro-auth',
            'webcare-pro-security_page_webcare-pro-notifications',
            'webcare-pro-security_page_webcare-pro-activity-logs',
            'webcare-pro-security_page_webcare-pro-cron-manager',
            'webcare-pro-security_page_webcare-pro-settings',
            'webcare-pro-security_page_webcare-pro-about',
            'webcare-pro-security_page_webcare-pro-wizard',
            'webcare-pro-security_page_webcare-pro-modular-waf',
        ];

        // Also check query param fallback
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        $current_page = isset($_GET['page']) ? sanitize_key(wp_unslash($_GET['page'])) : '';
        $is_webcare_page = in_array($hook, $valid_hooks, true) || strpos($current_page, 'webcare-pro-') === 0;

        if (!$is_webcare_page) {
            return;
        }

        // Enqueue universal in-page popover dialog system for alerts & near-button confirmations
        $popover_js_url = WEBCAREPROSCAN_URL . 'assets/js/webcare-popover-dialogs.js';
        $popover_js_path = WEBCAREPROSCAN_PATH . 'assets/js/webcare-popover-dialogs.js';
        if (file_exists($popover_js_path)) {
            wp_enqueue_script('webcare-popover-dialogs', $popover_js_url, [], WEBCAREPROSCAN_VERSION, false);
        }

        $active_tab = 'dashboard';
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        $tab_param = isset($_GET['tab']) ? sanitize_key(wp_unslash($_GET['tab'])) : '';

        // Resolve active cluster tab: check dedicated page slug first, then fallback to tab parameter
        if ($current_page === 'webcare-pro-auth') $active_tab = 'auth';
        elseif ($current_page === 'webcare-pro-logs') $active_tab = 'logs';
        elseif ($current_page === 'webcare-pro-tools') $active_tab = 'targeted';
        elseif ($current_page === 'webcare-pro-vulnerabilities') $active_tab = 'vulnerabilities';
        elseif ($current_page === 'webcare-pro-fim') $active_tab = 'fim';
        elseif ($current_page === 'webcare-pro-quarantine') $active_tab = 'quarantine';
        elseif ($current_page === 'webcare-pro-backup') $active_tab = 'backup';
        elseif ($current_page === 'webcare-pro-server') $active_tab = 'server';
        elseif ($current_page === 'webcare-pro-forensics') $active_tab = 'forensics';
        elseif ($current_page === 'webcare-pro-vault') {
            if ($tab_param === 'server') {
                $active_tab = 'server';
            } elseif ($tab_param === 'quarantine') {
                $active_tab = 'quarantine';
            } elseif ($tab_param === 'backup' || $tab_param === 'database') {
                $active_tab = 'backup';
            } else {
                $active_tab = 'vault';
            }
        }
        elseif ($current_page === 'webcare-pro-waf-logs') $active_tab = 'waf_logs';
        elseif (in_array($current_page, ['webcare-pro-firewall', 'webcare-pro-vpatch', 'webcare-pro-caf'], true)) $active_tab = 'firewall';
        elseif ($current_page === 'webcare-pro-notifications') $active_tab = 'notifications';
        elseif ($current_page === 'webcare-pro-activity-logs') $active_tab = 'activity_logs';
        elseif ($current_page === 'webcare-pro-cron-manager') $active_tab = 'cron_manager';
        elseif ($current_page === 'webcare-pro-settings') $active_tab = 'settings';
        elseif ($current_page === 'webcare-pro-about') $active_tab = 'about';
        elseif ($current_page === 'webcare-pro-wizard') $active_tab = 'wizard';
        elseif ($current_page === 'webcare-pro-modular-waf') $active_tab = 'modular_waf';
        elseif ($current_page === 'webcare-pro-scan') $active_tab = 'scan';
        // Tab parameter fallback for main portal / sub-tab navigation
        elseif ($tab_param === 'logs') $active_tab = 'logs';
        elseif ($tab_param === 'targeted') $active_tab = 'targeted';
        elseif ($tab_param === 'vulnerabilities') $active_tab = 'vulnerabilities';
        elseif ($tab_param === 'fim') $active_tab = 'fim';
        elseif ($tab_param === 'quarantine') $active_tab = 'quarantine';
        elseif ($tab_param === 'backup') $active_tab = 'backup';
        elseif ($tab_param === 'server') $active_tab = 'server';
        elseif ($tab_param === 'forensics') $active_tab = 'forensics';
        elseif ($tab_param === 'vault') $active_tab = 'vault';
        elseif ($tab_param === 'waf_logs') $active_tab = 'waf_logs';
        elseif (in_array($tab_param, ['firewall', 'vpatch', 'caf'], true)) $active_tab = 'firewall';
        elseif ($tab_param === 'auth') $active_tab = 'auth';
        elseif ($tab_param === 'notifications') $active_tab = 'notifications';
        elseif ($tab_param === 'activity_logs') $active_tab = 'activity_logs';
        elseif ($tab_param === 'cron_manager') $active_tab = 'cron_manager';
        elseif ($tab_param === 'settings') $active_tab = 'settings';
        elseif ($tab_param === 'about') $active_tab = 'about';
        elseif ($tab_param === 'wizard') $active_tab = 'wizard';
        elseif ($tab_param === 'modular_waf') $active_tab = 'modular_waf';
        elseif ($tab_param === 'scan') $active_tab = 'scan';

        $global_css_file = WEBCAREPROSCAN_PATH . 'build/global.css';
        $global_js_file  = WEBCAREPROSCAN_PATH . 'build/global.js';
        $global_css_ver  = file_exists($global_css_file) ? (string) filemtime($global_css_file) : WEBCAREPROSCAN_VERSION;
        $global_js_ver   = file_exists($global_js_file) ? (string) filemtime($global_js_file) : WEBCAREPROSCAN_VERSION;

        // 1. Enqueue Global Core Shell Assets (Design tokens, CSS variables & typography)
        if (file_exists($global_css_file)) {
            wp_enqueue_style('webcare-global-style', WEBCAREPROSCAN_URL . 'build/global.css', ['wp-components'], $global_css_ver);
        }
        if (file_exists($global_js_file)) {
            wp_enqueue_script('webcare-global-script', WEBCAREPROSCAN_URL . 'build/global.js', ['wp-element'], $global_js_ver, true);
        }

        $is_scan_cluster = ($current_page === 'webcare-pro-scan')
            || in_array($active_tab, ['scan', 'targeted', 'logs', 'vulnerabilities'], true);

        // 2. Select decoupled per-page bundle (ensures individual page updates never break other pages)
        $page_bundle = 'index';
        if ($is_scan_cluster && file_exists(WEBCAREPROSCAN_PATH . 'build/scan.js')) {
            $page_bundle = 'scan';
        } elseif ($active_tab === 'firewall' && file_exists(WEBCAREPROSCAN_PATH . 'build/firewall.js')) {
            $page_bundle = 'firewall';
        } elseif ($active_tab === 'waf_logs' && file_exists(WEBCAREPROSCAN_PATH . 'build/waf-logs.js')) {
            $page_bundle = 'waf-logs';
        } elseif ($active_tab === 'auth' && file_exists(WEBCAREPROSCAN_PATH . 'build/auth.js')) {
            $page_bundle = 'auth';
        } elseif (in_array($active_tab, ['vault', 'quarantine', 'backup', 'server'], true) && file_exists(WEBCAREPROSCAN_PATH . 'build/vault.js')) {
            $page_bundle = 'vault';
        } elseif ($active_tab === 'fim' && file_exists(WEBCAREPROSCAN_PATH . 'build/fim.js')) {
            $page_bundle = 'fim';
        } elseif ($active_tab === 'settings' && file_exists(WEBCAREPROSCAN_PATH . 'build/settings.js')) {
            $page_bundle = 'settings';
        } elseif ($active_tab === 'notifications' && file_exists(WEBCAREPROSCAN_PATH . 'build/notifications.js')) {
            $page_bundle = 'notifications';
        } elseif ($active_tab === 'activity_logs' && file_exists(WEBCAREPROSCAN_PATH . 'build/activity-logs.js')) {
            $page_bundle = 'activity-logs';
        } elseif ($active_tab === 'cron_manager' && file_exists(WEBCAREPROSCAN_PATH . 'build/cron-manager.js')) {
            $page_bundle = 'cron-manager';
        } elseif ($active_tab === 'wizard' && file_exists(WEBCAREPROSCAN_PATH . 'build/wizard.js')) {
            $page_bundle = 'wizard';
        } elseif ($active_tab === 'modular_waf' && file_exists(WEBCAREPROSCAN_PATH . 'build/modular-waf.js')) {
            $page_bundle = 'modular-waf';
        }

        $js_rel = "build/{$page_bundle}.js";
        $css_rel = file_exists(WEBCAREPROSCAN_PATH . "build/{$page_bundle}.css") ? "build/{$page_bundle}.css" : '';
        $asset_file = WEBCAREPROSCAN_PATH . "build/{$page_bundle}.asset.php";

        $deps = ['wp-element', 'wp-components', 'wp-api-fetch', 'wp-i18n'];
        $bundle_file = WEBCAREPROSCAN_PATH . $js_rel;
        $version = file_exists($bundle_file) ? (string) filemtime($bundle_file) : WEBCAREPROSCAN_VERSION;

        if (file_exists($asset_file)) {
            $asset = include $asset_file;
            $deps = $asset['dependencies'] ?? $deps;
            $version = $asset['version'] ?? $version;
        }

        $js_url = WEBCAREPROSCAN_URL . $js_rel;
        $css_url = WEBCAREPROSCAN_URL . $css_rel;
        $target_bundle_path = WEBCAREPROSCAN_PATH . $js_rel;

        if (file_exists($target_bundle_path)) {
            $server_info = [];
            try {
                $server_info = \WebCareProScanner\System\ServerInfo::get_info(false);
            } catch (\Throwable $e) {
                $server_info = [
                    'php' => ['version' => PHP_VERSION],
                    'wordpress' => ['version' => $GLOBALS['wp_version'] ?? ''],
                ];
            }

            $wp_tz = function_exists('wp_timezone') ? wp_timezone() : new \DateTimeZone(get_option('timezone_string') ?: 'UTC');
            $wp_tz_offset = $wp_tz->getOffset(new \DateTime('now', new \DateTimeZone('UTC')));

            // Fetch active administrators for reassignment selection
            $admin_users_raw = get_users([
                'role'    => 'administrator',
                'orderby' => 'display_name',
                'order'   => 'ASC',
                'fields'  => ['ID', 'user_login', 'display_name', 'user_email'],
            ]);
            $admin_users_list = [];
            foreach ($admin_users_raw as $admin_obj) {
                $admin_users_list[] = [
                    'id'           => (int) $admin_obj->ID,
                    'user_login'   => $admin_obj->user_login,
                    'display_name' => $admin_obj->display_name ?: $admin_obj->user_login,
                    'user_email'   => $admin_obj->user_email,
                ];
            }

            wp_enqueue_script('webcare-pro-app', $js_url, $deps, $version, true);
            wp_localize_script('webcare-pro-app', 'webcareScannerSettings', [
                'root'            => esc_url_raw(rest_url('webcare-pro-security/v1')),
                'nonce'           => wp_create_nonce('wp_rest'),
                'siteUrl'         => get_site_url(),
                'siteName'        => wp_specialchars_decode(get_bloginfo('name'), ENT_QUOTES),
                'initialTab'      => $active_tab,
                'version'         => WEBCAREPROSCAN_VERSION,
                'currentUserId'   => get_current_user_id(),
                'adminUsers'      => $admin_users_list,
                'serverInfo'      => $server_info,
                'timezoneString'  => wp_timezone_string(),
                'timezoneOffset'  => $wp_tz_offset, // in seconds from UTC
                'gmtOffset'       => (float) get_option('gmt_offset', 0),
                'siteTime'           => current_time('mysql'),
                'isTemporarySupport' => false,
                'assetsUrl'          => esc_url_raw(WEBCAREPROSCAN_URL . 'assets/'),
                'logoPngUrl'         => esc_url_raw(WEBCAREPROSCAN_URL . 'assets/logo.png'),
                'logo3dUrl'          => esc_url_raw(WEBCAREPROSCAN_URL . 'assets/webcare-original-logo-3d.jpg'),
                'emblem3dUrl'        => esc_url_raw(WEBCAREPROSCAN_URL . 'assets/logo.png'),
            ]);
        }

        if (!empty($css_rel) && file_exists(WEBCAREPROSCAN_PATH . $css_rel)) {
            $css_ver = (string) filemtime(WEBCAREPROSCAN_PATH . $css_rel);
            wp_enqueue_style('webcare-pro-style', $css_url, ['webcare-global-style'], $css_ver);
        }
    }

    /**
     * Add "Settings" action link beside "Deactivate" on wp-admin/plugins.php
     *
     * @param array $actions
     * @return array
     */
    public static function add_plugin_action_links(array $actions): array {
        $settings_url = admin_url('admin.php?page=webcare-pro-settings');
        $settings_link = '<a href="' . esc_url($settings_url) . '">' . esc_html__('Settings', 'webcare-pro-security') . '</a>';

        $new_actions = [];
        $placed = false;

        foreach ($actions as $key => $action) {
            $new_actions[$key] = $action;
            if ($key === 'deactivate' || $key === 'activate') {
                $new_actions['settings'] = $settings_link;
                $placed = true;
            }
        }

        if (!$placed) {
            $new_actions['settings'] = $settings_link;
        }

        return $new_actions;
    }

    /**
     * Enqueue custom admin CSS for official branding logo in sidebar and plugins page
     */
    public static function enqueue_brand_styles(): void {
        $logo_url = self::get_menu_icon();
        $custom_css = "
            /* WebCare Pro Security - Sidebar Menu Icon */
            #adminmenu #toplevel_page_webcare-pro-security .wp-menu-image img {
                width: 20px !important;
                height: 20px !important;
                padding: 6px 0 0 !important;
                object-fit: contain !important;
                border-radius: 4px !important;
                transition: transform 0.15s ease-in-out !important;
            }
            #adminmenu #toplevel_page_webcare-pro-security .wp-menu-image.svg {
                background-repeat: no-repeat;
                background-position: center;
                background-size: 20px 20px;
                opacity: 0.88;
                transition: transform 0.15s ease-in-out, opacity 0.15s ease-in-out;
            }
            #adminmenu #toplevel_page_webcare-pro-security:hover .wp-menu-image img,
            #adminmenu #toplevel_page_webcare-pro-security.wp-has-current-submenu .wp-menu-image img,
            #adminmenu #toplevel_page_webcare-pro-security:hover .wp-menu-image.svg,
            #adminmenu #toplevel_page_webcare-pro-security.wp-has-current-submenu .wp-menu-image.svg {
                opacity: 1;
                transform: scale(1.1);
            }
            /* WebCare Pro Security - Plugins List Page Brand Logo */
            .plugins tr[data-plugin*=\"webcare-pro-security.php\"] .plugin-title strong::before {
                content: \"\";
                display: inline-block;
                vertical-align: -4px;
                width: 20px;
                height: 20px;
                margin-right: 8px;
                background: url(\"" . esc_attr($logo_url) . "\") no-repeat center center;
                background-size: contain;
                border-radius: 4px;
            }
        ";

        wp_register_style('webcare-admin-brand', false, [], defined('WEBCAREPROSCAN_VERSION') ? WEBCAREPROSCAN_VERSION : '1.0.0');
        wp_enqueue_style('webcare-admin-brand');
        wp_add_inline_style('webcare-admin-brand', $custom_css);
    }

    /**
     * Render an emergency 1-click restore notice across wp-admin (including users.php)
     * if any backed-up administrator accounts are missing from the WordPress database.
     */
    public static function render_user_recovery_notice() {
        if (!current_user_can('manage_options')) {
            return;
        }

        // Show confirmation notice if redirected after restoration
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        if (!empty($_GET['webcareproscan_restored'])) {
            // phpcs:ignore WordPress.Security.NonceVerification.Recommended
            $count = (int) sanitize_text_field(wp_unslash($_GET['webcareproscan_restored']));
            echo '<div class="notice notice-success is-dismissible" style="padding: 12px 18px; border-left: 4px solid #16a34a; background: #f0fdf4;">';
            echo '<p style="margin: 0; font-size: 13px; color: #14532d;">';
            echo '<strong>' . esc_html__('WebCare Pro Security:', 'webcare-pro-security') . '</strong> ';
            /* translators: %d: count of restored administrator accounts */
            echo esc_html(sprintf(__('Successfully restored %d administrator account(s) to the WordPress database with full original capabilities and passwords.', 'webcare-pro-security'), $count));
            echo '</p></div>';
            return;
        }

        $mgr = new \WebCareProScanner\WordPress\UserRemediationManager();
        $missing_users = $mgr->get_missing_user_backups();

        if (empty($missing_users)) {
            return;
        }

        $nonce = wp_create_nonce('webcareproscan_restore_users_action');
        $restore_url = add_query_arg([
            'webcareproscan_action' => 'restore_all_users',
            '_wpnonce'       => $nonce,
        ], admin_url('users.php'));

        $dismiss_url = add_query_arg([
            'webcareproscan_action' => 'dismiss_all_users',
            '_wpnonce'       => $nonce,
        ], admin_url('users.php'));

        $names = array_map(fn($u) => '<code style="background: #e2e8f0; font-weight: 700;">' . esc_html($u['user_login']) . '</code>', $missing_users);
        $names_str = implode(', ', $names);

        $ajax_dismiss_nonce = wp_create_nonce('webcareproscan_dismiss_quarantined_notice_nonce');

        echo '<div id="webcare-quarantined-users-notice" class="notice notice-warning is-dismissible" data-nonce="' . esc_attr($ajax_dismiss_nonce) . '" style="padding: 14px 18px; border-left: 4px solid #22c55e; background: #f0fdf4; box-shadow: 0 1px 3px rgba(0,0,0,0.05);">';
        echo '<div style="display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 10px;">';
        echo '<div style="font-size: 13px; color: #14532d;">';
        echo '<strong>' . esc_html__('WebCare Pro Security:', 'webcare-pro-security') . '</strong> ';
        echo wp_kses(
            sprintf(
                /* translators: %1$d: count, %2$s: usernames */
                esc_html__('Found %1$d quarantined administrator account(s) (%2$s) available in safety backups.', 'webcare-pro-security'),
                count($missing_users),
                $names_str
            ),
            ['code' => ['style' => []]]
        );
        echo '</div>';
        echo '<div style="display: flex; align-items: center; gap: 8px;">';
        echo '<a href="' . esc_url($restore_url) . '" class="button button-primary" style="background: #16a34a; border-color: #15803d; font-weight: 700; padding: 2px 14px; box-shadow: 0 2px 4px rgba(22,163,74,0.2);">';
        echo esc_html__('1-Click Restore All Admin Accounts', 'webcare-pro-security');
        echo '</a>';
        echo '<a href="' . esc_url($dismiss_url) . '" class="button" style="color: #475569; font-weight: 600; padding: 2px 12px;" title="' . esc_attr__('Acknowledge intentional removal and permanently silence this alert', 'webcare-pro-security') . '">';
        echo esc_html__('Dismiss Notice', 'webcare-pro-security');
        echo '</a>';
        echo '</div>';
        echo '</div>';
        echo '</div>';

        // AJAX script to permanently persist dismissal when clicking native WP notice "X" close button
        $notice_dismiss_js = '
        (function() {
            var notice = document.getElementById("webcare-quarantined-users-notice");
            if (!notice) return;
            notice.addEventListener("click", function(e) {
                var btn = e.target.closest(".notice-dismiss");
                if (!btn) return;
                var nonce = notice.getAttribute("data-nonce");
                if (!nonce || typeof ajaxurl === "undefined") return;

                var data = new URLSearchParams();
                data.append("action", "webcareproscan_dismiss_quarantined_notice");
                data.append("nonce", nonce);

                fetch(ajaxurl, {
                    method: "POST",
                    body: data,
                    headers: { "Content-Type": "application/x-www-form-urlencoded" }
                }).catch(function() {});
            });
        })();
        ';
        wp_register_script('webcare-quarantined-notice-js', false, ['common'], defined('WEBCAREPROSCAN_VERSION') ? WEBCAREPROSCAN_VERSION : '1.0.0', true);
        wp_enqueue_script('webcare-quarantined-notice-js');
        wp_add_inline_script('webcare-quarantined-notice-js', $notice_dismiss_js);
    }

    /**
     * Process 1-click restore or dismiss request initiated from the WordPress admin notice.
     */
    public static function handle_user_recovery_action() {
        if (!current_user_can('manage_options')) {
            return;
        }

        if (isset($_GET['webcareproscan_action']) && $_GET['webcareproscan_action'] === 'restore_all_users') {
            check_admin_referer('webcareproscan_restore_users_action');

            $mgr = new \WebCareProScanner\WordPress\UserRemediationManager();
            $res = $mgr->restore_all_user_backups();
            $count = count($res['restored'] ?? []);

            wp_safe_redirect(add_query_arg(['webcareproscan_restored' => $count], admin_url('users.php')));
            exit;
        }

        if (isset($_GET['webcareproscan_action']) && $_GET['webcareproscan_action'] === 'dismiss_all_users') {
            check_admin_referer('webcareproscan_restore_users_action');

            $mgr = new \WebCareProScanner\WordPress\UserRemediationManager();
            $mgr->dismiss_all_missing_backups();

            $redirect_url = remove_query_arg(['webcareproscan_action', '_wpnonce']);
            wp_safe_redirect($redirect_url);
            exit;
        }
    }

    /**
     * Handle first-time plugin activation redirect to the Onboarding & Protection Quickstart Wizard.
     */
    public static function handle_wizard_activation_redirect() {
        if (!current_user_can('manage_options')) {
            return;
        }

        if (get_option('webcareproscan_activation_redirect_wizard', false)) {
            delete_option('webcareproscan_activation_redirect_wizard');

            if (is_network_admin() || wp_doing_ajax() || (defined('REST_REQUEST') && REST_REQUEST)) {
                return;
            }

            // phpcs:ignore WordPress.Security.NonceVerification.Recommended
            $page = isset($_GET['page']) ? sanitize_key(wp_unslash($_GET['page'])) : '';
            if ($page !== 'webcare-pro-wizard') {
                wp_safe_redirect(admin_url('admin.php?page=webcare-pro-wizard'));
                exit;
            }
        }
    }

    /**
     * Handle AJAX persistent dismissal when clicking native notice close button.
     */
    public static function ajax_dismiss_quarantined_notice() {
        check_ajax_referer('webcareproscan_dismiss_quarantined_notice_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => __('Unauthorized permission.', 'webcare-pro-security')], 403);
        }

        $mgr = new \WebCareProScanner\WordPress\UserRemediationManager();
        $dismissed = $mgr->dismiss_all_missing_backups();

        wp_send_json_success(['dismissed_count' => $dismissed]);
    }

    /**
     * Handle AJAX update for uninstall purge preference when user confirms in modal.
     */
    public static function ajax_set_uninstall_purge() {
        check_ajax_referer('webcareproscan_uninstall_prompt_nonce', 'nonce');

        if (!current_user_can('delete_plugins')) {
            wp_send_json_error(['message' => __('Unauthorized permission.', 'webcare-pro-security')], 403);
        }

        $purge = !empty($_POST['purge']);
        $settings = \WebCareProScanner\System\SettingsManager::get_settings();
        $settings['delete_data_on_uninstall'] = $purge;
        \WebCareProScanner\System\SettingsManager::save_settings($settings);

        wp_send_json_success(['purge' => $purge]);
    }

    /**
     * Render the interactive modal on wp-admin/plugins.php when deleting WebCare Pro Security.
     * Reminds administrators about quarantined malware, firewall rules, and scan logs,
     * defaulting to KEEP ALL DATA.
     */
    public static function render_plugins_uninstall_modal() {
        $screen = function_exists('get_current_screen') ? get_current_screen() : null;
        if (!$screen || $screen->id !== 'plugins' || !current_user_can('delete_plugins')) {
            return;
        }

        $nonce = wp_create_nonce('webcareproscan_uninstall_prompt_nonce');
        $settings = \WebCareProScanner\System\SettingsManager::get_settings();
        $is_purge_checked = !empty($settings['delete_data_on_uninstall']);
        ?>
        <!-- WebCare Pro Security Uninstall Confirmation Modal -->
        <div id="webcare-uninstall-modal-overlay" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(15, 23, 42, 0.6); z-index: 100050; backdrop-filter: blur(3px); align-items: center; justify-content: center;">
            <div id="webcare-uninstall-modal" style="background: #ffffff; border-radius: 12px; width: 100%; max-width: 520px; box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.25), 0 8px 10px -6px rgba(0, 0, 0, 0.2); overflow: hidden; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen-Sans, Ubuntu, Cantarell, sans-serif; border: 1px solid #e2e8f0; animation: webcareFadeIn 0.2s ease-out;">
                
                <!-- Header -->
                <div style="padding: 20px 24px; background: #f8fafc; border-bottom: 1px solid #e2e8f0; display: flex; align-items: center; gap: 12px;">
                    <div style="width: 38px; height: 38px; border-radius: 8px; background: #fee2e2; color: #dc2626; display: flex; align-items: center; justify-content: center; flex-shrink: 0;">
                        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
                            <line x1="12" y1="8" x2="12" y2="12"/>
                            <line x1="12" y1="16" x2="12.01" y2="16"/>
                        </svg>
                    </div>
                    <div>
                        <h3 style="margin: 0; font-size: 16px; font-weight: 800; color: #0f172a; line-height: 1.3;">
                            <?php echo esc_html__('Uninstalling WebCare Pro Security & Firewall', 'webcare-pro-security'); ?>
                        </h3>
                        <p style="margin: 2px 0 0 0; font-size: 12px; color: #64748b;">
                            <?php echo esc_html__('Please choose your data retention preference before deletion.', 'webcare-pro-security'); ?>
                        </p>
                    </div>
                </div>

                <!-- Body Content -->
                <div style="padding: 22px 24px; color: #334155; font-size: 13.5px; line-height: 1.55;">
                    <p style="margin: 0 0 16px 0;">
                        <?php echo esc_html__('You are deleting WebCare Pro Security & Firewall. If you reinstall the plugin later, keeping your data ensures your quarantined files and configurations remain intact.', 'webcare-pro-security'); ?>
                    </p>

                    <!-- Option 1: Retain Data (Recommended Default) -->
                    <label style="display: flex; align-items: flex-start; gap: 12px; padding: 12px 14px; border-radius: 8px; border: 2px solid #10b981; background: #f0fdf4; cursor: pointer; margin-bottom: 12px;">
                        <input type="radio" name="webcareproscan_uninstall_choice" value="retain" <?php checked(!$is_purge_checked); ?> style="margin-top: 3px; accent-color: #059669;">
                        <div>
                            <div style="font-weight: 700; color: #065f46; font-size: 13.5px; display: flex; align-items: center; gap: 6px;">
                                <span><?php echo esc_html__('Keep All Data & Quarantine Vault', 'webcare-pro-security'); ?></span>
                                <span style="background: #10b981; color: #ffffff; font-size: 10px; font-weight: 800; text-transform: uppercase; padding: 1px 6px; border-radius: 4px;"><?php echo esc_html__('Recommended', 'webcare-pro-security'); ?></span>
                            </div>
                            <div style="font-size: 12px; color: #047857; margin-top: 2px;">
                                <?php echo esc_html__('Preserves quarantined malware files, firewall bypass rules, scan history, and custom settings across reinstalls.', 'webcare-pro-security'); ?>
                            </div>
                        </div>
                    </label>

                    <!-- Option 2: Full Purge -->
                    <label style="display: flex; align-items: flex-start; gap: 12px; padding: 12px 14px; border-radius: 8px; border: 1px solid #e2e8f0; background: #ffffff; cursor: pointer;">
                        <input type="radio" name="webcareproscan_uninstall_choice" value="purge" <?php checked($is_purge_checked); ?> style="margin-top: 3px; accent-color: #dc2626;">
                        <div>
                            <div style="font-weight: 700; color: #0f172a; font-size: 13.5px;">
                                <?php echo esc_html__('Completely Purge All Data & Tables', 'webcare-pro-security'); ?>
                            </div>
                            <div style="font-size: 12px; color: #dc2626; margin-top: 2px;">
                                <?php echo esc_html__('Permanently drops all database tables and deletes quarantined files, virtual patches, and backups.', 'webcare-pro-security'); ?>
                            </div>
                        </div>
                    </label>
                </div>

                <!-- Footer Buttons -->
                <div style="padding: 16px 24px; background: #f8fafc; border-top: 1px solid #e2e8f0; display: flex; justify-content: flex-end; gap: 10px;">
                    <button type="button" id="webcare-uninstall-cancel-btn" class="button" style="padding: 4px 14px; font-size: 13px; font-weight: 600;">
                        <?php echo esc_html__('Cancel', 'webcare-pro-security'); ?>
                    </button>
                    <button type="button" id="webcare-uninstall-confirm-btn" class="button button-primary" style="background: #dc2626; border-color: #b91c1c; padding: 4px 18px; font-size: 13px; font-weight: 700; box-shadow: 0 2px 4px rgba(220, 38, 38, 0.25);">
                        <?php echo esc_html__('Proceed with Deletion', 'webcare-pro-security'); ?>
                    </button>
                </div>
            </div>
        </div>
        <?php
        $saving_label = esc_js(__('Saving preference...', 'webcare-pro-security'));
        $uninstall_modal_js = '
        (function() {
            var targetDeleteLink = null;
            var overlay = document.getElementById("webcare-uninstall-modal-overlay");
            var cancelBtn = document.getElementById("webcare-uninstall-cancel-btn");
            var confirmBtn = document.getElementById("webcare-uninstall-confirm-btn");

            if (!overlay || !cancelBtn || !confirmBtn) return;

            // Intercept click on the "Delete" action link for this plugin
            document.addEventListener("click", function(e) {
                var link = e.target.closest("a");
                if (!link) return;

                var href = link.getAttribute("href") || "";
                var isDelete = href.indexOf("action=delete-selected") !== -1 || (link.classList.contains("delete") && href.indexOf("plugins.php") !== -1);
                var isWebCarePlugin = href.indexOf("webcare-pro-security") !== -1;

                if (!isWebCarePlugin) {
                    var row = link.closest("tr[data-plugin*=\"webcare-\"]");
                    if (row) isWebCarePlugin = true;
                }

                if (isDelete && isWebCarePlugin) {
                    e.preventDefault();
                    e.stopImmediatePropagation();
                    targetDeleteLink = href;
                    overlay.style.display = "flex";
                }
            }, true);

            // Cancel button
            cancelBtn.addEventListener("click", function() {
                overlay.style.display = "none";
                targetDeleteLink = null;
            });

            // Close on backdrop click
            overlay.addEventListener("click", function(e) {
                if (e.target === overlay) {
                    overlay.style.display = "none";
                    targetDeleteLink = null;
                }
            });

            // Confirm & Save preference via AJAX before proceeding
            confirmBtn.addEventListener("click", function() {
                var selected = document.querySelector("input[name=\"webcareproscan_uninstall_choice\"]:checked");
                var shouldPurge = selected ? selected.value === "purge" : false;

                confirmBtn.disabled = true;
                confirmBtn.innerText = "' . $saving_label . '";

                var data = new URLSearchParams();
                data.append("action", "webcareproscan_set_uninstall_purge");
                data.append("nonce", "' . esc_js($nonce) . '");
                data.append("purge", shouldPurge ? "1" : "0");

                fetch(ajaxurl, {
                    method: "POST",
                    body: data,
                    headers: { "Content-Type": "application/x-www-form-urlencoded" }
                }).then(function() {
                    // Navigate to WordPress native delete confirmation
                    if (targetDeleteLink) {
                        window.location.href = targetDeleteLink;
                    } else {
                        overlay.style.display = "none";
                    }
                }).catch(function() {
                    if (targetDeleteLink) {
                        window.location.href = targetDeleteLink;
                    }
                });
            });
        })();
        ';

        wp_register_script('webcare-uninstall-modal-js', false, ['common'], defined('WEBCAREPROSCAN_VERSION') ? WEBCAREPROSCAN_VERSION : '1.0.0', true);
        wp_enqueue_script('webcare-uninstall-modal-js');
        wp_add_inline_script('webcare-uninstall-modal-js', $uninstall_modal_js);
    }
}

