<?php
namespace WebCareProScanner\Notifications;

use WebCareProScanner\System\SettingsManager;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * DevSecOps Chat & Automation Webhook Service
 *
 * Dispatches real-time security alerts and automated tickets to:
 * - Slack (Block Kit interactive cards)
 * - Discord (Rich Embed cards)
 * - ClickUp (Task & notification webhooks)
 * - Asana (Project task creation & automation webhooks)
 * - Generic Automations (Zapier, Make.com, n8n, custom webhooks)
 */
class WebhookService {

    const COLOR_CRITICAL = '#dc2626'; // 14428198
    const COLOR_WARNING  = '#f59e0b'; // 16096779
    const COLOR_SUCCESS  = '#10b981'; // 1096065
    const COLOR_INFO     = '#0284c7'; // 164999

    const CRON_HOOK_DISPATCH_QUEUE = 'webcareproscan_dispatch_webhook_queue';

    /**
     * Initialize WebhookService async cron handler.
     */
    public static function init(): void {
        add_action(self::CRON_HOOK_DISPATCH_QUEUE, [__CLASS__, 'process_queued_webhooks']);
    }

    /**
     * Enqueue a webhook alert for asynchronous delivery to protect live request paths.
     *
     * @param string $url
     * @param array  $payload
     * @param string $platform_name
     * @return void
     */
    public static function enqueue_webhook(string $url, array $payload, string $platform_name): void {
        $queue = get_option('webcareproscan_async_webhook_queue', []);
        if (!is_array($queue)) {
            $queue = [];
        }

        // Bounded queue ceiling to prevent option bloat under DDoS
        if (count($queue) >= 50) {
            array_shift($queue);
        }

        $queue[] = [
            'url'           => $url,
            'payload'       => $payload,
            'platform_name' => $platform_name,
            'enqueued_at'   => time(),
        ];

        update_option('webcareproscan_async_webhook_queue', $queue, false);

        if (!wp_next_scheduled(self::CRON_HOOK_DISPATCH_QUEUE)) {
            wp_schedule_single_event(time() + 5, self::CRON_HOOK_DISPATCH_QUEUE);
        }
    }

    /**
     * Process asynchronous queue items via scheduled task.
     */
    public static function process_queued_webhooks(): void {
        $queue = get_option('webcareproscan_async_webhook_queue', []);
        if (!is_array($queue) || empty($queue)) {
            return;
        }

        update_option('webcareproscan_async_webhook_queue', [], false);

        foreach ($queue as $item) {
            if (empty($item['url']) || !is_array($item['payload'])) {
                continue;
            }
            self::post_webhook($item['url'], $item['payload'], $item['platform_name'] ?? 'Webhook', false);
        }
    }

    /**
     * Dispatch a test alert to verify webhook integration
     */
    public static function send_test(string $platform, ?string $custom_url = null): array {
        $settings = SettingsManager::get_settings();
        $site_name = wp_specialchars_decode(get_bloginfo('name'), ENT_QUOTES) ?: 'WordPress';
        $site_url  = get_site_url();
        $dashboard_url = admin_url('admin.php?page=webcare-pro-security');
        $plugin_version = defined('WEBCAREPROSCAN_VERSION') ? WEBCAREPROSCAN_VERSION : '2.7.1';

        if ($platform === 'slack') {
            $url = !empty($custom_url) ? trim($custom_url) : ($settings['slack_webhook_url'] ?? '');
            if (empty($url)) {
                return ['success' => false, 'code' => 400, 'message' => __('No Slack Webhook URL provided.', 'webcare-pro-security')];
            }

            $payload = [
                'text' => "🧪 [TEST] WebCare Pro Security alert for {$site_name}",
                'attachments' => [
                    [
                        'color' => self::COLOR_SUCCESS,
                        'blocks' => [
                            [
                                'type' => 'header',
                                'text' => ['type' => 'plain_text', 'text' => '🧪 WebCare Pro Security Webhook Test', 'emoji' => true]
                            ],
                            [
                                'type' => 'section',
                                'text' => [
                                    'type' => 'mrkdwn',
                                    'text' => "*Site:* <{$site_url}|{$site_name}>\n*Status:* Webhook delivery test successful!\n*Security Engine:* WebCare Pro Security & Firewall v{$plugin_version}"
                                ]
                            ],
                            [
                                'type' => 'actions',
                                'elements' => [
                                    [
                                        'type' => 'button',
                                        'text' => ['type' => 'plain_text', 'text' => 'Open Security Dashboard'],
                                        'url' => $dashboard_url,
                                        'style' => 'primary'
                                    ]
                                ]
                            ]
                        ]
                    ]
                ]
            ];

            return self::post_webhook($url, $payload, 'Slack', true);

        } elseif ($platform === 'discord') {
            $url = !empty($custom_url) ? trim($custom_url) : ($settings['discord_webhook_url'] ?? '');
            if (empty($url)) {
                return ['success' => false, 'code' => 400, 'message' => __('No Discord Webhook URL provided.', 'webcare-pro-security')];
            }

            $payload = [
                'username' => 'WebCare Pro Security Bot',
                'embeds' => [
                    [
                        'title' => '🧪 WebCare Pro Security Webhook Test',
                        'description' => "Real-time security alert integration with **{$site_name}** is operational.",
                        'url' => $dashboard_url,
                        'color' => 1096065, // Emerald green
                        'fields' => [
                            ['name' => 'Site URL', 'value' => $site_url, 'inline' => true],
                            ['name' => 'Engine Version', 'value' => 'v' . $plugin_version, 'inline' => true],
                            ['name' => 'Status', 'value' => 'Connected & Ready', 'inline' => true],
                        ],
                        'footer' => ['text' => 'WebCare Pro DevSecOps Security Hub'],
                        'timestamp' => gmdate('Y-m-d\TH:i:s\Z'),
                    ]
                ]
            ];

            return self::post_webhook($url, $payload, 'Discord', true);

        } elseif ($platform === 'clickup') {
            $url = !empty($custom_url) ? trim($custom_url) : ($settings['clickup_webhook_url'] ?? '');
            if (empty($url)) {
                return ['success' => false, 'code' => 400, 'message' => __('No ClickUp Webhook URL provided.', 'webcare-pro-security')];
            }

            $payload = [
                'name'         => "🧪 [TEST] WebCare Pro Security Test Task - {$site_name}",
                'content'      => "Verification task generated by WebCare Pro Security v{$plugin_version}.\n\n- **Site:** {$site_name} ({$site_url})\n- **Dashboard:** {$dashboard_url}\n- **Timestamp:** " . current_time('mysql'),
                'description'  => "Verification task generated by WebCare Pro Security v{$plugin_version} for {$site_name}.",
                'text'         => "🧪 [TEST] WebCare Pro Security Test Task created for {$site_name}",
                'event'        => 'test_alert',
                'site_name'    => $site_name,
                'site_url'     => $site_url,
                'priority'     => 3, // Normal
                'status'       => 'to do',
                'tags'         => ['security', 'webcare-pro-security', 'test'],
            ];

            return self::post_webhook($url, $payload, 'ClickUp', true);

        } elseif ($platform === 'asana') {
            $url = !empty($custom_url) ? trim($custom_url) : ($settings['asana_webhook_url'] ?? '');
            if (empty($url)) {
                return ['success' => false, 'code' => 400, 'message' => __('No Asana Webhook URL provided.', 'webcare-pro-security')];
            }

            $payload = [
                'name'      => "🧪 [TEST] WebCare Pro Security Task - {$site_name}",
                'notes'     => "Automated security test task dispatched from WebCare Pro Security v{$plugin_version}.\n\nSite: {$site_name} ({$site_url})\nSecurity Dashboard: {$dashboard_url}\nDelivered at: " . current_time('mysql'),
                'text'      => "🧪 [TEST] WebCare Pro Security Task - {$site_name}",
                'event'     => 'test_alert',
                'site_name' => $site_name,
                'site_url'  => $site_url,
                'data'      => [
                    'name'  => "🧪 [TEST] WebCare Pro Security Task - {$site_name}",
                    'notes' => "Automated security test task dispatched from WebCare Pro Security v{$plugin_version}.\n\nSite: {$site_name} ({$site_url})\nDashboard: {$dashboard_url}",
                ],
            ];

            return self::post_webhook($url, $payload, 'Asana', true);

        } elseif ($platform === 'generic') {
            $url = !empty($custom_url) ? trim($custom_url) : ($settings['generic_webhook_url'] ?? '');
            if (empty($url)) {
                return ['success' => false, 'code' => 400, 'message' => __('No Automation Webhook URL provided.', 'webcare-pro-security')];
            }

            $payload = [
                'event'         => 'test_alert',
                'site_name'     => $site_name,
                'site_url'      => $site_url,
                'dashboard_url' => $dashboard_url,
                'version'       => $plugin_version,
                'severity'      => 'info',
                'title'         => "🧪 WebCare Pro Security Webhook Test",
                'message'       => "Automation webhook delivery test from {$site_name} was successful.",
                'timestamp'     => time(),
                'datetime'      => gmdate('c'),
            ];

            return self::post_webhook($url, $payload, 'Automation Webhook', true);
        }

        return ['success' => false, 'code' => 400, 'message' => __('Unsupported platform.', 'webcare-pro-security')];
    }

    /**
     * Dispatch Scan Completion Alert to all configured channels & automations
     */
    public static function send_scan_alert(int $scan_id, int $total_issues, int $risk_score, string $target, array $issues = []) {
        $settings = SettingsManager::get_settings();
        $has_slack   = !empty($settings['slack_enabled']) && !empty($settings['slack_webhook_url']);
        $has_discord = !empty($settings['discord_enabled']) && !empty($settings['discord_webhook_url']);
        $has_clickup = !empty($settings['clickup_enabled']) && !empty($settings['clickup_webhook_url']);
        $has_asana   = !empty($settings['asana_enabled']) && !empty($settings['asana_webhook_url']);
        $has_generic = !empty($settings['generic_webhook_enabled']) && !empty($settings['generic_webhook_url']);

        if (!$has_slack && !$has_discord && !$has_clickup && !$has_asana && !$has_generic) {
            return;
        }

        $critical_count = 0;
        $high_count     = 0;
        foreach ($issues as $iss) {
            if (($iss['severity'] ?? '') === 'critical') $critical_count++;
            elseif (($iss['severity'] ?? '') === 'high') $high_count++;
        }

        $notify_on_critical = !empty($settings['webhook_notify_on_critical']);
        $notify_on_finish   = !empty($settings['webhook_notify_on_scan_finish']);

        if (!$notify_on_finish && (!($notify_on_critical && ($critical_count > 0 || $high_count > 0)))) {
            return;
        }

        $site_name = wp_specialchars_decode(get_bloginfo('name'), ENT_QUOTES) ?: 'WordPress';
        $site_url  = get_site_url();
        $dashboard_url = admin_url('admin.php?page=webcare-pro-security');
        $plugin_version = defined('WEBCAREPROSCAN_VERSION') ? WEBCAREPROSCAN_VERSION : '2.7.1';

        $is_danger = ($critical_count > 0 || $high_count > 0);
        $color_hex = $is_danger ? self::COLOR_CRITICAL : ($total_issues > 0 ? self::COLOR_WARNING : self::COLOR_SUCCESS);
        $color_int = $is_danger ? 14428198 : ($total_issues > 0 ? 16096779 : 1096065);
        $status_emoji = $is_danger ? '🚨' : ($total_issues > 0 ? '⚠️' : '✅');

        // 1. Dispatch Slack
        if ($has_slack) {
            $slack_fields = [
                ['type' => 'mrkdwn', 'text' => "*Risk Score:*\n{$risk_score}/100"],
                ['type' => 'mrkdwn', 'text' => "*Total Findings:*\n{$total_issues}"],
                ['type' => 'mrkdwn', 'text' => "*Critical Threats:*\n{$critical_count}"],
                ['type' => 'mrkdwn', 'text' => "*High Warnings:*\n{$high_count}"],
            ];

            $slack_payload = [
                'text' => "{$status_emoji} Security Scan #{$scan_id} finished on {$site_name} ({$total_issues} findings)",
                'attachments' => [
                    [
                        'color' => $color_hex,
                        'blocks' => [
                            [
                                'type' => 'header',
                                'text' => ['type' => 'plain_text', 'text' => "{$status_emoji} WebCare Pro Security Scan Report", 'emoji' => true]
                            ],
                            [
                                'type' => 'section',
                                'text' => [
                                    'type' => 'mrkdwn',
                                    'text' => "*Site:* <{$site_url}|{$site_name}>\n*Target:* `{$target}` | *Scan ID:* `#{$scan_id}`"
                                ]
                            ],
                            [
                                'type' => 'section',
                                'fields' => $slack_fields
                            ],
                            [
                                'type' => 'actions',
                                'elements' => [
                                    [
                                        'type' => 'button',
                                        'text' => ['type' => 'plain_text', 'text' => 'Review Findings & Auto-Cure'],
                                        'url' => $dashboard_url,
                                        'style' => $is_danger ? 'danger' : 'primary'
                                    ]
                                ]
                            ]
                        ]
                    ]
                ]
            ];

            self::post_webhook($settings['slack_webhook_url'], $slack_payload, 'Slack');
        }

        // 2. Dispatch Discord
        if ($has_discord) {
            $discord_payload = [
                'username' => 'WebCare Pro Security Bot',
                'embeds' => [
                    [
                        'title' => "{$status_emoji} Security Scan #{$scan_id} Completed",
                        'description' => "Audit concluded on **{$site_name}** with **{$total_issues}** findings recorded.",
                        'url' => $dashboard_url,
                        'color' => $color_int,
                        'fields' => [
                            ['name' => 'Risk Score', 'value' => "{$risk_score}/100", 'inline' => true],
                            ['name' => 'Critical', 'value' => (string) $critical_count, 'inline' => true],
                            ['name' => 'High', 'value' => (string) $high_count, 'inline' => true],
                            ['name' => 'Target Mode', 'value' => $target, 'inline' => true],
                            ['name' => 'Site URL', 'value' => $site_url, 'inline' => true],
                        ],
                        'footer' => ['text' => 'WebCare Pro Security Scanner'],
                        'timestamp' => gmdate('Y-m-d\TH:i:s\Z'),
                    ]
                ]
            ];

            self::post_webhook($settings['discord_webhook_url'], $discord_payload, 'Discord');
        }

        // 3. Dispatch ClickUp Task
        if ($has_clickup) {
            $priority = $is_danger ? 1 : ($total_issues > 0 ? 2 : 4); // 1 = Urgent, 2 = High, 4 = Low
            $task_title = "{$status_emoji} [SECURITY] Scan #{$scan_id} on {$site_name}: {$total_issues} Issues (Risk: {$risk_score}/100)";
            $description = "Security scan #{$scan_id} concluded on {$site_name}.\n\n" .
                "- **Site URL:** {$site_url}\n" .
                "- **Target Scope:** {$target}\n" .
                "- **Risk Score:** {$risk_score}/100\n" .
                "- **Critical Threats:** {$critical_count}\n" .
                "- **High Warnings:** {$high_count}\n" .
                "- **Total Findings:** {$total_issues}\n\n" .
                "👉 Review & Auto-Cure: {$dashboard_url}";

            $clickup_payload = [
                'name'        => $task_title,
                'content'     => $description,
                'description' => $description,
                'text'        => $task_title,
                'priority'    => $priority,
                'status'      => 'to do',
                'tags'        => ['security', 'scan-alert', $is_danger ? 'critical' : 'routine'],
                'event'       => 'scan_completed',
                'site_name'   => $site_name,
                'site_url'    => $site_url,
                'scan_id'     => $scan_id,
                'risk_score'  => $risk_score,
                'total_issues'=> $total_issues,
            ];

            self::post_webhook($settings['clickup_webhook_url'], $clickup_payload, 'ClickUp');
        }

        // 4. Dispatch Asana Task
        if ($has_asana) {
            $task_title = "{$status_emoji} [SECURITY] Scan #{$scan_id} on {$site_name}: {$total_issues} Issues";
            $notes = "Automated Security Audit Report\n\n" .
                "Site: {$site_name} ({$site_url})\n" .
                "Risk Score: {$risk_score}/100\n" .
                "Critical Threats: {$critical_count}\n" .
                "High Warnings: {$high_count}\n" .
                "Total Findings: {$total_issues}\n\n" .
                "Dashboard: {$dashboard_url}";

            $asana_payload = [
                'name'      => $task_title,
                'notes'     => $notes,
                'text'      => $task_title,
                'event'     => 'scan_completed',
                'site_name' => $site_name,
                'site_url'  => $site_url,
                'data'      => [
                    'name'  => $task_title,
                    'notes' => $notes,
                ],
            ];

            self::post_webhook($settings['asana_webhook_url'], $asana_payload, 'Asana');
        }

        // 5. Dispatch Generic Automation Webhook (Zapier, Make, n8n)
        if ($has_generic) {
            $generic_payload = [
                'event'         => 'scan_completed',
                'site_name'     => $site_name,
                'site_url'      => $site_url,
                'dashboard_url' => $dashboard_url,
                'scan_id'       => $scan_id,
                'risk_score'    => $risk_score,
                'target'        => $target,
                'total_issues'  => $total_issues,
                'critical_count'=> $critical_count,
                'high_count'    => $high_count,
                'is_danger'     => $is_danger,
                'status'        => $is_danger ? 'danger' : ($total_issues > 0 ? 'warning' : 'clean'),
                'timestamp'     => time(),
                'datetime'      => gmdate('c'),
            ];

            self::post_webhook($settings['generic_webhook_url'], $generic_payload, 'Automation Webhook');
        }
    }

    /**
     * Dispatch File Integrity Monitoring (FIM) Alert
     */
    public static function send_fim_alert(array $changed_files) {
        $settings = SettingsManager::get_settings();
        if (empty($settings['webhook_notify_on_fim'])) {
            return;
        }

        $has_slack   = !empty($settings['slack_enabled']) && !empty($settings['slack_webhook_url']);
        $has_discord = !empty($settings['discord_enabled']) && !empty($settings['discord_webhook_url']);
        $has_clickup = !empty($settings['clickup_enabled']) && !empty($settings['clickup_webhook_url']);
        $has_asana   = !empty($settings['asana_enabled']) && !empty($settings['asana_webhook_url']);
        $has_generic = !empty($settings['generic_webhook_enabled']) && !empty($settings['generic_webhook_url']);

        if (!$has_slack && !$has_discord && !$has_clickup && !$has_asana && !$has_generic) {
            return;
        }

        $site_name = wp_specialchars_decode(get_bloginfo('name'), ENT_QUOTES) ?: 'WordPress';
        $site_url  = get_site_url();
        $fim_url   = admin_url('admin.php?page=webcare-pro-fim');
        $count     = count($changed_files);

        $sample_paths = array_slice(array_map(function ($f) {
            return '`' . basename($f['relative_path'] ?? $f['file_path'] ?? '') . '`';
        }, $changed_files), 0, 4);
        $sample_str = implode(', ', $sample_paths);

        if ($has_slack) {
            $slack_payload = [
                'text' => "⚠️ [FIM Alert] {$count} modified files detected on {$site_name}",
                'attachments' => [
                    [
                        'color' => self::COLOR_WARNING,
                        'blocks' => [
                            [
                                'type' => 'header',
                                'text' => ['type' => 'plain_text', 'text' => '⚠️ File Integrity Monitor Warning', 'emoji' => true]
                            ],
                            [
                                'type' => 'section',
                                'text' => [
                                    'type' => 'mrkdwn',
                                    'text' => "*Site:* <{$site_url}|{$site_name}>\n*Modified Files:* {$count}\n*Recent Changes:* {$sample_str}"
                                ]
                            ],
                            [
                                'type' => 'actions',
                                'elements' => [
                                    [
                                        'type' => 'button',
                                        'text' => ['type' => 'plain_text', 'text' => 'Inspect Code Diff (FIM)'],
                                        'url' => $fim_url,
                                        'style' => 'primary'
                                    ]
                                ]
                            ]
                        ]
                    ]
                ]
            ];
            self::post_webhook($settings['slack_webhook_url'], $slack_payload, 'Slack');
        }

        if ($has_discord) {
            $discord_payload = [
                'username' => 'WebCare FIM Monitor',
                'embeds' => [
                    [
                        'title' => '⚠️ File Integrity Changes Detected',
                        'description' => "FIM flagged **{$count}** unexpected filesystem modifications on **{$site_name}**.\nSample: {$sample_str}",
                        'url' => $fim_url,
                        'color' => 16096779,
                        'fields' => [
                            ['name' => 'Modified Count', 'value' => (string) $count, 'inline' => true],
                            ['name' => 'Site', 'value' => $site_name, 'inline' => true],
                        ],
                        'footer' => ['text' => 'WebCare File Integrity Monitoring'],
                        'timestamp' => gmdate('Y-m-d\TH:i:s\Z'),
                    ]
                ]
            ];
            self::post_webhook($settings['discord_webhook_url'], $discord_payload, 'Discord');
        }

        if ($has_clickup) {
            $clickup_payload = [
                'name'        => "⚠️ [FIM] {$count} Modified Files Flagged on {$site_name}",
                'content'     => "File Integrity Monitor detected {$count} unexpected file modifications on {$site_name}.\n\nSample files: {$sample_str}\n\nReview diffs: {$fim_url}",
                'description' => "File Integrity Monitor detected {$count} modified files.",
                'priority'    => 2, // High
                'tags'        => ['security', 'fim', 'file-integrity'],
                'event'       => 'fim_modified',
                'site_name'   => $site_name,
                'count'       => $count,
            ];
            self::post_webhook($settings['clickup_webhook_url'], $clickup_payload, 'ClickUp');
        }

        if ($has_asana) {
            $asana_payload = [
                'name'      => "⚠️ [FIM] {$count} Modified Files on {$site_name}",
                'notes'     => "FIM detected {$count} unexpected file modifications.\nSample: {$sample_str}\nInspect FIM: {$fim_url}",
                'data'      => [
                    'name'  => "⚠️ [FIM] {$count} Modified Files on {$site_name}",
                    'notes' => "FIM detected {$count} unexpected file modifications.\nSample: {$sample_str}\nInspect FIM: {$fim_url}",
                ],
            ];
            self::post_webhook($settings['asana_webhook_url'], $asana_payload, 'Asana');
        }

        if ($has_generic) {
            $generic_payload = [
                'event'          => 'fim_modified',
                'site_name'      => $site_name,
                'site_url'       => $site_url,
                'dashboard_url'  => $fim_url,
                'modified_count' => $count,
                'sample_files'   => array_slice($changed_files, 0, 10),
                'timestamp'      => time(),
                'datetime'       => gmdate('c'),
            ];
            self::post_webhook($settings['generic_webhook_url'], $generic_payload, 'Automation Webhook');
        }
    }

    /**
     * Dispatch High-Severity WAF Lite Attack Interception Alert
     */
    public static function send_waf_alert(array $incident) {
        $settings = SettingsManager::get_settings();
        if (empty($settings['webhook_notify_on_waf_block'])) {
            return;
        }

        // Rate-limit WAF webhooks to at most 1 per 60 seconds to avoid spamming team channels during DDoS/floods
        $rate_key = 'webcareproscan_waf_webhook_rate_limit';
        if (get_transient($rate_key)) {
            return;
        }
        set_transient($rate_key, 1, 60);

        $has_slack   = !empty($settings['slack_enabled']) && !empty($settings['slack_webhook_url']);
        $has_discord = !empty($settings['discord_enabled']) && !empty($settings['discord_webhook_url']);
        $has_clickup = !empty($settings['clickup_enabled']) && !empty($settings['clickup_webhook_url']);
        $has_asana   = !empty($settings['asana_enabled']) && !empty($settings['asana_webhook_url']);
        $has_generic = !empty($settings['generic_webhook_enabled']) && !empty($settings['generic_webhook_url']);

        if (!$has_slack && !$has_discord && !$has_clickup && !$has_asana && !$has_generic) {
            return;
        }

        $site_name = wp_specialchars_decode(get_bloginfo('name'), ENT_QUOTES) ?: 'WordPress';
        $site_url  = get_site_url();
        $waf_url   = admin_url('admin.php?page=webcare-pro-firewall');

        $category = $incident['category'] ?? 'Exploit Probe';
        $rule     = $incident['name'] ?? 'WAF Rule';
        $ip       = $incident['ip_address'] ?? 'unknown';

        if ($has_slack) {
            $slack_payload = [
                'text' => "🛡️ [WAF Block] Attack intercepted from {$ip} on {$site_name}",
                'attachments' => [
                    [
                        'color' => self::COLOR_CRITICAL,
                        'blocks' => [
                            [
                                'type' => 'header',
                                'text' => ['type' => 'plain_text', 'text' => '🛡️ WAF Lite Attack Blocked', 'emoji' => true]
                            ],
                            [
                                'type' => 'section',
                                'text' => [
                                    'type' => 'mrkdwn',
                                    'text' => "*Site:* <{$site_url}|{$site_name}>\n*Attacker IP:* `{$ip}`\n*Category:* *{$category}*\n*Rule:* `{$rule}`"
                                ]
                            ],
                            [
                                'type' => 'actions',
                                'elements' => [
                                    [
                                        'type' => 'button',
                                        'text' => ['type' => 'plain_text', 'text' => 'View Live Incident Stream'],
                                        'url' => $waf_url,
                                        'style' => 'danger'
                                    ]
                                ]
                            ]
                        ]
                    ]
                ]
            ];
            self::enqueue_webhook($settings['slack_webhook_url'], $slack_payload, 'Slack');
        }

        if ($has_discord) {
            $discord_payload = [
                'username' => 'WebCare Firewall Bot',
                'embeds' => [
                    [
                        'title' => '🛡️ WAF Lite Attack Intercepted',
                        'description' => "Malicious HTTP probe rejected before reaching WordPress core.",
                        'url' => $waf_url,
                        'color' => 14428198,
                        'fields' => [
                            ['name' => 'Attacker IP', 'value' => $ip, 'inline' => true],
                            ['name' => 'Category', 'value' => $category, 'inline' => true],
                            ['name' => 'Rule', 'value' => $rule, 'inline' => true],
                        ],
                        'footer' => ['text' => 'WebCare Web Application Firewall'],
                        'timestamp' => gmdate('Y-m-d\TH:i:s\Z'),
                    ]
                ]
            ];
            self::enqueue_webhook($settings['discord_webhook_url'], $discord_payload, 'Discord');
        }

        if ($has_clickup) {
            $clickup_payload = [
                'name'        => "🛡️ [WAF Block] Attack intercepted from {$ip} ({$category})",
                'content'     => "WAF Lite blocked an attack on {$site_name}.\n\n- Attacker IP: {$ip}\n- Attack Category: {$category}\n- Rule Triggered: {$rule}\n\nView live incidents: {$waf_url}",
                'priority'    => 2,
                'tags'        => ['security', 'waf', 'firewall-block'],
                'event'       => 'waf_block',
                'attacker_ip' => $ip,
                'category'    => $category,
            ];
            self::enqueue_webhook($settings['clickup_webhook_url'], $clickup_payload, 'ClickUp');
        }

        if ($has_asana) {
            $asana_payload = [
                'name'  => "🛡️ [WAF Block] Attack intercepted from {$ip} ({$category})",
                'notes' => "WAF Lite blocked attack on {$site_name}.\nAttacker IP: {$ip}\nCategory: {$category}\nRule: {$rule}\nLive Incidents: {$waf_url}",
                'data'  => [
                    'name'  => "🛡️ [WAF Block] Attack intercepted from {$ip} ({$category})",
                    'notes' => "WAF Lite blocked attack on {$site_name}.\nAttacker IP: {$ip}\nCategory: {$category}\nRule: {$rule}\nLive Incidents: {$waf_url}",
                ],
            ];
            self::enqueue_webhook($settings['asana_webhook_url'], $asana_payload, 'Asana');
        }

        if ($has_generic) {
            $generic_payload = [
                'event'         => 'waf_block',
                'site_name'     => $site_name,
                'site_url'      => $site_url,
                'dashboard_url' => $waf_url,
                'attacker_ip'   => $ip,
                'category'      => $category,
                'rule_name'     => $rule,
                'timestamp'     => time(),
                'datetime'      => gmdate('c'),
            ];
            self::enqueue_webhook($settings['generic_webhook_url'], $generic_payload, 'Automation Webhook');
        }
    }

    /**
     * Send HTTP POST to webhook endpoint.
     * Enforces SSRF defense (HTTPS-only, rejects RFC 1918 / loopback / cloud metadata).
     */
    private static function post_webhook(string $url, array $payload, string $platform_name, bool $is_manual_test = false): array {
        $parsed = wp_parse_url($url);
        $scheme = strtolower($parsed['scheme'] ?? '');
        $host   = strtolower($parsed['host'] ?? '');

        // Strict HTTPS enforcement (allow localhost HTTP strictly if defined in local development constant)
        if ($scheme !== 'https') {
            $is_local_dev = defined('WP_ENVIRONMENT_TYPE') && WP_ENVIRONMENT_TYPE === 'local';
            if (!$is_local_dev) {
                return [
                    'success' => false,
                    'code'    => 400,
                    'message' => __('Webhook URL must use secure HTTPS.', 'webcare-pro-security'),
                ];
            }
        }

        // SSRF protection: reject AWS/GCP/Azure instance metadata endpoints
        if ($host === '169.254.169.254' || $host === 'metadata.google.internal' || $host === 'instance-data') {
            return [
                'success' => false,
                'code'    => 400,
                'message' => __('Webhook URL rejected: Prohibited metadata endpoint.', 'webcare-pro-security'),
            ];
        }

        $timeout = $is_manual_test ? 4 : 5;

        // Use wp_safe_remote_post to validate IP boundaries and avoid private intranet SSRF
        $response = wp_safe_remote_post($url, [
            'timeout'     => $timeout,
            'blocking'    => true,
            'headers'     => ['Content-Type' => 'application/json'],
            'body'        => wp_json_encode($payload),
            'data_format' => 'body',
        ]);

        if (is_wp_error($response)) {
            return [
                'success' => false,
                'code'    => 500,
                /* translators: 1: platform name, 2: error message */
                'message' => sprintf(__('%1$s delivery error: %2$s', 'webcare-pro-security'), $platform_name, $response->get_error_message()),
            ];
        }

        $code = wp_remote_retrieve_response_code($response);
        if ($code >= 200 && $code < 300) {
            return [
                'success' => true,
                'code'    => $code,
                /* translators: 1: platform name, 2: HTTP status code */
                'message' => sprintf(__('%1$s alert delivered successfully (HTTP %2$d).', 'webcare-pro-security'), $platform_name, $code),
            ];
        }

        $body = wp_remote_retrieve_body($response);
        return [
            'success' => false,
            'code'    => $code,
            /* translators: 1: platform name, 2: HTTP status code, 3: response body snippet */
            'message' => sprintf(__('%1$s returned HTTP %2$d: %3$s', 'webcare-pro-security'), $platform_name, $code, substr($body, 0, 120)),
        ];
    }
}
