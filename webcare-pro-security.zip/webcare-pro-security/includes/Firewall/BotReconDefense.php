<?php
namespace WebCareProScanner\Firewall;

use WebCareProScanner\System\SettingsManager;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Bot Recon Defense & AI Scraper Shield
 *
 * Provides:
 * 1. Fake Search Engine Crawler Detection:
 *    Detects requests claiming to be Googlebot, Bingbot, Yahoo Slurp, or DuckDuckBot.
 *    Validates authenticity via reverse DNS lookup (PTR) followed by forward DNS confirmation (A/AAAA).
 *    Results are transiently cached for 24 hours to prevent repeated DNS resolution overhead.
 *    Any crawler impersonating genuine search engines is blocked as an adversarial reconnaissance probe.
 *
 * 2. AI Scraper & Unethical Harvester Shield:
 *    Identifies and blocks aggressive AI model scrapers (e.g. GPTBot, CCBot, Bytespider, ClaudeBot, PerplexityBot).
 *
 * 3. Dynamic Virtual robots.txt Ingestion:
 *    Automatically injects standard Disallow directives for AI scrapers into WordPress virtual robots.txt.
 */
class BotReconDefense {

    /**
     * Map of supported search engine bots and their authorized host suffixes.
     */
    private const SEARCH_BOTS = [
        'googlebot'             => ['googlebot.com', 'google.com'],
        'adsbot-google'         => ['googlebot.com', 'google.com'],
        'mediapartners-google'  => ['googlebot.com', 'google.com'],
        'apis-google'           => ['googlebot.com', 'google.com'],
        'google-inspectiontool' => ['googlebot.com', 'google.com'],
        'googleother'           => ['googlebot.com', 'google.com'],
        'storebot-google'       => ['googlebot.com', 'google.com'],
        'bingbot'               => ['search.msn.com', 'bing.com'],
        'adidxbot'              => ['search.msn.com', 'bing.com'],
        'applebot'              => ['applebot.apple.com', 'apple.com'],
        'slurp'                 => ['crawl.yahoo.net', 'yahoo.com'],
        'duckduckbot'           => ['duckduckgo.com'],
        'yandex'                => ['yandex.ru', 'yandex.net', 'yandex.com'],
        'baiduspider'           => ['baidu.com', 'baidu.jp'],
        'oai-searchbot'         => ['openai.com'],
        'perplexitybot'         => ['perplexity.ai'],
        'claude-searchbot'      => ['anthropic.com'],
    ];

    /**
     * Map of recognized SEO audit crawlers and their authorized FCrDNS domain suffixes.
     */
    private const SEO_BOTS = [
        'ahrefsbot'    => ['ahrefs.com', 'ahrefs.net'],
        'semrushbot'   => ['semrush.com'],
        'siteauditbot' => ['semrush.com'],
        'dotbot'       => ['moz.com', 'seomoz.org'],
        'rogerbot'     => ['moz.com', 'seomoz.org'],
        'mj12bot'      => ['majestic12.co.uk'],
        'seokicks'     => ['seokicks.de'],
    ];

    /**
     * Map of recognized desktop audit spiders.
     * These spiders typically run from auditor workstation/office IPs without fixed PTR records.
     */
    private const DESKTOP_SPIDERS = [
        'screaming frog' => 'Screaming Frog SEO Spider',
        'sitebulb'       => 'Sitebulb SEO Spider',
    ];

    /**
     * Official Verified Search Crawler Network CIDR Ranges (IPv4 & IPv6).
     * High-speed authoritative fallback when reverse DNS PTR queries fail, time out,
     * or are blocked by container network resolvers (e.g. Docker, NAT environments).
     */
    private const CRAWLER_CIDR_RANGES = [
        'googlebot' => [
            // Strict Googlebot-specific crawl CIDRs (excluding broad GCP Cloud/Services subnets)
            '66.249.64.0/19',
            '64.233.160.0/19',
            '72.14.192.0/18',
            '209.85.128.0/17',
            '108.177.8.0/21',
            '216.58.192.0/19',
            '34.22.85.0/27',
            '35.247.243.240/28',
            '192.178.4.0/22',
            // Googlebot Primary IPv6 Subnets
            '2001:4860::/32',
            '2404:6800::/32',
            '2a00:1450::/32',
            '2c0f:fb50::/32',
        ],
        'bingbot' => [
            // Strict Bingbot-specific crawl CIDRs (excluding broad Azure customer subnets)
            '157.55.39.0/24',
            '207.46.13.0/24',
            '40.77.167.0/24',
            '13.66.139.0/24',
            '13.66.144.0/24',
            '52.167.144.0/24',
        ],
        'oai-searchbot' => [
            // OpenAI published search crawler IP ranges
            '20.171.206.0/24',
            '20.171.207.0/24',
            '40.83.2.0/24',
        ],
        'perplexitybot' => [
            // Exact Perplexity-published crawler IP ranges (broad shared Fastly /16 ranges removed)
            // Unrelated Fastly clients cannot spoof PerplexityBot; fallback uses cached FCrDNS
        ],
        'claude-searchbot' => [
            // Anthropic Claude search citation IP ranges
            '160.79.104.0/23',
        ],
        'dotbot' => [
            // Official Moz DotBot crawler subnet
            '216.244.64.0/19',
        ],
    ];

    /**
     * Map of verified uptime & performance monitoring services and their authorized reverse DNS host suffixes.
     */
    private const MONITORING_BOTS = [
        'uptimerobot' => ['uptimerobot.com'],
        'pingdom'     => ['pingdom.com'],
        'statuscake'  => ['statuscake.com'],
        'betteruptime'=> ['betteruptime.com'],
        'gtmetrix'    => ['gtmetrix.com'],
    ];

    /**
     * Known AI scrapers & training harvesters User-Agent signatures.
     */
    private const AI_SCRAPERS = [
        'gptbot'         => 'OpenAI GPTBot',
        'chatgpt-user'   => 'ChatGPT Web Crawler',
        'ccbot'          => 'Common Crawl Bot',
        'bytespider'     => 'ByteDance Spider',
        'anthropic-ai'   => 'Anthropic AI Crawler',
        'claudebot'      => 'ClaudeBot',
        'perplexitybot'  => 'Perplexity AI Bot',
        'diffbot'        => 'Diffbot Harvester',
        'cohere-ai'      => 'Cohere AI Harvester',
        'omgili'         => 'Omgili Web Scraper',
        'facebookexternalhit' => false, // Leave Facebook unfrozen unless specified
    ];

    public const CRON_HOOK_DNS_VERIFY = 'webcareproscan_verify_bot_dns_bg';
    public const OPTION_DNS_QUEUE     = 'webcareproscan_bot_dns_queue';
    private const MAX_DNS_QUEUE_SIZE  = 20;

    /**
     * Initialize Dynamic robots.txt Hook and Background Crawler DNS Verification Worker.
     */
    public static function init() {
        add_filter('robots_txt', [__CLASS__, 'filter_dynamic_robots_txt'], 10, 2);
        add_action(self::CRON_HOOK_DNS_VERIFY, [__CLASS__, 'process_background_dns_queue']);
    }

    /**
     * Inspect Bot / User-Agent against Fake Search Engine and AI Scraper Shields
     *
     * @param string $client_ip
     * @param string $user_agent
     * @param array $settings
     * @return array|null Returns rule definition if suspicious/blocked, or null if allowed.
     */
    public static function inspect_bot(string $client_ip, string $user_agent, array $settings): ?array {
        if (empty($user_agent)) {
            return null;
        }

        $ua_lower        = strtolower($user_agent);
        $claimed_search  = self::detect_claimed_search_bot($ua_lower);
        $claimed_seo     = self::detect_claimed_seo_bot($ua_lower);
        $claimed_desktop = self::detect_claimed_desktop_spider($ua_lower);

        $bot_label = null;
        if ($claimed_search !== null) {
            $bot_label = ucfirst($claimed_search);
        } elseif ($claimed_seo !== null) {
            $bot_label = ucfirst($claimed_seo);
        } elseif ($claimed_desktop !== null) {
            $bot_label = $claimed_desktop;
        }

        // 1. Strict Read-Only Crawl Jail:
        // Genuine search engines, SEO suites, and desktop spiders ONLY crawl public URLs with GET/HEAD/OPTIONS.
        // If any crawler attempts a state-mutating method (POST/PUT/DELETE) or touches auth/cart/admin endpoints,
        // it is an adversarial spoof or crawler exploit attempt - immediately block it.
        if ($bot_label !== null && !self::is_read_only_public_crawl()) {
            $req_method = isset($_SERVER['REQUEST_METHOD']) ? sanitize_text_field(wp_unslash($_SERVER['REQUEST_METHOD'])) : 'GET';
            $req_uri    = isset($_SERVER['REQUEST_URI']) ? sanitize_text_field(wp_unslash($_SERVER['REQUEST_URI'])) : '/';

            return [
                'id'          => 'BOT-CRAWLER-MUTATION-BLOCKED',
                'name'        => 'Crawler Restricted to Read-Only Public URLs (' . $bot_label . ')',
                'category'    => 'Bot Recon Defense',
                'match_type'  => 'Crawler State-Mutation / Auth Violation',
                'match_value' => sprintf('Bot "%s" attempted non-crawl request (%s %s)', $bot_label, $req_method, substr($req_uri, 0, 100)),
            ];
        }

        // 2. Check AI Scrapers & Crawler Policy (3-Switch Controls)
        $ai_bot_matched = self::match_ai_scraper($ua_lower);
        if ($ai_bot_matched) {
            // Switch 1: Allow ONLY IP/rDNS-verified search & citation assistants (OAI-SearchBot, PerplexityBot, Claude-SearchBot)
            $allow_citations = !empty($settings['waf_ai_allow_search_citations']);
            if ($allow_citations && self::is_verified_ai_citation_bot($client_ip, $user_agent)) {
                return null;
            }

            // Switch 2: Token-bucket HTTP 429 rate limit or block for bulk training harvesters
            $throttle_training = !empty($settings['waf_ai_throttle_training_scrapers']);
            if ($throttle_training || !empty($settings['waf_block_ai_scrapers'])) {
                // Apply token-bucket rate limiting (max 10 requests / minute)
                $rate_key = 'webcare_ai_harvester_' . md5($client_ip);
                $hits = (int) get_transient($rate_key);
                set_transient($rate_key, $hits + 1, 60);

                if ($hits > 10 || !empty($settings['waf_block_ai_scrapers'])) {
                    return [
                        'id'          => 'BOT-AI-SCRAPER-BLOCKED',
                        'name'        => 'AI Content Scraper / Harvester Rate-Limited (' . $ai_bot_matched . ')',
                        'category'    => 'Bot Recon Defense',
                        'match_type'  => 'User-Agent Signature',
                        'match_value' => substr($user_agent, 0, 150),
                    ];
                }
            }
        }

        // 2b. Check Commercial / SEO Crawler Policy & Multi-Level Subnet Swarms (PetalBot, Bytespider, etc.)
        if (class_exists('\\WebCareProScanner\\Firewall\\Core\\SubnetSwarmGuard')) {
            $swarm_decision = \WebCareProScanner\Firewall\Core\SubnetSwarmGuard::inspect_crawler_swarm($client_ip, $user_agent, $settings);
            if ($swarm_decision !== null) {
                if ($swarm_decision['action'] === 'block') {
                    return [
                        'id'          => $swarm_decision['rule_id'] ?? 'WAF-CRAWLER-POLICY-BLOCKED',
                        'name'        => 'Commercial Crawler Blocked by Policy',
                        'category'    => 'Bot Recon Defense',
                        'match_type'  => 'Crawler Policy',
                        'match_value' => $swarm_decision['message'] ?? 'Crawler blocked',
                    ];
                }
                if ($swarm_decision['action'] === 'throttle') {
                    return [
                        'id'          => $swarm_decision['rule_id'] ?? 'WAF-SUBNET-SWARM-THROTTLE',
                        'name'        => 'Commercial Crawler Subnet Swarm Throttled',
                        'category'    => 'Bot Recon Defense',
                        'match_type'  => 'Subnet Rate Limit',
                        'match_value' => $swarm_decision['message'] ?? 'Crawler throttled',
                        'status_code' => 429,
                        'retry_after' => $swarm_decision['retry_after'] ?? 120,
                    ];
                }
            }
        }

        // 3. Check Fake Search Engine & Cloud SEO Crawler Spoofing (Zero synchronous DNS on request path)
        if (!empty($settings['waf_block_fake_bots'])) {
            $is_metadata_crawl_path = false;
            // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Preserve raw percent-encoded URI until wp_parse_url()/path parser runs
            $req_uri = (isset($_SERVER['REQUEST_URI']) && is_string($_SERVER['REQUEST_URI'])) ? (string) wp_unslash($_SERVER['REQUEST_URI']) : '';
            $path_only = strtolower((string) (wp_parse_url($req_uri, PHP_URL_PATH) ?: $req_uri));
            if ($path_only === '/robots.txt' || (str_starts_with($path_only, '/sitemap') && (str_ends_with($path_only, '.xml') || str_ends_with($path_only, '.xml.gz')))) {
                $is_metadata_crawl_path = true;
            }

            if ($claimed_search !== null) {
                $dns_state = self::get_cached_bot_dns_state($client_ip, $claimed_search);
                $has_authoritative_cidrs = in_array($claimed_search, ['googlebot', 'bingbot', 'applebot', 'duckduckbot'], true);
                if ($dns_state === 'conflicting' || ($dns_state === 'unknown' && !$is_metadata_crawl_path && $has_authoritative_cidrs)) {
                    return [
                        'id'          => 'BOT-FAKE-CRAWLER-SPOOF',
                        'name'        => 'Fake Search Engine Crawler Spoofing Detected (' . ucfirst($claimed_search) . ')',
                        'description' => 'Fake Search Engine Crawler Spoofing Detected (' . ucfirst($claimed_search) . ')',
                        'category'    => 'Bot Recon Defense',
                        'match_type'  => 'Reverse DNS Verification Failure',
                        'match_value' => 'IP: ' . $client_ip . ' claiming UA: ' . substr($user_agent, 0, 100),
                    ];
                }
            } elseif ($claimed_seo !== null) {
                $dns_state = self::get_cached_bot_dns_state($client_ip, $claimed_seo);
                if ($dns_state === 'conflicting') {
                    return [
                        'id'          => 'BOT-FAKE-CRAWLER-SPOOF',
                        'name'        => 'Fake SEO Crawler Spoofing Detected (' . ucfirst($claimed_seo) . ')',
                        'description' => 'Fake SEO Crawler Spoofing Detected (' . ucfirst($claimed_seo) . ')',
                        'category'    => 'Bot Recon Defense',
                        'match_type'  => 'Reverse DNS Verification Failure',
                        'match_value' => 'IP: ' . $client_ip . ' claiming UA: ' . substr($user_agent, 0, 100),
                    ];
                }
            }
            // Desktop spiders (Screaming Frog, Sitebulb) run from local user IPs, so they don't have fixed PTR records;
            // they are soft-allowed on read-only public crawl requests.
        }

        return null;
    }

    /**
     * Check if User Agent matches known AI Scrapers
     */
    public static function match_ai_scraper(string $ua_lower): ?string {
        foreach (self::AI_SCRAPERS as $signature => $label) {
            if ($label !== false && strpos($ua_lower, $signature) !== false) {
                return $label;
            }
        }
        return null;
    }

    /**
     * Detect if User Agent claims to be a well-known search crawler
     */
    public static function detect_claimed_search_bot(string $ua_lower): ?string {
        foreach (self::SEARCH_BOTS as $bot_key => $domains) {
            if (str_contains($ua_lower, $bot_key)) {
                return $bot_key;
            }
        }
        return null;
    }

    /**
     * Detect if User Agent claims to be a recognized SEO crawler.
     */
    public static function detect_claimed_seo_bot(string $ua_lower): ?string {
        foreach (self::SEO_BOTS as $bot_key => $domains) {
            if (str_contains($ua_lower, $bot_key)) {
                return $bot_key;
            }
        }
        return null;
    }

    /**
     * Detect if User Agent claims to be a recognized desktop SEO spider.
     */
    public static function detect_claimed_desktop_spider(string $ua_lower): ?string {
        foreach (self::DESKTOP_SPIDERS as $token => $label) {
            if (str_contains($ua_lower, $token)) {
                return $label;
            }
        }
        return null;
    }

    /**
     * Verify that the current request is strictly a read-only public URL crawl.
     * Search engines and SEO analyzers must NEVER sign up, log in, submit forms,
     * add items to cart, execute checkouts, or send state-mutating HTTP methods.
     *
     * @param string|null $request_uri Optional URI to evaluate (defaults to $_SERVER['REQUEST_URI'])
     * @param string|null $method Optional HTTP method to evaluate (defaults to $_SERVER['REQUEST_METHOD'])
     * @return bool True if strictly read-only public URL crawl, false otherwise.
     */
    public static function is_read_only_public_crawl(?string $request_uri = null, ?string $method = null): bool {
        $req_method = strtoupper($method ?? (isset($_SERVER['REQUEST_METHOD']) ? sanitize_text_field(wp_unslash($_SERVER['REQUEST_METHOD'])) : 'GET'));
        if (!in_array($req_method, ['GET', 'HEAD', 'OPTIONS'], true)) {
            return false;
        }

        $raw_uri = $request_uri ?? (isset($_SERVER['REQUEST_URI']) ? sanitize_text_field(wp_unslash($_SERVER['REQUEST_URI'])) : '/');
        $uri     = strtolower($raw_uri);
        $path    = (string) (wp_parse_url($uri, PHP_URL_PATH) ?: $uri);
        $query   = (string) (wp_parse_url($uri, PHP_URL_QUERY) ?: (isset($_SERVER['QUERY_STRING']) ? strtolower(sanitize_text_field(wp_unslash($_SERVER['QUERY_STRING']))) : ''));

        // Normalize URL encoded characters
        $path  = rawurldecode($path);
        $query = rawurldecode($query);

        $normalized_path = '/' . ltrim($path, '/');
        $trimmed_path    = rtrim($normalized_path, '/');

        // Interactive, authentication, account creation, and admin paths are forbidden for crawlers
        if ($trimmed_path === '/wp-admin' || str_starts_with($normalized_path, '/wp-admin/')) {
            return false;
        }

        // Store pages (/cart, /checkout, /my-account) are permitted for verified search crawlers only when:
        // A) Request method is GET or HEAD (read-only)
        // B) Request has no query string ($query === '')
        // This allows SEO suites (Ahrefs, Semrush, Screaming Frog) to verify 'noindex' and canonical headers
        // while strictly preventing automated cart manipulation, coupon enumeration, or parameter fuzzing.
        $store_paths = ['/my-account', '/checkout', '/cart'];
        foreach ($store_paths as $s_path) {
            if ($trimmed_path === $s_path || str_starts_with($normalized_path, $s_path . '/')) {
                if ($query !== '') {
                    return false; // Any query params on cart/checkout are forbidden for crawlers
                }
            }
        }

        // Script-specific filenames
        $forbidden_scripts = [
            'wp-login.php',
            'wp-register.php',
            'wp-signup.php',
            'wp-activate.php',
            'xmlrpc.php',
            'wp-comments-post.php',
            'wp-trackback.php',
        ];
        foreach ($forbidden_scripts as $script) {
            if ($trimmed_path === '/' . $script || str_ends_with($trimmed_path, '/' . $script)) {
                return false;
            }
        }

        // Forbidden transactional, account, or cart query parameters on GET requests
        if ($query !== '' && preg_match('/(?:^|&)(?:action=(?:register|lostpassword|retrievepassword|resetpass|rp|login|logout)|wc-ajax=|add-to-cart=|remove_item=)/i', $query)) {
            return false;
        }

        return true;
    }

    /**
     * Confirm forward DNS resolution (IPv4 A and IPv6 AAAA) matches the connecting IP.
     */
    private static function forward_dns_matches_ip(string $hostname, string $ip): bool {
        if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
            $single = @gethostbyname($hostname);
            if ($single === $ip) {
                return true;
            }
            $all_v4 = @gethostbynamel($hostname);
            return is_array($all_v4) && in_array($ip, $all_v4, true);
        }

        if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6) && function_exists('dns_get_record')) {
            $target_bin = @inet_pton($ip);
            if ($target_bin === false) {
                return false;
            }
            $records = @dns_get_record($hostname, DNS_AAAA);
            if (is_array($records)) {
                foreach ($records as $rec) {
                    if (!empty($rec['ipv6']) && is_string($rec['ipv6'])) {
                        $cand_bin = @inet_pton($rec['ipv6']);
                        if ($cand_bin !== false && hash_equals($target_bin, $cand_bin)) {
                            return true;
                        }
                    }
                }
            }
        }

        return false;
    }

    /**
     * Resolve cached tri-state crawler verification status without executing synchronous DNS on the request path.
     *
     * States:
     * - 'verified': IP matches authoritative vendor CIDRs or previously passed background FCrDNS.
     * - 'conflicting': Background FCrDNS confirmed a mismatched non-vendor PTR hostname.
     * - 'unknown': Outside static CIDRs and not yet resolved (queued for bounded background WP-Cron lookup).
     *
     * @param string $ip
     * @param string $bot_key
     * @return string 'verified'|'conflicting'|'unknown'
     */
    public static function get_cached_bot_dns_state(string $ip, string $bot_key): string {
        // Skip private or local IPs (never verified)
        if (!filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) {
            return 'unknown';
        }

        $allowed_domains = self::SEARCH_BOTS[$bot_key] ?? self::SEO_BOTS[$bot_key] ?? [];
        if (empty($allowed_domains)) {
            return 'unknown';
        }

        // 1. Authoritative Vendor CIDR check first (zero DNS latency & zero timeout risk)
        if (self::is_search_bot_in_official_cidrs($ip, $bot_key)) {
            return 'verified';
        }

        // 2. Check cached tri-state verdict (zero synchronous DNS on HTTP request path)
        $transient_key = 'webcareproscan_bot_dns_v2_' . md5($ip . '_' . $bot_key);
        $cached = get_transient($transient_key);
        if (is_string($cached) && in_array($cached, ['verified', 'conflicting', 'unknown'], true)) {
            return $cached;
        }

        // 3. Cache 'unknown' for 5 minutes and enqueue bounded background WP-Cron resolution
        set_transient($transient_key, 'unknown', 300);
        self::enqueue_background_dns_lookup($ip, $bot_key);

        return 'unknown';
    }

    /**
     * Enqueue an IP/bot pair for asynchronous background FCrDNS verification (strictly bounded queue).
     */
    private static function enqueue_background_dns_lookup(string $ip, string $bot_key): void {
        $queue = get_option(self::OPTION_DNS_QUEUE, []);
        if (!is_array($queue)) {
            $queue = [];
        }

        $entry_key = md5($ip . '_' . $bot_key);
        if (isset($queue[$entry_key]) || count($queue) >= self::MAX_DNS_QUEUE_SIZE) {
            return;
        }

        $queue[$entry_key] = [
            'ip'      => $ip,
            'bot_key' => $bot_key,
            'queued'  => time(),
        ];
        update_option(self::OPTION_DNS_QUEUE, $queue, false);

        if (function_exists('wp_next_scheduled') && function_exists('wp_schedule_single_event')) {
            if (!wp_next_scheduled(self::CRON_HOOK_DNS_VERIFY)) {
                wp_schedule_single_event(time() + 10, self::CRON_HOOK_DNS_VERIFY);
            }
        }
    }

    /**
     * Background WP-Cron worker that executes PTR + IPv4/IPv6 forward DNS verification
     * and stores a bounded tri-state result ('verified', 'conflicting', or 'unknown').
     */
    public static function process_background_dns_queue(): void {
        $queue = get_option(self::OPTION_DNS_QUEUE, []);
        if (!is_array($queue) || empty($queue)) {
            return;
        }

        // Clear queue atomically before processing to prevent overlapping worker loops
        update_option(self::OPTION_DNS_QUEUE, [], false);

        foreach ($queue as $item) {
            if (!is_array($item) || empty($item['ip']) || empty($item['bot_key'])) {
                continue;
            }
            $ip      = (string) $item['ip'];
            $bot_key = (string) $item['bot_key'];
            $allowed_domains = self::SEARCH_BOTS[$bot_key] ?? self::SEO_BOTS[$bot_key] ?? [];
            if (empty($allowed_domains)) {
                continue;
            }

            $transient_key = 'webcareproscan_bot_dns_v2_' . md5($ip . '_' . $bot_key);
            $state = 'unknown';
            $ttl   = 600;

            $hostname = @gethostbyaddr($ip);
            if (!empty($hostname) && $hostname !== $ip) {
                $hostname_lower = strtolower(rtrim($hostname, '.'));
                $domain_matches = false;
                foreach ($allowed_domains as $domain) {
                    if ($hostname_lower === $domain || str_ends_with($hostname_lower, '.' . $domain)) {
                        $domain_matches = true;
                        break;
                    }
                }

                if ($domain_matches && self::forward_dns_matches_ip($hostname, $ip)) {
                    $state = 'verified';
                    $ttl   = DAY_IN_SECONDS;
                } else {
                    $state = 'conflicting';
                    $ttl   = DAY_IN_SECONDS;
                }
            }

            set_transient($transient_key, $state, $ttl);
        }
    }

    /**
     * Validate genuine search crawler using official CIDRs and cached background FCrDNS.
     * Never performs synchronous DNS resolution on the request path, and never treats 'unknown' as verified.
     */
    public static function verify_search_bot_reverse_dns(string $ip, string $bot_key): bool {
        return self::get_cached_bot_dns_state($ip, $bot_key) === 'verified';
    }

    /**
     * Check if client IP belongs to official verified search crawler CIDR ranges.
     */
    public static function is_search_bot_in_official_cidrs(string $ip, string $bot_key): bool {
        $normalized_key = match ($bot_key) {
            'adsbot-google', 'mediapartners-google', 'apis-google', 'google-inspectiontool', 'googleother', 'storebot-google' => 'googlebot',
            'adidxbot' => 'bingbot',
            default    => $bot_key,
        };

        if (class_exists('\\WebCareProScanner\\Firewall\\OfficialCrawlerRegistry')) {
            if (OfficialCrawlerRegistry::is_ip_in_crawler_cidrs($ip, $bot_key) || OfficialCrawlerRegistry::is_ip_in_crawler_cidrs($ip, $normalized_key)) {
                return true;
            }
        }

        $cidrs = self::CRAWLER_CIDR_RANGES[$bot_key] ?? self::CRAWLER_CIDR_RANGES[$normalized_key] ?? [];
        if (empty($cidrs)) {
            return false;
        }

        foreach ($cidrs as $cidr) {
            if (class_exists('\\WebCareProScanner\\Firewall\\FirewallEngine') && FirewallEngine::ip_in_range($ip, $cidr)) {
                return true;
            }
        }

        return false;
    }

    /**
     * Check whether an incoming request belongs to an authenticated, verified search engine crawler.
     *
     * Examines the User-Agent string, and if it claims to be a recognized search engine (Google, Bing, DuckDuckGo,
     * Yandex, Baidu, Yahoo), executes full Reverse DNS (PTR) + Forward DNS (A/AAAA) confirmation.
     * Returns true ONLY if DNS cryptographic hostname confirmation succeeds.
     *
     * @param string $ip Client IP address.
     * @param string $user_agent Client User-Agent string.
     * @return bool True if genuine search engine, false otherwise.
     */
    public static function is_genuine_search_engine(string $ip, string $user_agent): bool {
        if (empty($user_agent) || !self::is_read_only_public_crawl()) {
            return false;
        }

        $ua_lower = strtolower($user_agent);
        $bot_key  = self::detect_claimed_search_bot($ua_lower);

        if ($bot_key !== null) {
            return self::verify_search_bot_reverse_dns($ip, $bot_key);
        }

        $seo_key = self::detect_claimed_seo_bot($ua_lower);
        if ($seo_key !== null) {
            return self::verify_search_bot_reverse_dns($ip, $seo_key);
        }

        return false;
    }

    /**
     * Check whether an incoming request belongs to an authenticated, verified AI citation bot
     * (OAI-SearchBot, PerplexityBot, Claude-SearchBot).
     *
     * Validates:
     * 1. Request is strictly a read-only public crawl (GET/HEAD/OPTIONS).
     * 2. Client IP matches verified vendor IP ranges or passes cached FCrDNS confirmation.
     *
     * @param string $ip Client IP address.
     * @param string $user_agent Client User-Agent string.
     * @return bool True if verified AI citation bot, false otherwise.
     */
    public static function is_verified_ai_citation_bot(string $ip, string $user_agent): bool {
        if (empty($user_agent) || !self::is_read_only_public_crawl()) {
            return false;
        }

        $ua_lower = strtolower($user_agent);
        $citation_keys = ['oai-searchbot', 'perplexitybot', 'claude-searchbot'];
        $matched_bot = null;

        foreach ($citation_keys as $cit_key) {
            if (str_contains($ua_lower, $cit_key)) {
                $matched_bot = $cit_key;
                break;
            }
        }

        if ($matched_bot === null) {
            return false;
        }

        return self::verify_search_bot_reverse_dns($ip, $matched_bot);
    }

    /**
     * Check whether an incoming request belongs to an authenticated, verified uptime monitoring service
     * (UptimeRobot, Pingdom, StatusCake, BetterUptime, GTmetrix).
     *
     * Validates:
     * 1. Setting 'waf_allow_uptime_monitors' is active.
     * 2. Request is strictly a read-only public crawl (GET/HEAD/OPTIONS).
     * 3. User-Agent matches recognized monitoring service signature.
     * 4. Forward & reverse DNS confirmation against official domain suffix (cached for 24 hours).
     *
     * @param string $ip
     * @param string $user_agent
     * @param array $settings
     * @return bool
     */
    public static function is_genuine_uptime_monitor(string $ip, string $user_agent, array $settings): bool {
        if (empty($settings['waf_allow_uptime_monitors']) || empty($user_agent) || !self::is_read_only_public_crawl()) {
            return false;
        }

        $ua_lower = strtolower($user_agent);
        $matched_key = null;
        foreach (self::MONITORING_BOTS as $bot_key => $domains) {
            if (strpos($ua_lower, $bot_key) !== false) {
                $matched_key = $bot_key;
                break;
            }
        }

        if ($matched_key === null) {
            return false;
        }

        // Validate via cached DNS PTR / Forward A record check
        $transient_key = 'webcareproscan_monitor_dns_' . md5($ip . '_' . $matched_key);
        $cached = get_transient($transient_key);
        if ($cached !== false) {
            return ($cached === 'genuine');
        }

        // Skip private or local IPs
        if (!filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) {
            return false;
        }

        $allowed_domains = self::MONITORING_BOTS[$matched_key] ?? [];
        $is_genuine = false;

        $hostname = @gethostbyaddr($ip);
        if (!empty($hostname) && $hostname !== $ip) {
            $hostname_lower = strtolower($hostname);
            $domain_matches = false;
            foreach ($allowed_domains as $domain) {
                if ($hostname_lower === $domain || str_ends_with($hostname_lower, '.' . $domain)) {
                    $domain_matches = true;
                    break;
                }
            }

            if ($domain_matches) {
                $resolved_ip = @gethostbyname($hostname);
                if ($resolved_ip === $ip) {
                    $is_genuine = true;
                }
            }
        }

        set_transient($transient_key, $is_genuine ? 'genuine' : 'fake', DAY_IN_SECONDS);
        return $is_genuine;
    }

    /**
     * Check whether an incoming request belongs to a recognized synthetic performance audit tool
     * (WebPageTest, Chrome Lighthouse, Google PageSpeed, GTmetrix, SpeedCurve, Pingdom TMS).
     *
     * Validates that the request is strictly a read-only public crawl (GET/HEAD/OPTIONS).
     *
     * @param string $user_agent
     * @return bool
     */
    public static function is_synthetic_performance_tool(string $user_agent): bool {
        if (empty($user_agent) || !self::is_read_only_public_crawl()) {
            return false;
        }

        // WebPageTest test agent token (e.g. PTST/261109.195727) or explicit WebPageTest
        if (str_contains($user_agent, 'PTST/') || stripos($user_agent, 'WebPageTest') !== false) {
            return true;
        }

        // Chrome Lighthouse / Google PageSpeed Insights
        if (stripos($user_agent, 'Chrome-Lighthouse') !== false || stripos($user_agent, 'Google-PageSpeed') !== false || stripos($user_agent, 'PageSpeed') !== false) {
            return true;
        }

        // GTmetrix synthetic testing runner
        if (stripos($user_agent, 'GTmetrix') !== false) {
            return true;
        }

        // SpeedCurve synthetic runner
        if (stripos($user_agent, 'SpeedCurve') !== false) {
            return true;
        }

        // Pingdom TMS (Transaction Monitoring System)
        if (stripos($user_agent, 'PingdomTMS') !== false) {
            return true;
        }

        return false;
    }

    /**
     * Append AI Scraper blocking rules to virtual robots.txt
     */
    public static function filter_dynamic_robots_txt(string $output, bool $public): string {
        $settings = SettingsManager::get_settings();

        $throttle_training = !empty($settings['waf_ai_throttle_training_scrapers']);
        $block_ai          = !empty($settings['waf_dynamic_robots_ai']) || !empty($settings['waf_block_ai_scrapers']);

        if (!$throttle_training && !$block_ai) {
            return $output;
        }

        $ai_rules = "\n# WebCare Pro Security - AI Content Harvester Rules\n";
        // Bulk training scrapers
        $training_scrapers = ['GPTBot', 'ChatGPT-User', 'CCBot', 'Bytespider', 'anthropic-ai', 'ClaudeBot', 'Diffbot', 'Cohere-ai'];

        foreach ($training_scrapers as $bot) {
            $ai_rules .= "User-agent: " . $bot . "\n";
            $ai_rules .= "Disallow: /\n\n";
        }

        // Allow search citations if enabled
        if (empty($settings['waf_ai_allow_search_citations'])) {
            $ai_rules .= "User-agent: PerplexityBot\nDisallow: /\n\n";
            $ai_rules .= "User-agent: OAI-SearchBot\nDisallow: /\n\n";
        }

        return $output . $ai_rules;
    }

    public const POW_COOKIE_NAME = 'webcare_pow_clearance';
    public const POW_DIFFICULTY  = 4; // 4 hex zeros = 16 leading zero bits (~65,536 hashes max)
    public const CLEARANCE_TTL   = 3600;

    /**
     * Verify if the client holds a valid PoW clearance cookie or just submitted a valid PoW solution.
     * Invoked when high-velocity reconnaissance or scraping anomaly is detected.
     */
    public static function verify_or_challenge_client(): void {
        $client_ip = class_exists('\\WebCareProScanner\\Firewall\\FirewallEngine') ? FirewallEngine::get_client_ip() : (isset($_SERVER['REMOTE_ADDR']) ? sanitize_text_field(wp_unslash($_SERVER['REMOTE_ADDR'])) : '0.0.0.0');
        $ua        = isset($_SERVER['HTTP_USER_AGENT']) ? sanitize_text_field(wp_unslash($_SERVER['HTTP_USER_AGENT'])) : '';

        if (self::has_valid_clearance_cookie($client_ip, $ua)) {
            return;
        }

        // phpcs:ignore WordPress.Security.NonceVerification.Missing
        if (isset($_POST['webcare_pow_challenge'], $_POST['webcare_pow_nonce'])) {
            // phpcs:ignore WordPress.Security.NonceVerification.Missing
            $challenge = sanitize_text_field(wp_unslash($_POST['webcare_pow_challenge']));
            // phpcs:ignore WordPress.Security.NonceVerification.Missing
            $nonce     = sanitize_text_field(wp_unslash($_POST['webcare_pow_nonce']));

            if (self::verify_pow_solution($challenge, $nonce, $client_ip, $ua)) {
                self::issue_clearance_cookie($client_ip, $ua);
                $req_uri = isset($_SERVER['REQUEST_URI']) ? esc_url_raw(wp_unslash($_SERVER['REQUEST_URI'])) : '/';
                wp_safe_redirect($req_uri);
                exit;
            }
        }

        self::render_webcrypto_challenge($client_ip, $ua);
    }

    /**
     * Inspect HTTP/2 & HTTP/3 pseudo-header ordering and letter-case anomalies.
     * Genuine modern web browsers (Chrome, Firefox, Safari) strictly send pseudo-headers
     * in standardized order (:method -> :authority -> :scheme -> :path) in lowercase.
     * Automated scripts (Python requests, Go net/http, custom cURL scrapers) often violate this.
     *
     * @return array|null Anomaly report if detected, null if clean or non-HTTP/2
     */
    public static function check_http2_pseudo_header_anomaly(): ?array {
        $protocol = isset($_SERVER['SERVER_PROTOCOL']) ? sanitize_text_field(wp_unslash($_SERVER['SERVER_PROTOCOL'])) : '';
        $is_h2 = (strpos($protocol, 'HTTP/2') !== false || strpos($protocol, 'HTTP/3') !== false || (!empty($_SERVER['HTTP2']) && $_SERVER['HTTP2'] === 'on'));

        // If not running under HTTP/2 or HTTP/3, skip check
        if (!$is_h2) {
            return null;
        }

        // Check if raw request headers can be retrieved
        $raw_headers = [];
        if (function_exists('getallheaders')) {
            $raw_headers = getallheaders();
        }

        if (empty($raw_headers) && is_array($_SERVER)) {
            foreach ($_SERVER as $k => $v) {
                if (str_starts_with($k, 'HTTP_')) {
                    $raw_headers[substr($k, 5)] = $v;
                }
            }
        }

        // Anomaly 1: Check for uppercase HTTP/2 headers if raw headers exposed
        if (!empty($raw_headers)) {
            foreach (array_keys($raw_headers) as $header_name) {
                if (is_string($header_name) && str_starts_with($header_name, ':')) {
                    if ($header_name !== strtolower($header_name)) {
                        return [
                            'anomaly'     => 'uppercase_pseudo_header',
                            'description' => sprintf('Invalid uppercase HTTP/2 pseudo-header detected: %s', esc_html($header_name)),
                            'severity'    => 'high',
                        ];
                    }
                }
            }
        }

        // Anomaly 2: Check for missing standard User-Agent or known script agent impersonating browser HTTP/2
        $ua = isset($_SERVER['HTTP_USER_AGENT']) ? sanitize_text_field(wp_unslash($_SERVER['HTTP_USER_AGENT'])) : '';
        if (preg_match('/^(python|go-http-client|curl|libwww|aiohttp)/i', $ua)) {
            return [
                'anomaly'     => 'script_http2_signature',
                'description' => sprintf('Script scraper "%s" connecting over HTTP/2 with automated bot signature.', esc_html($ua)),
                'severity'    => 'medium',
            ];
        }

        // Anomaly 3: Client-Hint (Sec-CH-UA) Consistency Check (CAF Phase 3)
        // Modern Chromium browsers (Chrome >= 89, Edge >= 89) on HTTPS always emit Sec-CH-UA, Sec-CH-UA-Mobile, and Sec-CH-UA-Platform.
        // Scrapers claiming modern Chrome User-Agents without Client-Hints or with platform contradictions are flagged.
        $client_hint_anomaly = self::check_client_hint_consistency($ua, $raw_headers);
        if ($client_hint_anomaly !== null) {
            return $client_hint_anomaly;
        }

        return null;
    }

    /**
     * Inspect Client-Hint headers (Sec-CH-UA, Sec-CH-UA-Mobile, Sec-CH-UA-Platform)
     * against declared User-Agent.
     *
     * @param string $ua
     * @param array $headers
     * @return array|null Anomaly description or null
     */
    public static function check_client_hint_consistency(string $ua, array $headers): ?array {
        if (empty($ua) || !is_ssl()) {
            return null; // Client-Hints are standard on HTTPS
        }

        // Normalize header keys to uppercase for search
        $normalized = [];
        foreach ($headers as $k => $v) {
            $normalized[strtoupper(str_replace('-', '_', (string) $k))] = (string) $v;
        }

        $sec_ch_ua          = $normalized['SEC_CH_UA'] ?? ($normalized['HTTP_SEC_CH_UA'] ?? '');
        $sec_ch_ua_mobile   = $normalized['SEC_CH_UA_MOBILE'] ?? ($normalized['HTTP_SEC_CH_UA_MOBILE'] ?? '');
        $sec_ch_ua_platform = $normalized['SEC_CH_UA_PLATFORM'] ?? ($normalized['HTTP_SEC_CH_UA_PLATFORM'] ?? '');

        // Pattern: User-Agent claims modern Chrome on Desktop (Version >= 90)
        $is_modern_desktop_chrome = false;
        if (preg_match('/Chrome\/([0-9]{2,3})\./i', $ua, $matches)) {
            $version = (int) $matches[1];
            if ($version >= 95 && !preg_match('/(Mobile|Android|iPhone|iPad)/i', $ua)) {
                $is_modern_desktop_chrome = true;
            }
        }

        // Check 1: User-Agent claims modern Chrome desktop but Sec-CH-UA header is absent
        // NOTE: Privacy-focused browsers like Brave, Tor, or hardened Firefox forks intentionally strip Sec-CH-UA,
        // and search crawlers or privacy extensions may omit it. Do not hard-block; only evaluate if platform contradicts.

        // Check 2: Mobile Client-Hint mismatch (?1 on desktop UA or ?0 on mobile UA)
        if (!empty($sec_ch_ua_mobile)) {
            $is_mobile_ua = (bool) preg_match('/(Mobile|Android|iPhone|iPad)/i', $ua);
            if ($sec_ch_ua_mobile === '?1' && !$is_mobile_ua) {
                return [
                    'anomaly'     => 'client_hint_mobile_mismatch',
                    'description' => 'Sec-CH-UA-Mobile indicates mobile client (?1) but User-Agent indicates desktop.',
                    'severity'    => 'medium',
                ];
            }
        }

        // Check 3: Platform contradiction (e.g. Windows UA with Linux/Android Client-Hint)
        if (!empty($sec_ch_ua_platform)) {
            $platform_clean = strtolower(trim($sec_ch_ua_platform, '" '));
            if ($platform_clean === 'windows' && preg_match('/(Linux|Macintosh|Android)/i', $ua)) {
                return [
                    'anomaly'     => 'client_hint_platform_mismatch',
                    'description' => 'Sec-CH-UA-Platform ("Windows") contradicts non-Windows operating system in User-Agent.',
                    'severity'    => 'high',
                ];
            } elseif ($platform_clean === 'linux' && preg_match('/(Windows NT|Macintosh)/i', $ua)) {
                return [
                    'anomaly'     => 'client_hint_platform_mismatch',
                    'description' => 'Sec-CH-UA-Platform ("Linux") contradicts Windows/Mac operating system in User-Agent.',
                    'severity'    => 'high',
                ];
            }
        }

        return null;
    }

    /**
     * Render the stateless WebCrypto Proof-of-Work (PoW) HTML5 challenge.
     * Public alias for active bot defense and suspicious IP mitigation.
     *
     * @param string $ip
     * @param string $action_context
     */
    public static function render_pow_challenge(string $ip, string $action_context = 'High-velocity probe'): void {
        $ua = isset($_SERVER['HTTP_USER_AGENT']) ? sanitize_text_field(wp_unslash($_SERVER['HTTP_USER_AGENT'])) : '';
        self::render_webcrypto_challenge($ip, $ua);
    }

    /**
     * Retrieve a persistent, cryptographically secure salt for Proof-of-Work challenge and cookie signing.
     * Prevents static fallback strings if NONCE_KEY or AUTH_KEY constants are undefined.
     *
     * @param string $type 'nonce' | 'auth'
     * @return string
     */
    public static function get_secure_pow_salt(string $type = 'nonce'): string {
        if ($type === 'auth') {
            if (function_exists('wp_salt')) {
                return wp_salt('auth');
            }
            if (defined('AUTH_KEY') && AUTH_KEY !== '') {
                return AUTH_KEY;
            }
        } else {
            if (function_exists('wp_salt')) {
                return wp_salt('nonce');
            }
            if (defined('NONCE_KEY') && NONCE_KEY !== '') {
                return NONCE_KEY;
            }
        }

        $opt_key = 'webcareproscan_pow_salt_' . $type;
        $salt = get_option($opt_key);
        if (empty($salt) || !is_string($salt)) {
            $salt = function_exists('wp_generate_password')
                ? wp_generate_password(64, true, true)
                : hash('sha256', bin2hex(random_bytes(32)) . microtime());
            update_option($opt_key, $salt, false);
        }
        return $salt;
    }

    public static function generate_challenge(string $ip, string $ua, ?int $target_window = null): string {
        $window = (string) ($target_window !== null ? $target_window : (int) floor(time() / 300)); // Valid for 5-minute window
        $salt   = self::get_secure_pow_salt('nonce');
        $mac    = hash_hmac('sha256', $ip . '|' . $ua . '|' . $window, $salt);
        return $window . '.' . substr($mac, 0, 32);
    }

    public static function verify_pow_solution(string $challenge, string $nonce, string $ip, string $ua): bool {
        $cur_window = (int) floor(time() / 300);
        $expected_current = self::generate_challenge($ip, $ua, $cur_window);
        $expected_prev    = self::generate_challenge($ip, $ua, $cur_window - 1);

        $matched = hash_equals($expected_current, $challenge) || hash_equals($expected_prev, $challenge);
        if (!$matched) {
            return false;
        }

        // Anti-replay: Single-use consumption of solved PoW token
        $token_hash = hash('sha256', $challenge . ':' . $nonce);
        $used_key   = 'webcareproscan_pow_used_' . substr($token_hash, 0, 32);
        if (get_transient($used_key)) {
            return false; // Replayed solution
        }

        $digest = hash('sha256', $challenge . ':' . $nonce);
        if (strpos($digest, str_repeat('0', self::POW_DIFFICULTY)) !== 0) {
            return false;
        }

        // Mark as consumed for 600s (covers current + previous window)
        set_transient($used_key, 1, 600);
        return true;
    }

    public static function issue_clearance_cookie(string $ip, string $ua): void {
        $expires = time() + self::CLEARANCE_TTL;
        $salt    = self::get_secure_pow_salt('auth');
        $sig     = hash_hmac('sha256', $ip . '|' . $ua . '|' . $expires, $salt);
        $value   = $expires . '.' . $sig;

        $_COOKIE[self::POW_COOKIE_NAME] = $value;

        setcookie(self::POW_COOKIE_NAME, $value, [
            'expires'  => $expires,
            'path'     => defined('COOKIEPATH') && COOKIEPATH ? COOKIEPATH : '/',
            'secure'   => is_ssl(),
            'httponly' => true,
            'samesite' => 'Lax',
        ]);
    }

    public static function has_valid_clearance_cookie(string $ip, string $ua): bool {
        if (empty($_COOKIE[self::POW_COOKIE_NAME])) {
            return false;
        }

        $raw   = sanitize_text_field(wp_unslash($_COOKIE[self::POW_COOKIE_NAME]));
        $parts = explode('.', $raw, 2);
        if (count($parts) !== 2) {
            return false;
        }

        $expires = (int) $parts[0];
        if (time() > $expires) {
            return false;
        }

        $salt         = self::get_secure_pow_salt('auth');
        $expected_sig = hash_hmac('sha256', $ip . '|' . $ua . '|' . $expires, $salt);
        return hash_equals($expected_sig, $parts[1]);
    }

    /**
     * Inspect and verify an incoming X-WebCare-PoW-Solution header for headless / REST / API clients.
     * If valid, issues a clearance cookie and returns true so the request can proceed without a 429 block.
     *
     * @param string $ip
     * @param string $ua
     * @return bool
     */
    public static function verify_and_clear_pow_header(string $ip, string $ua): bool {
        $pow_hdr = isset($_SERVER['HTTP_X_WEBCARE_POW_SOLUTION'])
            ? sanitize_text_field(wp_unslash($_SERVER['HTTP_X_WEBCARE_POW_SOLUTION']))
            : '';
        if ($pow_hdr !== '' && strpos($pow_hdr, ':') !== false) {
            [$ch, $no] = explode(':', $pow_hdr, 2);
            if (self::verify_pow_solution($ch, $no, $ip, $ua)) {
                self::issue_clearance_cookie($ip, $ua);
                return true;
            }
        }
        return false;
    }

    public static function render_webcrypto_challenge(string $ip, string $ua): void {
        // Allow headless/REST/AJAX clients to present a solved PoW token via X-WebCare-PoW-Solution: challenge:nonce
        if (self::verify_and_clear_pow_header($ip, $ua)) {
            return;
        }

        $challenge = self::generate_challenge($ip, $ua);
        $zeros     = str_repeat('0', self::POW_DIFFICULTY);

        status_header(429);
        nocache_headers();

        // Protocol-Appropriate Enforcement: Return structured JSON 429 on REST, AJAX, and WooCommerce JSON endpoints
        $raw_uri = isset($_SERVER['REQUEST_URI']) ? sanitize_text_field(wp_unslash($_SERVER['REQUEST_URI'])) : '';
        $is_json_surface = (function_exists('wp_is_json_request') && wp_is_json_request())
            || (defined('REST_REQUEST') && REST_REQUEST)
            || (function_exists('wp_doing_ajax') && wp_doing_ajax())
            || strpos($raw_uri, 'wc-ajax=') !== false
            || strpos($raw_uri, '/wp-json/') !== false
            || strpos($raw_uri, 'rest_route=') !== false;

        if ($is_json_surface) {
            header('Content-Type: application/json; charset=utf-8');
            header('Retry-After: 30');
            echo wp_json_encode([
                'code'         => 'webcare_pow_challenge_required',
                'result'       => 'failure',
                'status'       => 429,
                'pow_required' => true,
                'challenge'    => $challenge,
                'difficulty'   => self::POW_DIFFICULTY,
                'message'      => __('Browser cryptographic verification (Proof-of-Work) is required before proceeding.', 'webcare-pro-security'),
                'messages'     => '<ul class="woocommerce-error" role="alert"><li>' . esc_html__('Security verification required. Please reload the page to complete browser verification.', 'webcare-pro-security') . '</li></ul>',
            ]);
            exit;
        }
        ?>
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width,initial-scale=1">
            <title><?php esc_html_e('Security Verification', 'webcare-pro-security'); ?></title>
        </head>
        <body style="font-family:system-ui,-apple-system,sans-serif;display:flex;align-items:center;justify-content:center;height:100vh;margin:0;background:#0f172a;color:#f8fafc;">
            <div style="text-align:center;max-width:420px;padding:32px;background:#1e293b;border-radius:12px;border:1px solid rgba(255,255,255,0.08);box-shadow:0 10px 25px -5px rgba(0,0,0,0.5);">
                <div style="font-size:36px;margin-bottom:12px;">🛡️</div>
                <h2 style="margin:0 0 8px 0;font-size:20px;font-weight:600;"><?php esc_html_e('Browser Integrity Verification', 'webcare-pro-security'); ?></h2>
                <p id="webcare-status" style="color:#94a3b8;font-size:14px;margin:0 0 20px 0;line-height:1.5;"><?php esc_html_e('Verifying browser cryptographic environment to prevent automated scraping...', 'webcare-pro-security'); ?></p>
                <div style="height:4px;width:100%;background:#334155;border-radius:2px;overflow:hidden;position:relative;">
                    <div style="height:100%;width:50%;background:#4f46e5;border-radius:2px;animation:webcarePulse 1.2s infinite ease-in-out;"></div>
                </div>
                <form id="webcare-pow-form" method="POST" action="">
                    <input type="hidden" name="webcare_pow_challenge" value="<?php echo esc_attr($challenge); ?>">
                    <input type="hidden" name="webcare_pow_nonce" id="webcare-pow-nonce" value="">
                </form>
            </div>
            <style>
                @keyframes webcarePulse {
                    0% { transform: translateX(-100%); }
                    100% { transform: translateX(250%); }
                }
            </style>
            <script>
            (async function() {
                const challenge = <?php echo wp_json_encode($challenge); ?>;
                const target = <?php echo wp_json_encode($zeros); ?>;
                const enc = new TextEncoder();
                let nonce = 0;
                while (true) {
                    const buf = await crypto.subtle.digest('SHA-256', enc.encode(challenge + ':' + nonce));
                    const hex = Array.from(new Uint8Array(buf)).map(b => b.toString(16).padStart(2, '0')).join('');
                    if (hex.startsWith(target)) {
                        document.getElementById('webcare-pow-nonce').value = String(nonce);
                        document.getElementById('webcare-pow-form').submit();
                        return;
                    }
                    nonce++;
                }
            })();
            </script>
        </body>
        </html>
        <?php
        exit;
    }
}
