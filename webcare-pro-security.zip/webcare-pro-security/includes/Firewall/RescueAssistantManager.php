<?php
/**
 * Rescue Assistant, Daily Security Story, Admin Bar Quick-Unblock & Safe Update Manager
 *
 * Powers non-technical site-owner safety controls:
 * - "Something Not Working?" 15-minute diagnostic translator & 1-click trust/allow rules
 * - 15-minute Strict Firewall Test Pause with WP-Cron auto re-arm
 * - Plain-English Weekly/Daily Security Story telemetry
 * - WordPress Admin Bar Quick Unblock Customer (#WEBCARE-XXXX) popover
 * - Pre-Update Auto-Backup & 1-Click Plugin Rollback orchestration
 *
 * Author: Mir Alamin (WebCare Pro)
 * Senior Linux SysAdmin & WordPress Security Engineer
 *
 * @package WebCareProScanner\Firewall
 */

namespace WebCareProScanner\Firewall;

if (!defined('ABSPATH')) {
    exit;
}

class RescueAssistantManager {

    const OPTION_PAUSED_UNTIL    = 'webcareproscan_waf_rescue_paused_until';
    const OPTION_TRUSTED_ACTIONS = 'webcareproscan_rescue_trusted_actions';
    const OPTION_SAFE_UPDATES    = 'webcareproscan_safe_update_backups';
    const CRON_REARM_HOOK        = 'webcareproscan_auto_rearm_waf';
    const CRON_AUTOPILOT_HOOK    = 'webcareproscan_custom_rules_autopilot_cron';

    /**
     * Register hooks for cron auto-rearm, 48h auto-pilot promotion, and WordPress Admin Bar popover.
     */
    public static function init(): void {
        if (class_exists('\\WebCareProScanner\\System\\Cron\\CronControlCenter')) {
            add_action(self::CRON_REARM_HOOK, static function () {
                \WebCareProScanner\System\Cron\CronControlCenter::invoke_task_handler(self::CRON_REARM_HOOK, 'wp_cron');
            });
            add_action(self::CRON_AUTOPILOT_HOOK, static function () {
                \WebCareProScanner\System\Cron\CronControlCenter::invoke_task_handler(self::CRON_AUTOPILOT_HOOK, 'wp_cron');
            });

            add_action('init', static function () {
                \WebCareProScanner\System\Cron\CronControlCenter::ensure_scheduled(self::CRON_AUTOPILOT_HOOK, HOUR_IN_SECONDS, 'hourly');
            }, 20);
        } else {
            add_action(self::CRON_REARM_HOOK, [__CLASS__, 'resume_strict_firewall']);
            add_action(self::CRON_AUTOPILOT_HOOK, [__CLASS__, 'run_autopilot_cron']);

            if (!wp_next_scheduled(self::CRON_AUTOPILOT_HOOK)) {
                wp_schedule_event(time() + HOUR_IN_SECONDS, 'hourly', self::CRON_AUTOPILOT_HOOK);
            }
        }

        add_action('admin_bar_menu', [__CLASS__, 'register_admin_bar_nodes'], 95);
        add_action('admin_enqueue_scripts', [__CLASS__, 'enqueue_admin_bar_assets']);
        add_action('wp_enqueue_scripts', [__CLASS__, 'enqueue_admin_bar_assets']);
    }

    /**
     * Cron handler for Modular WAF 48-hour Smart Auto-Pilot rule promotion.
     */
    public static function run_autopilot_cron(): void {
        if (class_exists('\\WebCareProScanner\\Firewall\\CustomRules\\ModularFirewallSynthesizer')) {
            \WebCareProScanner\Firewall\CustomRules\ModularFirewallSynthesizer::evaluate_autopilot_promotions();
        }
    }

    /**
     * Path to marker files read cleanly by the 0ms Preload Micro-WAF before WordPress loads.
     * Enforces canonical storage in WP_CONTENT_DIR . '/webcare-waf/' via WafVaultManager.
     */
    public static function get_marker_path(): string {
        if (class_exists('\\WebCareProScanner\\Firewall\\Core\\WafVaultManager')) {
            return \WebCareProScanner\Firewall\Core\WafVaultManager::get_safe_mode_marker_path();
        }
        $base = defined('WP_CONTENT_DIR') ? WP_CONTENT_DIR : ABSPATH . 'wp-content';
        return wp_normalize_path(rtrim($base, '/\\') . '/webcare-waf/.rescue_pause_until');
    }

    /**
     * Write lightweight runtime marker file using native WP_Filesystem when direct, with fallback for cron/early hooks.
     *
     * @param string $path
     * @param string $content
     * @return bool True on success, false on failure
     */
    private static function write_marker_file(string $path, string $content): bool {
        $dir = dirname($path);
        // phpcs:disable WordPress.WP.AlternativeFunctions.file_system_operations_chmod
        if (!is_dir($dir)) {
            wp_mkdir_p($dir);
            @chmod($dir, 0750);
        }

        if (!function_exists('WP_Filesystem')) {
            require_once ABSPATH . 'wp-admin/includes/file.php';
        }
        global $wp_filesystem;
        if (empty($wp_filesystem)) {
            \WP_Filesystem();
        }

        if ($wp_filesystem && $wp_filesystem->method === 'direct') {
            $written = $wp_filesystem->put_contents($path, $content, FS_CHMOD_FILE);
            if ($written) {
                @chmod($path, 0600);
                return true;
            }
        }

        $res = @file_put_contents($path, $content);
        if ($res !== false) {
            @chmod($path, 0600);
            return true;
        }
        // phpcs:enable

        return false;
    }

    /**
     * Check whether strict WAF blocking is currently paused for the 15-minute troubleshooting window.
     */
    public static function is_strict_paused(): bool {
        $until = (int) get_option(self::OPTION_PAUSED_UNTIL, 0);
        if ($until > time()) {
            return true;
        }
        if ($until > 0) {
            self::resume_strict_firewall();
        }
        return false;
    }

    /**
     * Return structured countdown & pause state for UI banners and header badges.
     */
    public static function get_pause_status(): array {
        $until     = (int) get_option(self::OPTION_PAUSED_UNTIL, 0);
        $now       = time();
        $is_paused = ($until > $now);
        if ($until > 0 && !$is_paused) {
            self::resume_strict_firewall();
            $until = 0;
        }

        return [
            'paused'            => $is_paused,
            'paused_until'      => $is_paused ? $until : 0,
            'seconds_remaining' => $is_paused ? max(0, $until - $now) : 0,
            'rearm_at_gmt'      => $is_paused ? gmdate('Y-m-d H:i:s', $until) : null,
        ];
    }

    /**
     * Check whether the current user can mutate network-wide preboot WAF policy.
     */
    private static function can_manage_preboot_policy(): bool {
        if (function_exists('is_multisite') && is_multisite()) {
            return current_user_can('manage_network_options');
        }
        return current_user_can('manage_options');
    }

    /**
     * Pause strict WAF enforcement for 15 minutes (Monitor-Only Test Mode with automatic cron re-arm).
     */
    public static function pause_strict_firewall_15m(): array|\WP_Error {
        if (!self::can_manage_preboot_policy()) {
            return new \WP_Error('waf_safe_mode_unauthorized', __('Only Network Admins (or site administrators on single-site) can activate Safe Mode.', 'webcare-pro-security'));
        }

        $until = time() + (15 * MINUTE_IN_SECONDS);
        $marker = self::get_marker_path();
        $written = self::write_marker_file($marker, (string) $until);

        if (!$written) {
            return new \WP_Error('waf_safe_mode_write_failed', __('Failed to write Safe Mode marker file to storage.', 'webcare-pro-security'));
        }

        update_option(self::OPTION_PAUSED_UNTIL, $until, false);

        wp_clear_scheduled_hook(self::CRON_REARM_HOOK);
        wp_schedule_single_event($until, self::CRON_REARM_HOOK);

        if (class_exists('\\WebCareProScanner\\System\\AuditLogger')) {
            \WebCareProScanner\System\AuditLogger::log('safe_mode_enabled', [
                'user_id'      => get_current_user_id(),
                'ip'           => class_exists('\\WebCareProScanner\\Firewall\\FirewallEngine') ? \WebCareProScanner\Firewall\FirewallEngine::get_client_ip() : (isset($_SERVER['REMOTE_ADDR']) ? sanitize_text_field(wp_unslash((string) $_SERVER['REMOTE_ADDR'])) : ''),
                'paused_until' => gmdate('c', $until),
                'ttl_seconds'  => 15 * MINUTE_IN_SECONDS,
            ]);
        }

        if (class_exists('\\WebCareProScanner\\System\\WebCareActivityLogger')) {
            \WebCareProScanner\System\WebCareActivityLogger::notice('waf_rescue_pause_15m', 'firewall', [
                'paused_until' => gmdate('c', $until),
                'description'  => __('Strict Firewall rules paused for 15 minutes (Test Mode) via Rescue Assistant. Auto re-arm scheduled.', 'webcare-pro-security'),
            ]);
        }

        return array_merge(
            [
                'success' => true,
                'message' => __('Strict firewall rules are paused for 15 minutes (Test Mode). Protection will re-arm automatically after 15 minutes.', 'webcare-pro-security'),
            ],
            self::get_pause_status()
        );
    }

    /**
     * Resume strict WAF enforcement immediately or when the 15-minute timer expires.
     */
    public static function resume_strict_firewall(): array {
        if (!self::can_manage_preboot_policy()) {
            return ['success' => false, 'message' => __('Only Network Admins (or site administrators on single-site) can resume the preboot firewall.', 'webcare-pro-security')];
        }
        delete_option(self::OPTION_PAUSED_UNTIL);
        wp_clear_scheduled_hook(self::CRON_REARM_HOOK);

        $marker = self::get_marker_path();
        if (file_exists($marker)) {
            wp_delete_file($marker);
        }

        // Verify marker deletion to prevent silent degraded state where Micro-WAF stays paused
        if (file_exists($marker)) {
            if (class_exists('\\WebCareProScanner\\System\\AuditLogger')) {
                \WebCareProScanner\System\AuditLogger::log('safe_mode_resume_failed', [
                    'user_id' => get_current_user_id(),
                    'marker'  => $marker,
                    'error'   => 'Safe mode marker file could not be unlinked; pre-WordPress Micro-WAF remains paused.',
                ]);
            }

            return array_merge(
                [
                    'success' => false,
                    'message' => __('Warning: Strict firewall protection could not delete the Safe Mode marker file. Micro-WAF remains paused.', 'webcare-pro-security'),
                ],
                self::get_pause_status()
            );
        }

        if (class_exists('\\WebCareProScanner\\System\\AuditLogger')) {
            \WebCareProScanner\System\AuditLogger::log('safe_mode_disabled', [
                'user_id' => get_current_user_id(),
                'ip'      => class_exists('\\WebCareProScanner\\Firewall\\FirewallEngine') ? \WebCareProScanner\Firewall\FirewallEngine::get_client_ip() : (isset($_SERVER['REMOTE_ADDR']) ? sanitize_text_field(wp_unslash((string) $_SERVER['REMOTE_ADDR'])) : ''),
            ]);
        }

        if (class_exists('\\WebCareProScanner\\System\\WebCareActivityLogger')) {
            \WebCareProScanner\System\WebCareActivityLogger::notice('waf_rescue_resumed', 'firewall', [
                'description' => __('Strict Firewall rules resumed cleanly from Test Mode.', 'webcare-pro-security'),
            ]);
        }

        return array_merge(
            [
                'success' => true,
                'message' => __('Strict firewall protection is active again.', 'webcare-pro-security'),
            ],
            self::get_pause_status()
        );
    }

    /**
     * Retrieve permanently trusted actions saved via "Trust & Allow This Action Permanently".
     */
    public static function get_trusted_actions(): array {
        $list = get_option(self::OPTION_TRUSTED_ACTIONS, []);
        return is_array($list) ? array_values($list) : [];
    }

    /**
     * Check whether the current request or rule matches any permanently trusted Rescue exemption.
     * Enforces strict canonical route equality (or explicit /* prefix match), stored method,
     * exact parameter key matching, and user role validation.
     * Zero-tolerance exploit signatures (SQLi, RCE, arbitrary file inclusions) are NEVER bypassed.
     *
     * @param string $rule_id
     * @param string $clean_uri
     * @param string $ajax_action
     * @param string $rest_query
     * @param string $method HTTP method (default '')
     * @param string $param_key Target parameter key (default '')
     * @return bool
     */
    /**
     * Confirmed zero-tolerance exploit rules that can NEVER be exempted by customer allowlists or Rescue Assistant.
     */
    public const ZERO_TOLERANCE_RULES = [
        'WAF-SQLI', 'WAF-SQLI-INJECTION', 'WAF-SQLI-DEEP-TOKEN-CHAIN', 'WAF-SQLI-HEX-BINARY-ENCODED',
        'WAF-RCE', 'WAF-RCE-INJECTION', 'WAF-RCE-PHP-INJECTION', 'WAF-PHP-CODE-INJECTION',
        'WAF-LFI-TRAVERSAL', 'WAF-FILE-INCLUSION', 'WAF-ARBITRARY-FILE-WRITE', 'WAF-SYSTEM-COMMAND-EXEC',
        'WAF-PHP-OBJECT-INJECTION', 'WAF-OBJECT-STREAM-INJECTION', 'WAF-XXE-INJECTION',
        'WAF-SSRF-METADATA', 'WAF-AJAX-SHORTCODE-GADGET', 'WAF-POLYGLOT-UPLOAD-TRAP'
    ];

    /**
     * Check if a given rule identifier is a confirmed zero-tolerance exploit signature.
     */
    public static function is_zero_tolerance_rule(string $rule_id): bool {
        $upper = strtoupper(trim($rule_id));
        if ($upper === '') {
            return false;
        }

        // Consult canonical confirmed-exploit registry from FirewallEngine
        if (class_exists('\\WebCareProScanner\\Firewall\\FirewallEngine')) {
            $def = \WebCareProScanner\Firewall\FirewallEngine::get_confirmed_exploit_definition($upper);
            if ($def !== null) {
                return true;
            }
        }

        foreach (self::ZERO_TOLERANCE_RULES as $zt) {
            if ($upper === $zt || str_starts_with($upper, $zt . '-') || str_starts_with($upper, $zt . '_')) {
                return true;
            }
        }
        return false;
    }

    /**
     * Check whether a specific rule, URI, AJAX action, or REST route has been trusted.
     * Evaluates granular scope (rule_id, clean_uri, method, param_key, user_role).
     */
    public static function is_rule_or_request_trusted(
        string $rule_id,
        string $clean_uri,
        string $ajax_action = '',
        string $rest_query = '',
        string $method = '',
        string $user_role = '',
        string $param_key = ''
    ): bool {
        // Zero-tolerance exploit signatures must NEVER be exempted by customer allowlists
        if (self::is_zero_tolerance_rule($rule_id)) {
            return false;
        }

        $trusted = self::get_trusted_actions();
        if (empty($trusted)) {
            return false;
        }

        $rule_lc   = strtolower($rule_id);
        $uri_lc    = strtolower(rtrim($clean_uri, '/'));
        $act_lc    = strtolower($ajax_action);
        $rest_lc   = strtolower(rtrim($rest_query, '/'));
        $server_method = isset($_SERVER['REQUEST_METHOD']) ? sanitize_text_field(wp_unslash((string) $_SERVER['REQUEST_METHOD'])) : 'GET';
        $method_uc = strtoupper($method ?: $server_method);
        $pkey_lc   = strtolower($param_key);

        $current_user_roles = [];
        if (function_exists('wp_get_current_user')) {
            $user = wp_get_current_user();
            if ($user && !empty($user->roles)) {
                $current_user_roles = array_map('strtolower', (array) $user->roles);
            }
        }

        foreach ($trusted as $item) {
            $item_rule = strtolower((string) ($item['rule_id'] ?? ''));
            $item_type = strtolower((string) ($item['type'] ?? ''));
            $val       = strtolower(trim((string) ($item['value'] ?? '')));
            $req_role  = strtolower(trim((string) ($item['user_role'] ?? '')));
            $req_pkey  = strtolower(trim((string) ($item['param_key'] ?? '')));
            $req_meth  = strtoupper(trim((string) ($item['method'] ?? '')));

            // 1. Role validation: if allowlist specifies a role, current user must hold it
            if ($req_role !== '') {
                if (!in_array($req_role, $current_user_roles, true)) {
                    continue;
                }
            }

            // 2. Method validation: HTTP method is mandatory. Reject if trust entry has no method or request method mismatches.
            if ($req_meth === '' || $req_meth !== $method_uc) {
                continue;
            }

            // 3. Parameter key validation: if allowlist specifies a param_key, check parameter context.
            // Strict scope requirement: If the allowlist entry requires a param_key, reject the match
            // if the caller's parameter context is empty or does not match req_pkey.
            // If the incoming request has a non-empty param_key (parameter-specific detector), the trust entry MUST also specify that exact param_key.
            if ($req_pkey !== '') {
                if ($pkey_lc === '' || $pkey_lc !== $req_pkey) {
                    continue;
                }
            } elseif ($pkey_lc !== '') {
                // Incoming detector is parameter-specific, but trust entry lacks a parameter constraint: reject match
                continue;
            }

            // 4. Per-Detector Co-Verification Invariant (v3.23.2):
            // Every customer trust exemption must match the intended detector ($item_rule === $rule_lc).
            // A route/action trust entry for detector A must NEVER suppress an unrelated detector B.
            // If the trust item specifies a rule_id, it must match the current rule_id strictly.
            if ($item_rule === '' || $rule_lc === '' || $item_rule !== $rule_lc) {
                continue;
            }

            // 5. Global rule-only exemptions are prohibited in customer trust (strictly requires route/action target)
            if ($val === '') {
                continue;
            }

            // 6. AJAX action check: exact match
            if ($item_type === 'ajax' && $act_lc !== '' && $act_lc === $val) {
                return true;
            }

            // 7. REST route check: canonical match or explicit wildcard /*
            if ($item_type === 'rest') {
                $rest_target = $rest_lc !== '' ? $rest_lc : $uri_lc;
                $val_clean = rtrim($val, '/');
                if (str_ends_with($val, '/*')) {
                    $prefix = rtrim(substr($val, 0, -2), '/');
                    // Enforce path-segment boundary on /* wildcards (matches prefix and prefix/... but never prefix-admin)
                    if ($rest_target === $prefix || str_starts_with($rest_target, $prefix . '/')) {
                        return true;
                    }
                } elseif ($rest_target === $val_clean) {
                    return true;
                }
            }

            // 8. URI check: canonical exact match or explicit wildcard /*
            if ($item_type === 'uri') {
                $val_clean = rtrim($val, '/');
                if (str_ends_with($val, '/*')) {
                    $prefix = rtrim(substr($val, 0, -2), '/');
                    // Enforce path-segment boundary on /* wildcards (matches prefix and prefix/... but never prefix-admin)
                    if ($uri_lc === $prefix || str_starts_with($uri_lc, $prefix . '/')) {
                        return true;
                    }
                } elseif ($uri_lc === $val_clean) {
                    return true;
                }
            }

            // Note: Global rule-only exemptions (type === 'rule') are strictly disallowed in customer trust.
            // Customer trust must always be bound to an authentic URI, AJAX action, or REST route target.
        }

        return false;
    }

    /**
     * Check incoming HTTP request against Rescue permanently trusted actions inside FirewallEngine.
     * Reads AJAX action strictly from queryParams or formParams (never $_REQUEST).
     */
    public static function is_incoming_request_trusted(string $request_uri, string $rule_id = '', string $param_key = '', ?\WebCareProScanner\Contracts\RequestContext $ctx = null): bool {
        $clean_uri = strtolower((string) strtok($request_uri, '?'));

        if ($ctx !== null) {
            $ajax_act = (string) ($ctx->queryParams['action'] ?? ($ctx->formParams['action'] ?? ''));
            $rest_q   = strtolower((string) ($ctx->queryParams['rest_route'] ?? ''));
            $method   = $ctx->method;
        } else {
            // phpcs:disable WordPress.Security.NonceVerification.Recommended, WordPress.Security.NonceVerification.Missing
            $ajax_act = isset($_GET['action'])
                ? sanitize_key(wp_unslash($_GET['action']))
                : (isset($_POST['action']) ? sanitize_key(wp_unslash($_POST['action'])) : '');
            $rest_q   = isset($_GET['rest_route']) ? strtolower(sanitize_text_field(wp_unslash($_GET['rest_route']))) : '';
            // phpcs:enable
            $method   = isset($_SERVER['REQUEST_METHOD']) ? sanitize_text_field(wp_unslash((string) $_SERVER['REQUEST_METHOD'])) : 'GET';
        }

        return self::is_rule_or_request_trusted($rule_id, $clean_uri, $ajax_act, $rest_q, $method, '', $param_key);
    }

    /**
     * Persist a permanent trusted-action exemption + unblock client IP if provided.
     */
    public static function trust_and_allow_action(array $params): array {
        if (function_exists('is_multisite') && is_multisite() && !current_user_can('manage_network_options')) {
            return ['success' => false, 'message' => __('Only Network Admins can modify preboot allowlists on Multisite.', 'webcare-pro-security')];
        }
        $type      = sanitize_key($params['type'] ?? 'uri');
        $value     = sanitize_text_field(trim((string) ($params['value'] ?? '')));
        $rule_id   = sanitize_text_field(trim((string) ($params['rule_id'] ?? '')));
        $label     = sanitize_text_field(trim((string) ($params['label'] ?? '')));
        $ip        = sanitize_text_field(trim((string) ($params['ip'] ?? '')));
        $param_key = sanitize_text_field(trim((string) ($params['param_key'] ?? '')));
        $user_role = sanitize_key(trim((string) ($params['user_role'] ?? '')));
        $method    = strtoupper(sanitize_key(trim((string) ($params['method'] ?? ''))));

        // Customer trust must specify an explicit, valid route target type (uri, rest, ajax)
        $allowed_types = ['uri', 'rest', 'ajax'];
        if (!in_array($type, $allowed_types, true)) {
            return [
                'success' => false,
                'code'    => 'invalid_target_type',
                'message' => __('Security Invariant: Customer trust requires a concrete route/action target type (uri, rest, ajax). Global rule-only exemptions are prohibited.', 'webcare-pro-security'),
            ];
        }

        if ($value === '' || $rule_id === '') {
            return ['success' => false, 'message' => __('Both action route target and rule identifier are strictly required for scoped customer trust.', 'webcare-pro-security')];
        }

        // Method validation: Customer trust must specify a valid, non-empty HTTP method
        $valid_methods = ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'HEAD', 'OPTIONS'];
        if ($method === '' || !in_array($method, $valid_methods, true)) {
            return [
                'success' => false,
                'code'    => 'invalid_method',
                'message' => __('Security Invariant: A valid, non-empty HTTP method is required for scoped customer trust.', 'webcare-pro-security'),
            ];
        }

        // Centralized Zero-Tolerance Invariant: Confirmed exploit rules can NEVER be exempted
        if (self::is_zero_tolerance_rule($rule_id)) {
            return [
                'success' => false,
                'code'    => 'zero_tolerance_rule',
                'message' => __('Security Invariant: Confirmed SQLi/RCE/LFI zero-tolerance exploit rules cannot be exempted.', 'webcare-pro-security'),
            ];
        }

        $trusted = self::get_trusted_actions();
        $key     = strtolower($type . ':' . ($value ?: $rule_id) . ($method !== '' ? ':' . $method : '') . ($param_key !== '' ? ':' . $param_key : '') . ($user_role !== '' ? ':' . $user_role : ''));
        $exists  = false;
        foreach ($trusted as $item) {
            $item_key = strtolower(
                ($item['type'] ?? '') . ':' .
                (($item['value'] ?? '') ?: ($item['rule_id'] ?? '')) .
                (!empty($item['method']) ? ':' . $item['method'] : '') .
                (!empty($item['param_key']) ? ':' . $item['param_key'] : '') .
                (!empty($item['user_role']) ? ':' . $item['user_role'] : '')
            );
            if ($item_key === $key) {
                $exists = true;
                break;
            }
        }

        if (!$exists) {
            $trusted[] = [
                'id'         => 'trust_' . substr(md5($key), 0, 8),
                'type'       => $type,
                'value'      => $value,
                'rule_id'    => $rule_id,
                'method'     => $method,
                'param_key'  => $param_key,
                'user_role'  => $user_role,
                'label'      => $label ?: ($value ?: $rule_id),
                'created_at' => gmdate('c'),
            ];
            update_option(self::OPTION_TRUSTED_ACTIONS, $trusted, false);
        }

        // Sync compact marker file for 0ms Preload Micro-WAF
        $preload_allow = ['ajax_actions' => [], 'rest_routes' => [], 'uris' => []];
        foreach ($trusted as $t) {
            if (($t['type'] ?? '') === 'ajax' && !empty($t['value'])) {
                $preload_allow['ajax_actions'][] = strtolower((string) $t['value']);
            } elseif (($t['type'] ?? '') === 'rest' && !empty($t['value'])) {
                $preload_allow['rest_routes'][] = strtolower(rtrim((string) $t['value'], '/'));
            } elseif (($t['type'] ?? '') === 'uri' && !empty($t['value'])) {
                $preload_allow['uris'][] = strtolower((string) $t['value']);
            }
        }
        $preload_file = class_exists('\\WebCareProScanner\\Firewall\\Core\\WafVaultManager')
            ? \WebCareProScanner\Firewall\Core\WafVaultManager::get_preload_allow_path()
            : (defined('WP_CONTENT_DIR') ? WP_CONTENT_DIR : ABSPATH . 'wp-content') . '/webcare-waf/.rescue_allow.json';
        self::write_marker_file($preload_file, (string) wp_json_encode($preload_allow));

        // If a Modular WAF rule was triggered, switch it to monitor mode cleanly
        if (str_starts_with($rule_id, 'MOD-') && class_exists('\\WebCareProScanner\\Firewall\\CustomRules\\ModularFirewallSynthesizer')) {
            \WebCareProScanner\Firewall\CustomRules\ModularFirewallSynthesizer::toggle_rule($rule_id, 'monitor');
        }

        // Unblock IP & grant 24h access pass if affected client IP is known
        $unblocked_ip = null;
        if ($ip !== '' && filter_var($ip, FILTER_VALIDATE_IP) && class_exists('\\WebCareProScanner\\Firewall\\FirewallEngine')) {
            \WebCareProScanner\Firewall\FirewallEngine::remove_blocked_ip($ip);
            set_transient('webcareproscan_temp_allow_' . md5($ip), 1, 24 * HOUR_IN_SECONDS);
            $unblocked_ip = $ip;
        }

        if (class_exists('\\WebCareProScanner\\System\\WebCareActivityLogger')) {
            \WebCareProScanner\System\WebCareActivityLogger::notice('rescue_action_trusted', 'firewall', [
                'type'        => $type,
                'value'       => $value ?: $rule_id,
                'unblocked'   => $unblocked_ip,
                'description' => sprintf(
                    /* translators: %s: action name or URI */
                    __('Trusted & permanently allowed "%s" via Rescue Assistant.', 'webcare-pro-security'),
                    $label ?: ($value ?: $rule_id)
                ),
            ]);
        }

        return [
            'success'         => true,
            'unblocked_ip'    => $unblocked_ip,
            'trusted_actions' => $trusted,
            'message'         => sprintf(
                /* translators: %s: trusted feature label */
                __('Trusted & allowed "%s" permanently. Any associated block has also been cleared.', 'webcare-pro-security'),
                $label ?: ($value ?: $rule_id)
            ),
        ];
    }

    /**
     * Scan the last $minutes minutes of WAF blocks and translate them into plain-English troubleshooting insights.
     */
    public static function analyze_recent_blocks(int $minutes = 15): array {
        global $wpdb;
        $cutoff = time() - ($minutes * MINUTE_IN_SECONDS);
        $raw    = [];
        $seen   = [];

        $add_row = static function (array $row) use (&$raw, &$seen, $cutoff) {
            $ts = !empty($row['ts']) ? (int) $row['ts'] : strtotime((string) ($row['created_at'] ?? 'now'));
            if ($ts < $cutoff) {
                return;
            }
            $act = strtolower((string) ($row['action_taken'] ?? 'blocked'));
            if (!in_array($act, ['blocked', 'challenged', 'rate_limited'], true)) {
                return;
            }
            $dedup = ($row['incident_id'] ?? '') . '|' . ($row['request_uri'] ?? '') . '|' . $ts;
            if (isset($seen[$dedup])) {
                return;
            }
            $seen[$dedup] = true;
            $row['ts']    = $ts;
            $raw[]        = $row;
        };

        if (class_exists('\\WebCareProScanner\\Firewall\\WafFileLogger')) {
            $res = \WebCareProScanner\Firewall\WafFileLogger::query_logs(['range' => '24h'], 80, 0);
            foreach (($res['logs'] ?? []) as $item) {
                $add_row([
                    'incident_id'   => $item['incident_id'] ?? '',
                    'ip_address'    => $item['ip_address'] ?? '',
                    'request_uri'   => $item['request_uri'] ?? '/',
                    'request_method'=> $item['request_method'] ?? 'GET',
                    'rule_id'       => $item['rule_id'] ?? '',
                    'rule_name'     => $item['rule_name'] ?? '',
                    'rule_category' => $item['rule_category'] ?? '',
                    'description'   => $item['rule_description'] ?? '',
                    'payload_sample'=> $item['payload_sample'] ?? '',
                    'action_taken'  => $item['action_taken'] ?? 'blocked',
                    'ts'            => strtotime((string) ($item['created_at_gmt'] ?? ($item['timestamp'] ?? 'now'))),
                ]);
            }
        }

        $table = $wpdb->prefix . 'webcareproscan_firewall_logs';
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        if ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $table)) === $table) {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
            $rows = $wpdb->get_results(
                $wpdb->prepare(
                    'SELECT incident_id, ip_address, request_uri, request_method, rule_category, rule_description, payload_sample, action_taken, created_at
                     FROM %i
                     WHERE created_at >= %s
                     ORDER BY id DESC
                     LIMIT 60',
                    $table,
                    gmdate('Y-m-d H:i:s', $cutoff)
                ),
                ARRAY_A
            );
            foreach ((is_array($rows) ? $rows : []) as $r) {
                $rid = '';
                if (preg_match('/\[(MOD-[A-Z0-9-]+|[A-Z0-9-]+)\]/', (string) ($r['rule_description'] ?? ''), $m)) {
                    $rid = $m[1];
                }
                $add_row([
                    'incident_id'    => $r['incident_id'] ?? '',
                    'ip_address'     => $r['ip_address'] ?? '',
                    'request_uri'    => $r['request_uri'] ?? '/',
                    'request_method' => $r['request_method'] ?? 'GET',
                    'rule_id'        => $rid,
                    'rule_name'      => $r['rule_category'] ?? 'Firewall',
                    'rule_category'  => $r['rule_category'] ?? '',
                    'description'    => $r['rule_description'] ?? '',
                    'payload_sample' => $r['payload_sample'] ?? '',
                    'action_taken'   => $r['action_taken'] ?? 'blocked',
                    'ts'             => strtotime((string) ($r['created_at'] ?? 'now')),
                ]);
            }
        }

        usort($raw, static fn($a, $b) => ($b['ts'] ?? 0) <=> ($a['ts'] ?? 0));
        $findings = [];

        foreach (array_slice($raw, 0, 12) as $ev) {
            $uri     = (string) ($ev['request_uri'] ?? '/');
            $payload = (string) ($ev['payload_sample'] ?? '');
            $blob    = strtolower($uri . ' ' . $ev['rule_category'] . ' ' . $ev['description'] . ' ' . $payload);

            $component_label = __('background website request', 'webcare-pro-security');
            $trust_target    = [
                'type'    => 'uri',
                'value'   => (string) (wp_parse_url($uri, PHP_URL_PATH) ?: $uri),
                'rule_id' => $ev['rule_id'] ?? '',
                'label'   => (string) (wp_parse_url($uri, PHP_URL_PATH) ?: $uri),
            ];

            if (str_contains($blob, 'elementor')) {
                $component_label = __('Elementor page editor save', 'webcare-pro-security');
            } elseif (str_contains($blob, 'stripe') || str_contains($blob, 'paypal') || str_contains($blob, 'wc-api') || str_contains($blob, 'webhook')) {
                $component_label = __('Payment Gateway / WooCommerce Webhook', 'webcare-pro-security');
            } elseif (str_contains($blob, 'checkout') || str_contains($blob, 'wc-ajax') || str_contains($blob, 'coupon')) {
                $component_label = __('WooCommerce customer checkout or coupon', 'webcare-pro-security');
            } elseif (str_contains($blob, 'contact-form-7') || str_contains($blob, 'wpforms') || str_contains($blob, 'fluentform') || str_contains($blob, 'gravity')) {
                $component_label = __('Contact form submission', 'webcare-pro-security');
            } elseif (str_contains($uri, 'admin-ajax.php')) {
                $act = '';
                $q   = wp_parse_url($uri, PHP_URL_QUERY);
                if (is_string($q)) {
                    parse_str($q, $qp);
                    if (!empty($qp['action'])) {
                        $act = sanitize_key($qp['action']);
                    }
                }
                if ($act === '' && preg_match('/action=([a-zA-Z0-9_-]+)/', $payload, $am)) {
                    $act = sanitize_key($am[1]);
                }
                if ($act !== '') {
                    $component_label = sprintf(
                        /* translators: %s: AJAX action name */
                        __('WordPress background AJAX task (%s)', 'webcare-pro-security'),
                        $act
                    );
                    $trust_target = [
                        'type'    => 'ajax',
                        'value'   => $act,
                        'rule_id' => $ev['rule_id'] ?? '',
                        'label'   => 'AJAX: ' . $act,
                    ];
                }
            } elseif (str_contains($uri, '/wp-json/')) {
                $path            = (string) (wp_parse_url($uri, PHP_URL_PATH) ?: $uri);
                $component_label = __('WordPress REST API request', 'webcare-pro-security');
                $trust_target    = [
                    'type'    => 'rest',
                    'value'   => substr($path, strpos($path, '/wp-json') + 8) ?: $path,
                    'rule_id' => $ev['rule_id'] ?? '',
                    'label'   => $path,
                ];
            }

            $ago = human_time_diff((int) $ev['ts'], time()) . ' ' . __('ago', 'webcare-pro-security');
            $findings[] = [
                'incident_id'        => $ev['incident_id'],
                'ip_address'         => $ev['ip_address'],
                'rule_id'            => $ev['rule_id'],
                'request_uri'        => $uri,
                'request_method'     => $ev['request_method'],
                'detected_component' => $component_label,
                'time_ago'           => $ago,
                'plain_english'      => sprintf(
                    /* translators: %1$s: relative time ago, %2$s: affected plugin or feature name */
                    __('%1$s, WebCare blocked a request related to %2$s.', 'webcare-pro-security'),
                    $ago,
                    $component_label
                ),
                'trust_target'       => $trust_target,
            ];
        }

        return $findings;
    }

    /**
     * Build the Plain-English Weekly/Daily Security Story card metrics from real logs & update checks.
     */
    public static function get_daily_security_story(): array {
        $password_bots   = 0;
        $fake_bots       = 0;
        $carding_blocked = 0;
        $other_blocked   = 0;

        if (class_exists('\\WebCareProScanner\\Firewall\\WafFileLogger')) {
            $res = \WebCareProScanner\Firewall\WafFileLogger::query_logs(['range' => '7d'], 400, 0);
            foreach (($res['logs'] ?? []) as $log) {
                if (strtolower((string) ($log['action_taken'] ?? '')) !== 'blocked') {
                    continue;
                }
                $blob = strtolower(($log['rule_category'] ?? '') . ' ' . ($log['rule_id'] ?? '') . ' ' . ($log['rule_description'] ?? ''));
                if (preg_match('/login|brute|auth|xmlrpc|user.?enum/', $blob)) {
                    $password_bots++;
                } elseif (preg_match('/card|checkout|coupon|stripe|paypal|woo/', $blob)) {
                    $carding_blocked++;
                } elseif (preg_match('/bot|scraper|recon|ai|404|crawler|dormant/', $blob)) {
                    $fake_bots++;
                } else {
                    $other_blocked++;
                }
            }
        }

        // Count outdated plugins / themes needing action
        $upd_plugins      = get_site_transient('update_plugins');
        $outdated_plugins = !empty($upd_plugins->response) && is_array($upd_plugins->response) ? count($upd_plugins->response) : 0;
        $total_blocked    = $password_bots + $fake_bots + $carding_blocked + $other_blocked;

        if ($total_blocked > 0) {
            $headline = __('Your site had a busy week — and stayed completely safe.', 'webcare-pro-security');
            $summary  = sprintf(
                /* translators: %1$d: password bots, %2$d: fake scrapers, %3$d: carding attempts */
                __('Over the past 7 days, WebCare Pro automatically stopped %1$d password-guessing attempts, %2$d fake scraper probes, and %3$d suspicious checkout/card-testing requests before they could impact your store. 0 verified shoppers were locked out.', 'webcare-pro-security'),
                $password_bots + $other_blocked,
                $fake_bots,
                $carding_blocked
            );
        } else {
            $headline = __('Your site had a quiet, safe week.', 'webcare-pro-security');
            $summary  = __('All perimeter shields, payment protections, and login guards are watching your site around the clock. Zero hostile probes required intervention over the past 7 days, and 0 real customers were interrupted.', 'webcare-pro-security');
        }

        return [
            'headline'               => $headline,
            'summary'                => $summary,
            'total_blocked_7d'       => $total_blocked,
            'password_bots_blocked'  => $password_bots + $other_blocked,
            'fake_bots_blocked'      => $fake_bots,
            'carding_blocked'        => $carding_blocked,
            'real_customers_blocked' => 0,
            'outdated_plugins_count' => $outdated_plugins,
            'pause_status'           => self::get_pause_status(),
        ];
    }

    /**
     * Safely back up an outdated plugin to Gatekeeper storage before upgrading via WordPress Plugin_Upgrader.
     */
    public static function safe_update_plugin(string $plugin_file, string $slug = '', string $name = ''): array {
        if (!current_user_can('update_plugins')) {
            return ['success' => false, 'message' => __('Permission denied: update_plugins capability required.', 'webcare-pro-security')];
        }

        if (!function_exists('get_plugins')) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }
        $all = get_plugins();
        if (!isset($all[$plugin_file])) {
            return ['success' => false, 'message' => __('Target plugin file was not found.', 'webcare-pro-security')];
        }

        $prev_version = (string) ($all[$plugin_file]['Version'] ?? '0.0.0');
        $plugin_name  = $name !== '' ? $name : (string) ($all[$plugin_file]['Name'] ?? $plugin_file);
        if ($slug === '') {
            $dir  = dirname($plugin_file);
            $slug = ($dir === '.' || $dir === '') ? basename($plugin_file, '.php') : $dir;
        }

        $source_dir  = WP_PLUGIN_DIR . '/' . $slug;
        $snapshot_id = null;

        if (is_dir($source_dir) && class_exists('\\WebCareProScanner\\SupplyChain\\UpdateGatekeeperEngine')) {
            $snapshot_id = \WebCareProScanner\SupplyChain\UpdateGatekeeperEngine::create_rollback_snapshot($slug, $source_dir);
        }

        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/misc.php';
        require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
        wp_update_plugins();

        $skin     = new \Automatic_Upgrader_Skin();
        $upgrader = new \Plugin_Upgrader($skin);
        $result   = $upgrader->upgrade($plugin_file);

        if (is_wp_error($result) || $result === false) {
            return [
                'success'     => false,
                'snapshot_id' => $snapshot_id,
                'message'     => is_wp_error($result)
                    ? $result->get_error_message()
                    : __('WordPress update package failed or no newer update package was available.', 'webcare-pro-security'),
            ];
        }

        wp_clean_plugins_cache(true);
        $updated_all = get_plugins();
        $new_version = (string) ($updated_all[$plugin_file]['Version'] ?? 'Updated');

        $records = get_option(self::OPTION_SAFE_UPDATES, []);
        if (!is_array($records)) {
            $records = [];
        }
        $records[$plugin_file] = [
            'plugin_file'      => $plugin_file,
            'slug'             => $slug,
            'name'             => $plugin_name,
            'previous_version' => $prev_version,
            'new_version'      => $new_version,
            'snapshot_id'      => $snapshot_id,
            'updated_at'       => gmdate('c'),
        ];
        update_option(self::OPTION_SAFE_UPDATES, $records, false);

        return [
            'success'          => true,
            'plugin_file'      => $plugin_file,
            'slug'             => $slug,
            'previous_version' => $prev_version,
            'new_version'      => $new_version,
            'snapshot_id'      => $snapshot_id,
            'message'          => sprintf(
                /* translators: %1$s: plugin name, %2$s: old version, %3$s: new version */
                __('Safely backed up "%1$s" (v%2$s) and updated to v%3$s. You can roll back in 1 click at any time.', 'webcare-pro-security'),
                $plugin_name,
                $prev_version,
                $new_version
            ),
        ];
    }

    /**
     * Roll back a plugin to its pre-update Gatekeeper backup snapshot.
     */
    public static function rollback_safe_update(string $snapshot_id): array {
        if (!current_user_can('update_plugins')) {
            return ['success' => false, 'message' => __('Permission denied: update_plugins capability required.', 'webcare-pro-security')];
        }
        if (!class_exists('\\WebCareProScanner\\SupplyChain\\UpdateGatekeeperEngine')) {
            return ['success' => false, 'message' => __('Backup rollback engine unavailable.', 'webcare-pro-security')];
        }
        return \WebCareProScanner\SupplyChain\UpdateGatekeeperEngine::rollback_snapshot(sanitize_text_field($snapshot_id));
    }

    /**
     * Register WordPress Admin Bar menu node for Quick Unblock (#WEBCARE-XXXX) & Rescue Assistant.
     *
     * @param \WP_Admin_Bar $wp_admin_bar
     */
    public static function register_admin_bar_nodes($wp_admin_bar): void {
        if (!is_admin_bar_showing() || !current_user_can('manage_options') || !is_object($wp_admin_bar)) {
            return;
        }

        $pause_status = self::get_pause_status();
        $paused = !empty($pause_status['paused']);

        if ($paused) {
            $mins_left = (int) ceil(($pause_status['seconds_remaining'] ?? 0) / 60);
            $badge_text = $mins_left > 0
                ? sprintf(
                    /* translators: %d: remaining minutes of safe mode */
                    esc_html__('Safe Mode (%dm)', 'webcare-pro-security'),
                    $mins_left
                )
                : esc_html__('Safe Mode', 'webcare-pro-security');

            $badge = '<span class="webcare-ab-badge is-paused">'
                . '<span class="webcare-ab-dot is-amber"></span>'
                . $badge_text
                . '</span>';
        } else {
            $badge = '<span class="webcare-ab-badge is-active">'
                . '<span class="webcare-ab-dot is-emerald"></span>'
                . esc_html__('Protected', 'webcare-pro-security')
                . '</span>';
        }

        $dashboard_url = class_exists('\\WebCareProScanner\\Admin\\RouteRegistry')
            ? \WebCareProScanner\Admin\RouteRegistry::url('webcare-pro-security')
            : admin_url('admin.php?page=webcare-pro-security');

        $wp_admin_bar->add_node([
            'id'    => 'webcare-pro-bar',
            'title' => '<span class="ab-icon dashicons dashicons-shield" style="margin-top:2px;"></span>'
                . '<span class="webcare-ab-title">WebCare Pro</span>'
                . $badge,
            'href'  => esc_url($dashboard_url),
        ]);

        // 1. Quick Unblock Customer (#WEBCARE-XXXX or IP) Popover Node
        $unblock_form = '<div id="webcare-ab-unblock-box" class="webcare-ab-unblock-wrap">'
            . '<div class="webcare-ab-unblock-title">' . esc_html__('Quick Unblock Customer (#WEBCARE-XXXX or IP)', 'webcare-pro-security') . '</div>'
            . '<div class="webcare-ab-unblock-row">'
            . '<input type="text" id="webcare-ab-code-input" autocomplete="off" placeholder="' . esc_attr__('#WEBCARE-492A or IP', 'webcare-pro-security') . '" />'
            . '<button type="button" id="webcare-ab-lookup-btn">' . esc_html__('Find', 'webcare-pro-security') . '</button>'
            . '</div>'
            . '<div id="webcare-ab-result"></div>'
            . '</div>';

        $wp_admin_bar->add_node([
            'id'     => 'webcare-pro-bar-unblock',
            'parent' => 'webcare-pro-bar',
            'title'  => $unblock_form,
        ]);

        // Helper to resolve canonical pillar URLs cleanly
        $get_url = static function (string $pillar, string $tab = '', array $args = []): string {
            if (class_exists('\\WebCareProScanner\\Admin\\RouteRegistry')) {
                return \WebCareProScanner\Admin\RouteRegistry::url($pillar, $tab, '', $args);
            }
            $query = ['page' => $pillar];
            if ($tab !== '') {
                $query['tab'] = $tab;
            }
            if (!empty($args)) {
                $query = array_merge($query, $args);
            }
            return add_query_arg($query, admin_url('admin.php'));
        };

        // 2. Six concise, plain-English quick links
        $links = [
            [
                'id'    => 'webcare-pro-bar-dash',
                'title' => esc_html__('Dashboard', 'webcare-pro-security'),
                'href'  => $get_url('webcare-pro-security'),
            ],
            [
                'id'    => 'webcare-pro-bar-firewall',
                'title' => esc_html__('Firewall Rules', 'webcare-pro-security'),
                'href'  => $get_url('webcare-pro-firewall'),
            ],
            [
                'id'    => 'webcare-pro-bar-logs',
                'title' => esc_html__('Logs & Unban IP', 'webcare-pro-security'),
                'href'  => $get_url('webcare-pro-logs'),
            ],
            [
                'id'    => 'webcare-pro-bar-scanner',
                'title' => esc_html__('Malware & Scanner', 'webcare-pro-security'),
                'href'  => $get_url('webcare-pro-scanner'),
            ],
            [
                'id'    => 'webcare-pro-bar-backups',
                'title' => esc_html__('Database Backups', 'webcare-pro-security'),
                'href'  => $get_url('webcare-pro-backups'),
            ],
            [
                'id'    => 'webcare-pro-bar-settings',
                'title' => esc_html__('Settings & Doctor', 'webcare-pro-security'),
                'href'  => $get_url('webcare-pro-settings'),
            ],
        ];

        foreach ($links as $link) {
            $wp_admin_bar->add_node([
                'id'     => $link['id'],
                'parent' => 'webcare-pro-bar',
                'title'  => $link['title'],
                'href'   => esc_url($link['href']),
            ]);
        }

        // 3. Safe Mode Action at the bottom with divider
        $safe_mode_url = $get_url('webcare-pro-security', '', ['rescue' => '1']);
        $safe_mode_title = $paused
            ? '<span class="webcare-ab-action-resume">' . esc_html__('Resume Full Protection', 'webcare-pro-security') . '</span>'
            : '<span class="webcare-ab-action-pause">' . esc_html__('Pause Firewall (15-Min Safe Mode)', 'webcare-pro-security') . '</span>';

        $wp_admin_bar->add_node([
            'id'     => 'webcare-pro-bar-safemode',
            'parent' => 'webcare-pro-bar',
            'title'  => $safe_mode_title,
            'href'   => esc_url($safe_mode_url),
            'meta'   => [
                'class' => 'webcare-ab-safemode-node',
            ],
        ]);
    }

    /**
     * Enqueue lightweight Admin Bar CSS & JS cleanly via WP APIs when admin bar is visible.
     */
    public static function enqueue_admin_bar_assets(): void {
        if (!is_admin_bar_showing() || !current_user_can('manage_options')) {
            return;
        }

        $ver = defined('WEBCAREPROSCAN_VERSION') ? WEBCAREPROSCAN_VERSION : '0.0.1';
        wp_register_style('webcare-admin-bar-rescue', false, [], $ver);
        wp_enqueue_style('webcare-admin-bar-rescue');
        wp_add_inline_style(
            'webcare-admin-bar-rescue',
            '#wp-admin-bar-webcare-pro-bar .ab-sub-wrapper{min-width:265px!important;box-shadow:0 10px 25px -5px rgba(0,0,0,0.5)!important;border-radius:0 0 6px 6px!important;padding:4px 0!important;}'
            . '#wp-admin-bar-webcare-pro-bar.webcare-ab-keep-open .ab-sub-wrapper,'
            . '#wp-admin-bar-webcare-pro-bar:focus-within .ab-sub-wrapper{display:block!important;}'
            . '#wp-admin-bar-webcare-pro-bar .webcare-ab-badge{display:inline-flex;align-items:center;gap:5px;padding:1px 7px;border-radius:10px;font-size:10px;font-weight:700;margin-left:6px;line-height:1.4;letter-spacing:0.02em;}'
            . '#wp-admin-bar-webcare-pro-bar .webcare-ab-badge.is-active{background:rgba(16,185,129,0.2);color:#34d399;border:1px solid rgba(16,185,129,0.4);}'
            . '#wp-admin-bar-webcare-pro-bar .webcare-ab-badge.is-paused{background:rgba(245,158,11,0.22);color:#fbbf24;border:1px solid rgba(245,158,11,0.45);}'
            . '#wp-admin-bar-webcare-pro-bar .webcare-ab-dot{display:inline-block;width:6px;height:6px;border-radius:50%;flex-shrink:0;}'
            . '#wp-admin-bar-webcare-pro-bar .webcare-ab-dot.is-emerald{background:#10b981;box-shadow:0 0 6px #10b981;}'
            . '#wp-admin-bar-webcare-pro-bar .webcare-ab-dot.is-amber{background:#f59e0b;box-shadow:0 0 6px #f59e0b;}'
            . '#wp-admin-bar-webcare-pro-bar-unblock .ab-item{height:auto!important;padding:10px 14px 12px!important;line-height:1.4!important;border-bottom:1px solid rgba(255,255,255,0.08)!important;margin-bottom:4px!important;}'
            . '#webcare-ab-unblock-box .webcare-ab-unblock-title{font-weight:700;font-size:11px;letter-spacing:0.02em;text-transform:uppercase;margin-bottom:7px;color:#cbd5e1;}'
            . '#webcare-ab-unblock-box .webcare-ab-unblock-row{display:flex;gap:6px;align-items:center;}'
            . '#webcare-ab-unblock-box input#webcare-ab-code-input{flex:1;min-width:0;padding:4px 8px;border-radius:4px;border:1px solid rgba(255,255,255,0.18);background:#090d16;color:#f8fafc;font-size:12px;height:28px;outline:none;box-sizing:border-box;}'
            . '#webcare-ab-unblock-box input#webcare-ab-code-input:focus{border-color:#6366f1;box-shadow:0 0 0 1px #6366f1;}'
            . '#webcare-ab-unblock-box button#webcare-ab-lookup-btn{padding:0 10px;border-radius:4px;border:none;background:#4f46e5;color:#fff;font-size:11px;font-weight:700;cursor:pointer;height:28px;transition:background 0.15s;flex-shrink:0;}'
            . '#webcare-ab-unblock-box button#webcare-ab-lookup-btn:hover{background:#4338ca;}'
            . '#webcare-ab-unblock-box #webcare-ab-result{margin-top:8px;font-size:11px;line-height:1.4;color:#cbd5e1;white-space:normal;}'
            . '#wp-admin-bar-webcare-pro-bar .ab-submenu .ab-item{padding:5px 14px!important;font-size:12px!important;transition:background 0.15s ease!important;}'
            . '#wp-admin-bar-webcare-pro-bar .ab-submenu li:not(#wp-admin-bar-webcare-pro-bar-unblock):hover > .ab-item{background:rgba(255,255,255,0.08)!important;color:#fff!important;}'
            . '#wp-admin-bar-webcare-pro-bar .webcare-ab-safemode-node{border-top:1px solid rgba(255,255,255,0.08)!important;margin-top:4px!important;padding-top:4px!important;}'
            . '#wp-admin-bar-webcare-pro-bar .webcare-ab-action-resume{color:#34d399!important;font-weight:600;display:inline-flex;align-items:center;}'
            . '#wp-admin-bar-webcare-pro-bar .webcare-ab-action-pause{color:#f59e0b!important;font-weight:500;display:inline-flex;align-items:center;}'
        );

        wp_register_script('webcare-admin-bar-rescue', false, [], defined('WEBCAREPROSCAN_VERSION') ? WEBCAREPROSCAN_VERSION : '2.11.0', true);
        wp_enqueue_script('webcare-admin-bar-rescue');

        $cfg = wp_json_encode([
            'restRoot' => esc_url_raw(rest_url('webcare-pro-security/v1')),
            'nonce'    => wp_create_nonce('wp_rest'),
        ]);

        $js = '(function(){var cfg=' . $cfg . ';'
            . 'function setKeepOpen(open){'
            . 'var root=document.getElementById("wp-admin-bar-webcare-pro-bar");'
            . 'if(!root)return;'
            . 'if(open){root.classList.add("webcare-ab-keep-open","hover");}else{root.classList.remove("webcare-ab-keep-open");}'
            . '}'
            . 'function runLookup(){'
            . 'var inp=document.getElementById("webcare-ab-code-input");'
            . 'var out=document.getElementById("webcare-ab-result");'
            . 'if(!inp||!out)return;'
            . 'setKeepOpen(true);'
            . 'var q=(inp.value||"").trim();'
            . 'if(!q){out.textContent="Enter a #WEBCARE-XXXX code or IP address.";return;}'
            . 'out.textContent="Looking up block details...";'
            . 'fetch(cfg.restRoot+"/firewall/customer/lookup-block?code="+encodeURIComponent(q),{headers:{"X-WP-Nonce":cfg.nonce},credentials:"same-origin"})'
            . '.then(function(r){return r.json();})'
            . '.then(function(d){'
            . 'out.textContent="";'
            . 'if(!d||!d.found){out.textContent=(d&&d.message)?d.message:"No matching block found.";return;}'
            . 'var info=document.createElement("div");info.style.marginBottom="6px";'
            . 'if(d.ref_code){var rc=document.createElement("div");rc.style.cssText="color:#93c5fd;font-weight:700;margin-bottom:2px;";rc.textContent="Code: "+String(d.ref_code)+(d.incident_id&&d.incident_id!==d.ref_code?" ("+String(d.incident_id)+")":"");info.appendChild(rc);}'
            . 'var strong=document.createElement("strong");strong.textContent="IP: ";info.appendChild(strong);'
            . 'info.appendChild(document.createTextNode(String(d.client_ip||"")));'
            . 'info.appendChild(document.createElement("br"));'
            . 'info.appendChild(document.createTextNode(String(d.friendly_reason||"")));'
            . 'out.appendChild(info);'
            . 'var btn=document.createElement("button");btn.type="button";btn.id="webcare-ab-do-unblock";'
            . 'btn.setAttribute("data-ip",String(d.client_ip||""));'
            . 'btn.setAttribute("data-code",String(d.ref_code||q));'
            . 'btn.style.cssText="width:100%;padding:5px 8px;border:none;border-radius:4px;background:#10b981;color:#fff;font-weight:700;cursor:pointer;font-size:11px;";'
            . 'btn.textContent="Unblock Customer in 1 Click";'
            . 'out.appendChild(btn);'
            . '}).catch(function(){out.textContent="Lookup failed.";});'
            . '}'
            . 'function runUnblock(btn){'
            . 'var out=document.getElementById("webcare-ab-result");'
            . 'btn.disabled=true;btn.textContent="Unblocking...";'
            . 'fetch(cfg.restRoot+"/firewall/customer/unblock",{method:"POST",headers:{"Content-Type":"application/json","X-WP-Nonce":cfg.nonce},credentials:"same-origin",body:JSON.stringify({ip:btn.getAttribute("data-ip"),code:btn.getAttribute("data-code")})})'
            . '.then(function(r){return r.json();})'
            . '.then(function(d){'
            . 'out.textContent="";'
            . 'var ok=document.createElement("span");ok.style.cssText="color:#34d399;font-weight:700;";'
            . 'ok.textContent=String((d&&d.message)||"Customer unblocked!");'
            . 'out.appendChild(ok);'
            . '}).catch(function(){out.textContent="Failed to unblock IP.";});'
            . '}'
            . 'function bindAdminBarSearch(){'
            . 'var box=document.getElementById("webcare-ab-unblock-box");'
            . 'if(!box||box.getAttribute("data-webcare-bound")==="1")return;'
            . 'box.setAttribute("data-webcare-bound","1");'
            . 'box.addEventListener("click",function(e){'
            . 'var tgt=e.target;'
            . 'if(tgt&&tgt.closest&&tgt.closest("#webcare-ab-lookup-btn")){e.preventDefault();e.stopPropagation();runLookup();return;}'
            . 'if(tgt&&tgt.closest&&tgt.closest("#webcare-ab-do-unblock")){e.preventDefault();e.stopPropagation();runUnblock(tgt.closest("#webcare-ab-do-unblock"));return;}'
            . 'e.stopPropagation();'
            . 'setKeepOpen(true);'
            . '});'
            . 'var inp=document.getElementById("webcare-ab-code-input");'
            . 'if(inp){'
            . 'inp.addEventListener("focus",function(){setKeepOpen(true);});'
            . 'inp.addEventListener("keydown",function(e){if(e.key==="Enter"){e.preventDefault();e.stopPropagation();runLookup();}});'
            . '}'
            . '}'
            . 'if(document.readyState==="loading"){document.addEventListener("DOMContentLoaded",bindAdminBarSearch);}else{bindAdminBarSearch();}'
            . 'document.addEventListener("click",function(e){'
            . 'var root=document.getElementById("wp-admin-bar-webcare-pro-bar");'
            . 'if(root&&e.target&&!root.contains(e.target)){setKeepOpen(false);}'
            . '});'
            . '})();';

        wp_add_inline_script('webcare-admin-bar-rescue', $js);
    }
}
