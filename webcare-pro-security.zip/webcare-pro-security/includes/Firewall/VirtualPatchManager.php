<?php
namespace WebCareProScanner\Firewall;

use WebCareProScanner\System\SettingsManager;
use WebCareProScanner\System\AuditLogger;
use WebCareProScanner\Cloudflare\CloudflareService;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * VirtualPatchManager
 *
 * Automated Two-Tier Virtual Patching Engine (WAF Lite + Cloudflare Free Edge Rules):
 * - Intercepts and shields unpatched CVEs and zero-days before official vendor releases or updates can be applied.
 * - Tier 1: Local PHP WAF Lite Virtual Patch (<0.5ms in-memory inspection at plugins_loaded:0).
 * - Tier 2: Cloudflare Global Edge Custom WAF Expression (blocks exploit at edge before reaching server/PHP).
 * - 1-Click "Protect Now via Virtual Patch" action across vulnerabilities and scan issues.
 *
 * Author: Mir Alamin (WebCare Pro)
 * Senior Linux SysAdmin & WordPress Security Engineer
 */
class VirtualPatchManager {

    const OPTION_PATCHES = 'webcareproscan_virtual_patches';
    const CF_TAG = '[WebCare Virtual Patch]';

    /**
     * Get Curated Catalog of Pre-Built Virtual Patches for Common & High-Impact WordPress CVEs.
     *
     * @return array
     */
    public static function get_patch_catalog(): array {
        return [
            'CVE-2024-28000' => [
                'patch_id'     => 'CVE-2024-28000',
                'cve_id'       => 'CVE-2024-28000',
                'component'    => 'litespeed-cache',
                'title'        => 'LiteSpeed Cache <= 6.3.0.1 - Unauthenticated Privilege Escalation / Admin Takeover',
                'severity'     => 'critical',
                'description'  => 'Blocks brute-forced or spoofed hash authentication bypass targeting LiteSpeed REST API / admin simulation endpoints.',
                'php_rule'     => [
                    'target_uris' => ['/wp-json/litespeed/', 'action=async_litespeed'],
                    'headers'     => ['X-LSCACHE-VARY'],
                    'regex'       => '/(litespeed_role|litespeed_hash|user_id=1)/i',
                ],
                'cf_expression' => '(http.request.uri.path contains "wp-json/litespeed" or http.request.uri.query contains "async_litespeed") and (http.request.uri.query contains "user_id=1" or any(http.request.headers["x-lscache-vary"][*] contains "role"))',
            ],
            'CVE-2024-31210' => [
                'patch_id'     => 'CVE-2024-31210',
                'cve_id'       => 'CVE-2024-31210',
                'component'    => 'wordpress-core',
                'title'        => 'WordPress Core <= 6.5.2 - Path Traversal & Arbitrary File Deletion',
                'severity'     => 'critical',
                'description'  => 'Neutralizes path traversal attempts with dot-dot-slash sequence targeting media attachment cleanup and file deletion routines.',
                'php_rule'     => [
                    'target_uris' => ['/wp-admin/post.php', '/wp-admin/admin-ajax.php'],
                    'regex'       => '/(\.\.\/|\.\.\\\\|\%2e\%2e|\%252e)/i',
                ],
                'cf_expression' => '(http.request.uri.path contains "wp-admin/post.php" or http.request.uri.path contains "wp-admin/admin-ajax.php") and (http.request.uri.query contains ".." or http.request.body contains "..")',
            ],
            'CVE-2024-5654' => [
                'patch_id'     => 'CVE-2024-5654',
                'cve_id'       => 'CVE-2024-5654',
                'component'    => 'give',
                'title'        => 'GiveWP <= 3.14.1 - Unauthenticated PHP Object Injection & RCE',
                'severity'     => 'critical',
                'description'  => 'Blocks serialized PHP object payload injection through donation forms and donation receipt parameter handles.',
                'php_rule'     => [
                    'target_uris' => ['give_action', 'give-donation'],
                    'regex'       => '/(O:[0-9]+:"[a-zA-Z0-9_]+":|a:[0-9]+:\{|give_title)/i',
                ],
                'cf_expression' => '(http.request.uri.path contains "give" or http.request.uri.query contains "give") and (http.request.body contains "O:" or http.request.uri.query contains "O:")',
            ],
            'CVE-2023-38000' => [
                'patch_id'     => 'CVE-2023-38000',
                'cve_id'       => 'CVE-2023-38000',
                'component'    => 'royal-elementor-addons',
                'title'        => 'Royal Elementor Addons <= 1.3.78 - Unauthenticated Arbitrary File Upload',
                'severity'     => 'critical',
                'description'  => 'Prevents executable file uploads and PHP extensions bypassing file verification checks in Royal Elementor upload handlers.',
                'php_rule'     => [
                    'target_uris' => ['wpr_addons_upload_file', 'royal_elementor'],
                    'regex'       => '/(\.php|\.phtml|\.php5|\.sh|\.cgi)/i',
                ],
                'cf_expression' => '(http.request.uri.query contains "wpr_addons_upload_file" or http.request.body contains "wpr_addons_upload_file") and (http.request.body contains ".php" or http.request.uri.query contains ".php")',
            ],
            'CVE-2023-28121' => [
                'patch_id'     => 'CVE-2023-28121',
                'cve_id'       => 'CVE-2023-28121',
                'component'    => 'woocommerce-payments',
                'title'        => 'WooCommerce Payments <= 5.6.1 - Unauthenticated Admin Privilege Escalation',
                'severity'     => 'critical',
                'description'  => 'Blocks unauthorized user impersonation headers (X-WCPay-Platform-Checkout-User) from arbitrary remote clients.',
                'php_rule'     => [
                    'target_uris' => ['/'],
                    'headers'     => ['X-WCPay-Platform-Checkout-User'],
                    'regex'       => '/[0-9]+/i',
                ],
                'cf_expression' => 'any(http.request.headers["X-WCPay-Platform-Checkout-User"][*] != "")',
            ],
            'VPATCH-FILE-UPLOAD' => [
                'patch_id'     => 'VPATCH-FILE-UPLOAD',
                'cve_id'       => 'GENERIC-UPLOAD',
                'component'    => 'all-plugins',
                'title'        => 'Universal Zero-Day Arbitrary File Upload Shield',
                'severity'     => 'high',
                'description'  => 'Blocks unauthenticated POST requests uploading PHP, shell scripts, or executable code to admin-ajax or rest-api endpoints.',
                'php_rule'     => [
                    'target_uris' => ['/wp-admin/admin-ajax.php', '/wp-json/'],
                    'methods'     => ['POST'],
                    'regex'       => '/(filename=[\'"][^\'"]+\.(php[0-9]?|phtml|sh|bash|cgi|exe)[\'"]|application\/x-php)/i',
                ],
                'cf_expression' => '(http.request.uri.path contains "admin-ajax.php" or http.request.uri.path contains "wp-json") and http.request.method eq "POST" and (http.request.body contains ".php" or http.request.body contains "application/x-php")',
            ],
            'VPATCH-SQLI-DEEP' => [
                'patch_id'     => 'VPATCH-SQLI-DEEP',
                'cve_id'       => 'GENERIC-SQLI',
                'component'    => 'all-plugins',
                'title'        => 'High-Confidence Plugin SQL Injection Shield',
                'severity'     => 'high',
                'description'  => 'Blocks UNION SELECT, Boolean-based sleep(), and benchmark() injection payloads targeting plugin custom query parameters.',
                'php_rule'     => [
                    'target_uris' => ['/'],
                    'regex'       => '/(union\s+all\s+select|select\s+sleep\s*\(|waitfor\s+delay\s+|extractvalue\s*\(|updatexml\s*\()/i',
                ],
                'cf_expression' => 'http.request.uri.query contains "union select" or http.request.uri.query contains "sleep(" or http.request.body contains "union select"',
            ],
        ];
    }

    /**
     * Get All Active Virtual Patches.
     *
     * @return array
     */
    public static function get_active_patches(): array {
        $patches = get_option(self::OPTION_PATCHES, []);
        if (!is_array($patches)) {
            $patches = [];
        }

        // Merge active synthesized virtual hotpatches
        $synthesized = get_option(VirtualPatchSynthesizer::OPTION_SYNTHESIZED_PATCHES, []);
        if (is_array($synthesized) && !empty($synthesized)) {
            foreach ($synthesized as $s_id => $s_patch) {
                if (!empty($s_patch['enabled'])) {
                    $patches[$s_id] = $s_patch;
                }
            }
        }

        return $patches;
    }

    /**
     * Apply a Virtual Patch (Tier 1: PHP WAF Lite + Tier 2: Cloudflare Free Edge).
     * Enforces DeclarativePatchVerifier cryptographic signature and manifest check on all declarative patches.
     *
     * @param string $patch_id
     * @param array $custom_config
     * @return array
     */
    public static function apply_patch(string $patch_id, array $custom_config = []): array {
        // If applying an incoming declarative patch manifest (has signature/schema_version)
        $is_declarative_manifest = !empty($custom_config['schema_version']) || !empty($custom_config['signature']);

        if ($is_declarative_manifest) {
            $checkpoint = class_exists('\\WebCareProScanner\\Firewall\\CentralThreatControlPlane')
                ? CentralThreatControlPlane::get_checkpoint()
                : ['sequence' => 0];
            $min_seq = (int) ($checkpoint['sequence'] ?? 0);

            $verify_res = DeclarativePatchVerifier::verify_patch_manifest($custom_config, $min_seq);
            if (!$verify_res['valid']) {
                AuditLogger::log_event(
                    'VPATCH_REJECTED',
                    sprintf('Declarative patch %s rejected: %s', $patch_id, (string) $verify_res['error'])
                );
                return [
                    'success' => false,
                    'message' => sprintf(__('Virtual patch validation failed: %s', 'webcare-pro-security'), (string) $verify_res['error']),
                ];
            }

            $patch = $verify_res['patch'];
            $patch['stage'] = DeclarativePatchVerifier::determine_initial_stage($patch);
        } else {
            $catalog = self::get_patch_catalog();
            $patch = $catalog[$patch_id] ?? null;

            if (!$patch && !empty($custom_config['title'])) {
                // Remote/central custom patch without declarative signature must be rejected
                if (!empty($custom_config['is_remote'])) {
                    return [
                        'success' => false,
                        'message' => __('Unsigned remote virtual patches are prohibited. A valid Ed25519 signature is required.', 'webcare-pro-security'),
                    ];
                }

                $patch = [
                    'patch_id'      => $patch_id,
                    'cve_id'        => $custom_config['cve_id'] ?? $patch_id,
                    'component'     => $custom_config['component'] ?? 'custom',
                    'title'         => $custom_config['title'],
                    'severity'      => $custom_config['severity'] ?? 'high',
                    'description'   => $custom_config['description'] ?? 'Custom Virtual Patch shield deployed via WebCare.',
                    'php_rule'      => $custom_config['php_rule'] ?? ['target_uris' => ['/'], 'regex' => '/\.\.\//i'],
                    'cf_expression' => $custom_config['cf_expression'] ?? '',
                ];
            }
        }

        if (!$patch) {
            /* translators: %s: patch ID */
            return ['success' => false, 'message' => sprintf(__('Unknown patch template: %s', 'webcare-pro-security'), $patch_id)];
        }

        $active = self::get_active_patches();
        $is_update = isset($active[$patch_id]);

        $patch['enabled'] = true;
        $patch['hits'] = $is_update ? ($active[$patch_id]['hits'] ?? 0) : 0;
        $patch['applied_at'] = current_time('mysql');
        $patch['deployed_to_cloudflare'] = false;
        $patch['cloudflare_rule_id'] = null;

        // Tier 2: Deploy to Cloudflare Global Edge if Cloudflare is configured
        $cf_deployed = false;
        $cf_msg = '';

        if (!empty($patch['cf_expression'])) {
            $cf_res = self::deploy_to_cloudflare_edge($patch);
            if ($cf_res['success']) {
                $patch['deployed_to_cloudflare'] = true;
                $patch['cloudflare_rule_id'] = $cf_res['rule_id'] ?? null;
                $cf_deployed = true;
                $cf_msg = __(' (Active on Cloudflare Global Edge + PHP WAF Lite)', 'webcare-pro-security');
            } else {
                $cf_msg = ' (' . __('Local PHP WAF Lite Active; Cloudflare Edge: ', 'webcare-pro-security') . ($cf_res['message'] ?? 'Not connected') . ')';
            }
        } else {
            $stage_label = !empty($patch['stage']) ? " [{$patch['stage']}]" : '';
            $cf_msg = __(' (Active on Local PHP WAF Lite)', 'webcare-pro-security') . $stage_label;
        }

        $active[$patch_id] = $patch;
        update_option(self::OPTION_PATCHES, $active, false);

        // Record Audit Log with Rich Details
        if (class_exists('\\WebCareProScanner\\System\\WebCareActivityLogger')) {
            \WebCareProScanner\System\WebCareActivityLogger::notice('virtual_patch_applied', 'firewall', [
                'patch_id'   => $patch_id,
                'title'      => $patch['title'] ?? $patch_id,
                'cve_id'     => $patch['cve_id'] ?? $patch_id,
                'severity'   => $patch['severity'] ?? 'high',
                'target'     => $patch['target'] ?? 'core',
                'cloudflare' => $cf_deployed,
                'diff'       => [
                    $patch_id => [
                        'old' => null,
                        'new' => [
                            'status'     => 'active',
                            'title'      => $patch['title'] ?? $patch_id,
                            'cve_id'     => $patch['cve_id'] ?? $patch_id,
                            'cloudflare' => $cf_deployed,
                        ],
                    ],
                ],
                'description' => sprintf(
                    /* translators: 1: patch title, 2: patch ID, 3: deployment message */
                    __('Activated Virtual Shield "%1$s" (%2$s)%3$s', 'webcare-pro-security'),
                    $patch['title'] ?? $patch_id,
                    $patch_id,
                    $cf_msg
                ),
            ]);
        }

        AuditLogger::log_event(
            'virtual_patch_applied',
            sprintf(
                /* translators: 1: patch title, 2: patch ID, 3: deployment message */
                __('Applied Virtual Patch "%1$s" (%2$s)%3$s', 'webcare-pro-security'),
                $patch['title'] ?? $patch_id,
                $patch_id,
                $cf_msg
            )
        );

        return [
            'success'                => true,
            'message'                => sprintf(
                /* translators: 1: patch title, 2: deployment message */
                __('Virtual Patch "%1$s" applied successfully!%2$s', 'webcare-pro-security'),
                $patch['title'] ?? $patch_id,
                $cf_msg
            ),
            'patch'                  => $patch,
            'deployed_to_cloudflare' => $cf_deployed,
        ];
    }

    /**
     * Remove / Deactivate a Virtual Patch.
     *
     * @param string $patch_id
     * @return array
     */
    public static function remove_patch(string $patch_id): array {
        $active = self::get_active_patches();
        if (!isset($active[$patch_id])) {
            return ['success' => false, 'message' => __('Virtual Patch is not active.', 'webcare-pro-security')];
        }

        $patch = $active[$patch_id];

        // Remove from Cloudflare if deployed
        if (!empty($patch['deployed_to_cloudflare'])) {
            self::remove_from_cloudflare_edge($patch_id);
        }

        unset($active[$patch_id]);
        update_option(self::OPTION_PATCHES, $active, false);

        if (class_exists('\\WebCareProScanner\\System\\WebCareActivityLogger')) {
            \WebCareProScanner\System\WebCareActivityLogger::notice('virtual_patch_deactivated', 'firewall', [
                'patch_id'   => $patch_id,
                'title'      => $patch['title'] ?? $patch_id,
                'cve_id'     => $patch['cve_id'] ?? $patch_id,
                'diff'       => [
                    $patch_id => [
                        'old' => [
                            'status' => 'active',
                            'title'  => $patch['title'] ?? $patch_id,
                        ],
                        'new' => null,
                    ],
                ],
                'description' => sprintf(
                    /* translators: 1: patch title, 2: patch ID */
                    __('Deactivated Virtual Shield "%1$s" (%2$s)', 'webcare-pro-security'),
                    $patch['title'] ?? $patch_id,
                    $patch_id
                ),
            ]);
        }

        AuditLogger::log_event(
            'virtual_patch_removed',
            sprintf(
                /* translators: 1: patch title, 2: patch ID */
                __('Removed Virtual Patch "%1$s" (%2$s)', 'webcare-pro-security'),
                $patch['title'] ?? $patch_id,
                $patch_id
            )
        );

        return [
            'success' => true,
            /* translators: %s: patch title */
            'message' => sprintf(__('Virtual Patch "%s" has been deactivated.', 'webcare-pro-security'), $patch['title'] ?? $patch_id),
        ];
    }

    /**
     * Check if current request originates from an authenticated WordPress administrator.
     *
     * @return bool
     */
    public static function is_authenticated_administrator(): bool {
        if (class_exists('\\WebCareProScanner\\Firewall\\FirewallEngine')) {
            return \WebCareProScanner\Firewall\FirewallEngine::is_authenticated_administrator();
        }

        if (function_exists('is_user_logged_in') && function_exists('current_user_can')) {
            if (is_user_logged_in() && (current_user_can('manage_options') || current_user_can('activate_plugins'))) {
                return true;
            }
        }

        return false;
    }

    /**
     * Fast-Path Runtime Inspection: Evaluate Incoming Request against Active Virtual Patches.
     * Hooked directly into FirewallEngine before request processing.
     *
     * @param string $client_ip
     * @param string $request_uri
     * @return array|null Triggered rule array or null if clean
     */
    public static function evaluate_request(string $client_ip, string $request_uri): ?array {
        // Authenticated administrators managing the site must never be blocked by virtual patches
        if (self::is_authenticated_administrator()) {
            return null;
        }

        $active_patches = self::get_active_patches();
        if (empty($active_patches)) {
            return null;
        }

        $method = isset($_SERVER['REQUEST_METHOD']) ? strtoupper(sanitize_key(wp_unslash($_SERVER['REQUEST_METHOD']))) : 'GET';
        // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Inspecting raw query string for CVE virtual patch match criteria
        $raw_query = isset($_SERVER['QUERY_STRING']) ? (string) wp_unslash($_SERVER['QUERY_STRING']) : '';
        $query_string = rawurldecode($raw_query);
        $raw_body = '';

        if (in_array($method, ['POST', 'PUT', 'PATCH'], true)) {
            $raw_input = @file_get_contents('php://input', false, null, 0, 65536);
            $raw_body = !empty($raw_input) ? wp_unslash($raw_input) : '';
        }

        foreach ($active_patches as $patch_id => &$patch) {
            if (empty($patch['enabled'])) {
                continue;
            }

            // CAF 2.0: Skip virtual patches for components/plugins not currently installed or active
            $comp = is_array($patch['component'] ?? null) ? ($patch['component']['slug'] ?? '') : ($patch['component'] ?? '');
            $target_slug = strtolower((string) ($patch['target'] ?? $comp));
            if (!empty($target_slug) && !in_array($target_slug, ['core', 'wordpress-core', 'generic', 'server', 'php', 'all-plugins', 'custom', 'test-plugin'], true)) {
                if (class_exists('\\WebCareProScanner\\Firewall\\CAF\\AdaptiveFirewallAdvisor') &&
                    !\WebCareProScanner\Firewall\CAF\AdaptiveFirewallAdvisor::is_plugin_slug_active($target_slug)) {
                    continue;
                }
            }

            // Check Declarative Patch match logic (PR-K wiring: route + method + source + key + predicate)
            if (!empty($patch['match']) && is_array($patch['match'])) {
                $match = $patch['match'];
                $match_route = (string) ($match['route'] ?? '/');
                $match_method = strtoupper((string) ($match['method'] ?? '*'));

                if ($match_method !== '*' && $match_method !== $method) {
                    continue;
                }

                if ($match_route !== '/' && !str_starts_with($request_uri, $match_route) && stripos($request_uri, $match_route) === false) {
                    continue;
                }

                $predicate = (string) ($match['predicate'] ?? '');
                $matched_declarative = false;
                $evidence = 'Declarative match';

                if ($predicate === 'true' || empty($predicate)) {
                    $matched_declarative = true;
                } elseif (str_starts_with($predicate, 'header.')) {
                    // Evaluate header predicate (e.g. header.x-wcpay != "")
                    if (preg_match('/header\.([a-zA-Z0-9_-]+)\s*(!=|==)\s*"?([^"]*)"?/', $predicate, $pm)) {
                        $hdr_name = 'HTTP_' . strtoupper(str_replace('-', '_', $pm[1]));
                        $hdr_op   = $pm[2];
                        $hdr_val  = $pm[3];
                        $actual   = (string) ($_SERVER[$hdr_name] ?? '');
                        if ($hdr_op === '!=' && $actual !== $hdr_val) {
                            $matched_declarative = true;
                            $evidence = "Header {$pm[1]}: {$actual}";
                        } elseif ($hdr_op === '==' && $actual === $hdr_val) {
                            $matched_declarative = true;
                            $evidence = "Header {$pm[1]}: {$actual}";
                        }
                    }
                } elseif (!empty($rule['regex'])) {
                    // Predicate with regex
                    if (!empty($query_string) && preg_match($rule['regex'], $query_string, $m)) {
                        $matched_declarative = true;
                        $evidence = $m[0];
                    } elseif (!empty($raw_body) && preg_match($rule['regex'], $raw_body, $m)) {
                        $matched_declarative = true;
                        $evidence = substr($m[0], 0, 100);
                    }
                }

                if ($matched_declarative) {
                    $stage = (string) ($patch['stage'] ?? DeclarativePatchVerifier::STAGE_ACTIVE);
                    if ($stage === DeclarativePatchVerifier::STAGE_SHADOW) {
                        // Shadow mode: observe and log hit telemetry without blocking
                        $active = self::get_active_patches();
                        if (isset($active[$patch_id])) {
                            $active[$patch_id]['hits'] = ($active[$patch_id]['hits'] ?? 0) + 1;
                            $active[$patch_id]['last_hit'] = current_time('mysql');
                            update_option(self::OPTION_PATCHES, $active, false);
                        }
                        AuditLogger::log_event(
                            'VPATCH_SHADOW_OBSERVE',
                            sprintf('Virtual patch %s matched in shadow mode (observe-only): %s', $patch_id, $evidence)
                        );
                        continue;
                    }

                    return self::trigger_patch_block($patch_id, $patch, $evidence, 'Declarative Match');
                }

                continue;
            }

            $rule = $patch['php_rule'] ?? [];
            if (empty($rule)) {
                continue;
            }

            // Check Method restriction
            if (!empty($rule['methods']) && is_array($rule['methods'])) {
                $allowed_methods = array_map('strtoupper', (array) $rule['methods']);
                if (!in_array('*', $allowed_methods, true) && !in_array($method, $allowed_methods, true)) {
                    continue;
                }
            }

            // Check URI match
            $uri_matches = false;
            if (!empty($rule['target_uris']) && is_array($rule['target_uris'])) {
                foreach ($rule['target_uris'] as $target_uri) {
                    if ($target_uri === '/' || stripos($request_uri, $target_uri) !== false) {
                        $uri_matches = true;
                        break;
                    }
                }
            } else {
                $uri_matches = true;
            }

            if (!$uri_matches) {
                continue;
            }

            // Check Headers
            if (!empty($rule['headers']) && is_array($rule['headers'])) {
                foreach ($rule['headers'] as $h_key) {
                    $norm_header = 'HTTP_' . strtoupper(str_replace('-', '_', $h_key));
                    if (!empty($_SERVER[$norm_header])) {
                        $h_val = sanitize_text_field(wp_unslash($_SERVER[$norm_header]));
                        if (!empty($rule['regex']) && preg_match($rule['regex'], $h_val)) {
                            return self::trigger_patch_block($patch_id, $patch, $h_val, 'HTTP Header: ' . $h_key);
                        }
                    }
                }
                // Header-targeted rules must not leak their header regex into query string or POST parameters
                continue;
            }

            // Check Query string and Body with Regex
            if (!empty($rule['regex'])) {
                $matched_evidence = '';

                if (!empty($query_string) && preg_match($rule['regex'], urldecode($query_string), $matches)) {
                    $matched_evidence = $matches[0];
                } elseif (!empty($raw_body) && preg_match($rule['regex'], $raw_body, $matches)) {
                    $matched_evidence = substr($matches[0], 0, 100);
                // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Early runtime virtual patch evaluation executes before nonces
                } elseif (!empty($_POST)) {
                    // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Early runtime virtual patch evaluation executes before nonces
                    $raw_post = is_array($_POST) ? wp_unslash($_POST) : [];
                    $flat_post = (string) wp_json_encode($raw_post);
                    if (preg_match($rule['regex'], $flat_post, $matches) || preg_match($rule['regex'], rawurldecode($flat_post), $matches)) {
                        $matched_evidence = substr($matches[0], 0, 100);
                    }
                }

                if (!empty($matched_evidence)) {
                    return self::trigger_patch_block($patch_id, $patch, $matched_evidence, 'Payload Parameter');
                }
            }
        }

        return null;
    }

    /**
     * Trigger Patch Block and Increment Counters.
     */
    private static function trigger_patch_block(string $patch_id, array &$patch, string $evidence, string $match_type): array {
        // Increment hit counter in options
        $active = self::get_active_patches();
        if (isset($active[$patch_id])) {
            $active[$patch_id]['hits'] = ($active[$patch_id]['hits'] ?? 0) + 1;
            $active[$patch_id]['last_hit'] = current_time('mysql');
            update_option(self::OPTION_PATCHES, $active, false);
        }

        return [
            'id'          => 'VPATCH-' . $patch_id,
            'name'        => '[Virtual Patch] ' . ($patch['title'] ?? $patch_id),
            'category'    => 'Virtual Patch (CVE Shield)',
            'detector'    => 'VirtualPatchManager',
            'sig_id'      => 'cve:' . strtolower($patch_id),
            'match_type'  => $match_type,
            'match_value' => substr($evidence, 0, 120),
        ];
    }

    /**
     * Deploy Virtual Patch Expression to Cloudflare Global Edge.
     */
    public static function deploy_to_cloudflare_edge(array $patch): array {
        $settings = SettingsManager::get_settings();
        $zone_id = $settings['cloudflare_zone_id'] ?? '';
        $token = $settings['cloudflare_api_token'] ?? '';

        if (empty($zone_id) || empty($token)) {
            return ['success' => false, 'message' => __('Cloudflare API Token or Zone ID is not configured in Settings.', 'webcare-pro-security')];
        }

        if (!class_exists('\\WebCareProScanner\\Cloudflare\\CloudflareService')) {
            $cf_file = defined('WEBCAREPROSCAN_PATH') ? WEBCAREPROSCAN_PATH . 'includes/Cloudflare/CloudflareService.php' : dirname(__DIR__) . '/Cloudflare/CloudflareService.php';
            if (file_exists($cf_file)) {
                require_once $cf_file;
            }
        }

        if (!class_exists('\\WebCareProScanner\\Cloudflare\\CloudflareService')) {
            return ['success' => false, 'message' => __('Cloudflare integration service is unavailable.', 'webcare-pro-security')];
        }

        // Fetch existing ruleset
        $res = CloudflareService::request("zones/{$zone_id}/rulesets/phases/http_request_firewall_custom/entrypoint");
        $rules = [];

        if (!empty($res['success']) && !empty($res['result']['rules'])) {
            foreach ($res['result']['rules'] as $r) {
                // Keep other rules
                $desc = $r['description'] ?? '';
                if (strpos($desc, self::CF_TAG . ' ' . $patch['patch_id']) === false) {
                    $rules[] = $r;
                }
            }
        }

        // Append new virtual patch rule
        $rule_desc = self::CF_TAG . ' ' . $patch['patch_id'] . ': ' . substr($patch['title'], 0, 60);
        $rules[] = [
            'action'      => 'block',
            'expression'  => $patch['cf_expression'],
            'description' => $rule_desc,
            'enabled'     => true,
        ];

        // Cloudflare Free allows up to 5 custom rules. Check limit
        if (count($rules) > 10) {
            // Keep rules within limit
            $rules = array_slice($rules, -10);
        }

        $put_res = CloudflareService::request(
            "zones/{$zone_id}/rulesets/phases/http_request_firewall_custom/entrypoint",
            'PUT',
            ['rules' => $rules]
        );

        if (!empty($put_res['success'])) {
            return [
                'success' => true,
                'rule_id' => $patch['patch_id'],
                'message' => __('Cloudflare Edge Rule synced successfully.', 'webcare-pro-security'),
            ];
        }

        $err = $put_res['errors'][0]['message'] ?? __('Cloudflare API rejected rule expression.', 'webcare-pro-security');
        return ['success' => false, 'message' => $err];
    }

    /**
     * Remove Virtual Patch Rule from Cloudflare Global Edge.
     */
    public static function remove_from_cloudflare_edge(string $patch_id): bool {
        $settings = SettingsManager::get_settings();
        $zone_id = $settings['cloudflare_zone_id'] ?? '';
        if (empty($zone_id)) {
            return false;
        }

        if (!class_exists('\\WebCareProScanner\\Cloudflare\\CloudflareService')) {
            $cf_file = defined('WEBCAREPROSCAN_PATH') ? WEBCAREPROSCAN_PATH . 'includes/Cloudflare/CloudflareService.php' : dirname(__DIR__) . '/Cloudflare/CloudflareService.php';
            if (file_exists($cf_file)) {
                require_once $cf_file;
            }
        }

        if (!class_exists('\\WebCareProScanner\\Cloudflare\\CloudflareService')) {
            return false;
        }

        $res = CloudflareService::request("zones/{$zone_id}/rulesets/phases/http_request_firewall_custom/entrypoint");
        if (empty($res['success']) || empty($res['result']['rules'])) {
            return false;
        }

        $remaining_rules = [];
        foreach ($res['result']['rules'] as $r) {
            $desc = $r['description'] ?? '';
            if (strpos($desc, self::CF_TAG . ' ' . $patch_id) === false) {
                $remaining_rules[] = $r;
            }
        }

        $put_res = CloudflareService::request(
            "zones/{$zone_id}/rulesets/phases/http_request_firewall_custom/entrypoint",
            'PUT',
            ['rules' => $remaining_rules]
        );

        return !empty($put_res['success']);
    }
}
