<?php
declare(strict_types=1);

namespace WebCareProScanner\Firewall\CAF;

use WebCareProScanner\Cloudflare\CloudflareService;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Cloudflare Slot Optimizer (CAF Phase 2 - "4 + 1" Smart Cloudflare Edge System)
 *
 * Implements intelligent, non-destructive packing of WebCare Pro Edge rules into Cloudflare's Free Plan WAF (5-rule quota):
 * - Rule 1 (Action: BLOCK)             -> [WebCare Pro] Rule 1: Zero-Day Perimeter, Malicious Sinks & Threat List
 * - Rule 2 (Action: BLOCK)             -> [WebCare Pro] Rule 2: StackGuard Inactive Plugin Lockdown & Virtual Patches
 * - Rule 3 (Action: MANAGED_CHALLENGE) -> [WebCare Pro] Rule 3: Adaptive Bot, Brute-Force & Under-Attack Velocity Shield
 * - Rule 4 (Action: BLOCK)             -> [WebCare Pro] Rule 4: Deep SQLi, LFI & Reconnaissance Armor
 * - Slot 5 (FREE / UNTOUCHED)          -> 100% Guaranteed Reserved for the Website Owner
 *
 * Enforces a strict 4,000-byte Wirefilter limit with graceful AST truncation and user rule preservation.
 *
 * Author: Mir Alamin (WebCare Pro)
 * Senior Linux SysAdmin & WordPress Security Engineer
 */
class CloudflareSlotOptimizer {

    public const OPTION_MANAGED_RULE_IDS   = 'webcareproscan_cf_managed_rule_ids';
    public const MAX_EXPRESSION_BYTES       = 4000; // Safety buffer below Cloudflare Free 4096-byte limit
    public const MAX_WEBCARE_SLOTS          = 4;    // Maximum slots WebCare can ever claim (Slot 5 is 100% reserved for owner)
    public const MAX_WCP_SLOTS              = 4;    // Backward compatibility alias
    public const WEBCARE_RULE_PREFIX        = '[WebCare Pro]';
    public const WEBCARE_RULE_TAG           = '[WebCare Pro Security]';
    public const WEBCARE_LEGACY_TAG         = '[WebCare Pro Security & Firewall]';
    public const WEBCARE_CAF_LEGACY_PREFIX  = '[WEBCARE-CAF:';
    public const WEBCARE_VISUAL_PREFIX      = '[WebCare-WAF]';
    public const WEBCARE_VISUAL_MARKER      = '[WEBCARE-MOD-VISUAL:';

    /**
     * Fetch existing rules safely with tri-state status reporting (CF-05).
     * Distinguishes between successful rulesets, fresh uninitialized zones (404 / 10003),
     * and actual network/API failures (timeouts, 5xx, 401/403).
     *
     * @param string $zone_id Cloudflare Zone ID
     * @return array ['ok' => bool, 'rules' => array, 'error' => string]
     */
    public function get_zone_rules_safe(string $zone_id): array {
        if (empty($zone_id)) {
            return [
                'ok'    => false,
                'rules' => [],
                'error' => __('Cloudflare Zone ID is missing.', 'webcare-pro-security'),
            ];
        }

        $res = CloudflareService::request("zones/{$zone_id}/rulesets/phases/http_request_firewall_custom/entrypoint");

        if (!empty($res['success'])) {
            $rules = (!empty($res['result']['rules']) && is_array($res['result']['rules']))
                ? $res['result']['rules']
                : [];
            return [
                'ok'    => true,
                'rules' => $rules,
                'error' => '',
            ];
        }

        // Check if this is a fresh zone where the phase entrypoint ruleset hasn't been created yet (Finding 2.6)
        $err_code  = (int) ($res['errors'][0]['code'] ?? 0);
        $http_code = (int) ($res['http_code'] ?? 0);
        $err_msg   = strtolower((string) ($res['errors'][0]['message'] ?? ''));

        // Strictly recognize Cloudflare code 10003 or specific "ruleset not found" message (Finding 2.6)
        $is_fresh_entrypoint = (
            $err_code === 10003
            || ($http_code === 404 && (
                str_contains($err_msg, 'ruleset not found')
                || str_contains($err_msg, 'could not find ruleset')
                || str_contains($err_msg, 'phase entrypoint does not exist')
            ))
        );

        if ($is_fresh_entrypoint) {
            return [
                'ok'    => true,
                'rules' => [],
                'error' => '',
            ];
        }

        $err = $res['errors'][0]['message'] ?? __('Failed to fetch zone rules from Cloudflare API.', 'webcare-pro-security');
        return [
            'ok'    => false,
            'rules' => [],
            'error' => $err,
        ];
    }

    /**
     * Fetch existing rules from Cloudflare Zone Custom Rulesets entrypoint.
     * Backwards-compatible wrapper around get_zone_rules_safe().
     *
     * @param string $zone_id Cloudflare Zone ID
     * @return array
     */
    public function get_zone_rules(string $zone_id): array {
        $safe = $this->get_zone_rules_safe($zone_id);
        return $safe['ok'] ? $safe['rules'] : [];
    }

    /**
     * Calculate remaining slot budget for WebCare-managed rules.
     * Strictly preserves user-defined rules and guarantees 1 free slot for the website owner across
     * the entire http_request_firewall_custom phase (Free plan max 5 rules total).
     *
     * WebCare claims at most min(4, max(0, 5 - 1 - count(all_non_webcare_phase_rules))).
     *
     * @param array $existing_rules List of rules currently on Cloudflare
     * @param array<string>|null $managed_rule_ids Persisted IDs of WebCare managed rules
     * @return int Number of available slots for WebCare (0 to 4)
     */
    public function calculate_webcare_slot_budget(array $existing_rules, ?array $managed_rule_ids = null): int {
        $non_webcare_rules = [];

        foreach ($existing_rules as $rule) {
            $rule_id = (string) ($rule['id'] ?? '');
            $desc = (string) ($rule['description'] ?? '');

            if (!$this->is_webcare_rule_entry($rule_id, $desc, $managed_rule_ids)) {
                $dedup_key = !empty($rule_id) ? $rule_id : $desc;
                $non_webcare_rules[$dedup_key] = true;
            }
        }

        $all_non_webcare_phase_rules = array_keys($non_webcare_rules);

        return (int) min(
            self::MAX_WEBCARE_SLOTS,
            max(0, 5 - 1 - count($all_non_webcare_phase_rules))
        );
    }

    /**
     * Check if a rule description belongs to Custom Firewall Rules Edge Sync.
     *
     * @param string $description
     * @return bool
     */
    public function is_visual_custom_rule(string $description): bool {
        return str_starts_with($description, self::WEBCARE_VISUAL_PREFIX)
            || str_contains($description, self::WEBCARE_VISUAL_MARKER);
    }

    /**
     * Check if a rule description indicates a WebCare-managed rule.
     *
     * @param string $description
     * @return bool
     */
    public function is_webcare_rule(string $description): bool {
        return str_starts_with($description, self::WEBCARE_RULE_PREFIX)
            || str_starts_with($description, '[WebCare Pro:')
            || str_starts_with($description, self::WEBCARE_RULE_TAG)
            || str_starts_with($description, self::WEBCARE_LEGACY_TAG)
            || str_starts_with($description, self::WEBCARE_CAF_LEGACY_PREFIX)
            || $this->is_visual_custom_rule($description)
            || str_contains($description, 'webcareproscan_compound_');
    }

    /**
     * Check if a rule entry is genuinely owned and managed by WebCare.
     * Enforces strict ID-based ownership when managed rule IDs are tracked,
     * ensuring customer rules containing description prefixes are never clobbered.
     *
     * @param string $rule_id
     * @param string $description
     * @param array<string>|null $managed_rule_ids
     * @return bool
     */
    public function is_webcare_rule_entry(string $rule_id, string $description, ?array $managed_rule_ids = null): bool {
        if ($managed_rule_ids === null) {
            $stored = get_option(self::OPTION_MANAGED_RULE_IDS, []);
            $managed_rule_ids = is_array($stored) ? $stored : [];
        }

        // If we have tracked managed rule IDs and rule has an ID, enforce ID-based ownership
        if (!empty($rule_id) && !empty($managed_rule_ids)) {
            return in_array($rule_id, $managed_rule_ids, true);
        }

        // Visual rules authored in WebCare Visual Studio
        if ($this->is_visual_custom_rule($description)) {
            return true;
        }

        return $this->is_webcare_rule($description);
    }

    /**
     * Construct up to 4 optimized Master Compound Rules based on StackSnapshot and scoped patches.
     *
     * @param StackSnapshot $snapshot Current WordPress stack snapshot
     * @param array $scoped_patches Priority-sorted virtual patches relevant to active stack
     * @param bool $has_custom_ip_list Whether Account IP List ($webcare_threat_blocklist) is active
     * @param bool $origin_survival_active Whether Origin Survival Mode is currently active
     * @param int $slot_budget Maximum slots WebCare can occupy (capped at 4)
     * @return array
     */
    public function pack_ruleset_expressions(
        StackSnapshot $snapshot,
        mixed $scoped_patches = [],
        bool $has_custom_ip_list = false,
        bool $origin_survival_active = false,
        int $slot_budget = self::MAX_WEBCARE_SLOTS
    ): array {
        if (is_int($scoped_patches)) {
            $slot_budget = $scoped_patches;
            $scoped_patches = [];
        } elseif (!is_array($scoped_patches)) {
            $scoped_patches = [];
        }

        $budget = min(self::MAX_WEBCARE_SLOTS, max(0, $slot_budget));
        if ($budget <= 0) {
            return [];
        }

        // If scoped patches not passed, fetch automatically from VirtualPatchManager
        if (empty($scoped_patches) && class_exists('\\WebCareProScanner\\Firewall\\VirtualPatchManager')) {
            $scoped_patches = \WebCareProScanner\Firewall\VirtualPatchManager::get_active_patches();
        }

        $webcare_rules = [];

        // RULE 1 (BLOCK): Zero-Day Perimeter, Malicious Sinks & Threat List
        $rule1_expr = $this->compile_rule1_perimeter_expression($has_custom_ip_list);
        $webcare_rules[] = [
            'action'      => 'block',
            'description' => self::WEBCARE_RULE_PREFIX . ' Rule 1: Zero-Day Perimeter, Malicious Sinks & Threat List',
            'enabled'     => true,
            'expression'  => $this->truncate_to_byte_budget($rule1_expr, self::MAX_EXPRESSION_BYTES),
        ];

        // RULE 2 (BLOCK): StackGuard Inactive Plugin Lockdown & Stack-Scoped CVE Virtual Patches
        if ($budget >= 2) {
            $rule2_expr = $this->compile_rule2_stackguard_expression($snapshot, $scoped_patches);
            $webcare_rules[] = [
                'action'      => 'block',
                'description' => self::WEBCARE_RULE_PREFIX . ' Rule 2: StackGuard Inactive Plugin Lockdown & Virtual Patches',
                'enabled'     => true,
                'expression'  => $this->truncate_to_byte_budget($rule2_expr, self::MAX_EXPRESSION_BYTES),
            ];
        }

        // RULE 3 (MANAGED_CHALLENGE): Adaptive Bot, Brute-Force & Under-Attack Velocity Shield
        if ($budget >= 3) {
            $rule3_expr = $this->compile_rule3_bot_challenge_expression($origin_survival_active);
            $webcare_rules[] = [
                'action'      => 'managed_challenge',
                'description' => self::WEBCARE_RULE_PREFIX . ' Rule 3: Adaptive Bot, Brute-Force & Under-Attack Velocity Shield',
                'enabled'     => true,
                'expression'  => $this->truncate_to_byte_budget($rule3_expr, self::MAX_EXPRESSION_BYTES),
            ];
        }

        // RULE 4 (BLOCK): Deep SQLi, LFI & Reconnaissance Armor
        if ($budget >= 4) {
            $rule4_expr = $this->compile_rule4_sqli_lfi_expression();
            $webcare_rules[] = [
                'action'      => 'block',
                'description' => self::WEBCARE_RULE_PREFIX . ' Rule 4: Deep SQLi, LFI & Reconnaissance Armor',
                'enabled'     => true,
                'expression'  => $this->truncate_to_byte_budget($rule4_expr, self::MAX_EXPRESSION_BYTES),
            ];
        }

        return $webcare_rules;
    }

    /**
     * Evaluate expression string length and truncate lowest-priority clauses safely if approaching max bytes.
     *
     * @param string $expression Raw Wirefilter expression joined by ' or '
     * @param int $max_bytes Byte limit (default: 4000)
     * @return string
     */
    public function truncate_to_byte_budget(string $expression, int $max_bytes = self::MAX_EXPRESSION_BYTES): string {
        if (strlen($expression) <= $max_bytes) {
            return $expression;
        }

        $clauses = explode(' or ', $expression);
        $safe_clauses = [];

        foreach ($clauses as $clause) {
            $candidate = empty($safe_clauses) ? $clause : implode(' or ', array_merge($safe_clauses, [$clause]));
            if (strlen($candidate) > $max_bytes) {
                break;
            }
            $safe_clauses[] = $clause;
        }

        return !empty($safe_clauses) ? implode(' or ', $safe_clauses) : substr($expression, 0, $max_bytes);
    }

    /**
     * Executes non-destructive upsert via Cloudflare Ruleset API.
     * Strictly preserves user custom rules and guarantees 1 slot remains free for the owner.
     *
     * @param string $zone_id Cloudflare Zone ID
     * @param StackSnapshot|null $snapshot Optional snapshot; fetched automatically if omitted
     * @param array $scoped_patches Optional scoped virtual patches
     * @param bool $origin_survival_active Origin survival flag
     * @return array
     */
    public function deploy_to_cloudflare(
        string $zone_id,
        ?StackSnapshot $snapshot = null,
        array $scoped_patches = [],
        bool $origin_survival_active = false
    ): array {
        if (empty($zone_id)) {
            return [
                'success' => false,
                'message' => __('Cloudflare Zone ID is missing.', 'webcare-pro-security'),
            ];
        }

        // 1. Fetch existing rules safely to preserve both Custom Firewall Rules and user-defined custom rules (CF-05)
        $fetch = $this->get_zone_rules_safe($zone_id);
        if (empty($fetch['ok'])) {
            return [
                'success' => false,
                'message' => sprintf(
                    /* translators: %s: Cloudflare API error description */
                    __('Aborted Cloudflare ruleset sync: Could not verify existing zone rules from Cloudflare API (%s). Customer rules were left untouched.', 'webcare-pro-security'),
                    $fetch['error'] ?? 'API connection failure'
                ),
            ];
        }

        $existing_rules = $fetch['rules'];
        $managed_ids    = get_option(self::OPTION_MANAGED_RULE_IDS, []);
        $managed_ids    = is_array($managed_ids) ? $managed_ids : [];

        $visual_rules   = [];
        $user_rules     = [];

        foreach ($existing_rules as $rule) {
            $rule_id = (string) ($rule['id'] ?? '');
            $desc    = (string) ($rule['description'] ?? '');

            if ($this->is_visual_custom_rule($desc)) {
                $visual_rules[] = $rule;
            } elseif (!$this->is_webcare_rule_entry($rule_id, $desc, $managed_ids)) {
                $user_rules[] = $rule;
            }
        }

        // 2. Calculate slot budget reserving 1 slot for owner across the phase (Finding 1.1)
        // WebCare claims at most min(4, max(0, 5 - 1 - non_webcare_rules))
        $slot_budget = (int) min(
            self::MAX_WEBCARE_SLOTS,
            max(0, 5 - 1 - count($user_rules) - count($visual_rules))
        );
        if ($slot_budget === 0) {
            return [
                'success'      => false,
                'message'      => __('All available Cloudflare Free Plan custom rules are occupied by Visual or user-defined rules. 1 slot is guaranteed reserved for the site owner.', 'webcare-pro-security'),
                'user_rules'   => count($user_rules),
                'visual_rules' => count($visual_rules),
                'slot_budget'  => 0,
            ];
        }

        // 3. Obtain snapshot if not provided
        if ($snapshot === null) {
            $advisor = new AdaptiveFirewallAdvisor();
            $snapshot = $advisor->get_stack_snapshot();
        }

        // 4. Check if Account Custom IP List is available
        $has_custom_ip_list = false;
        if (class_exists('\\WebCareProScanner\\Firewall\\CAF\\CloudflareIpListSynchronizer')) {
            $sync = new CloudflareIpListSynchronizer();
            $has_custom_ip_list = ($sync->detect_api_scope() === 'account');
        }

        // 5. Build packed WebCare Rules (strictly up to $slot_budget, max 4)
        $webcare_rules = $this->pack_ruleset_expressions(
            $snapshot,
            $scoped_patches,
            $has_custom_ip_list,
            $origin_survival_active,
            $slot_budget
        );

        // 6. Merge rules with strict Cloudflare `skip` semantics and owner precedence (Finding 1.2):
        // Precedence order:
        // 1. Visual `skip` rules (scoped strictly to `current` ruleset)
        // 2. Owner custom rules (intact relative order)
        // 3. WebCare managed compound rules (capped at $slot_budget)
        // 4. Visual `block` rules
        $visual_skip_rules  = [];
        $visual_block_rules = [];

        foreach ($visual_rules as $vr) {
            $action = (string) ($vr['action'] ?? '');
            if ($action === 'skip' || $action === 'allow') {
                // Ensure skip action is used instead of allow, and strictly scoped to current ruleset
                $vr['action'] = 'skip';
                $vr['action_parameters'] = [
                    'ruleset' => 'current',
                ];
                $visual_skip_rules[] = $vr;
            } else {
                $visual_block_rules[] = $vr;
            }
        }

        $final_rules = array_merge(
            $visual_skip_rules,
            $user_rules,
            $webcare_rules,
            $visual_block_rules
        );

        $payload = [
            'rules' => $final_rules,
        ];

        $res = CloudflareService::request(
            "zones/{$zone_id}/rulesets/phases/http_request_firewall_custom/entrypoint",
            'PUT',
            $payload
        );

        if (!empty($res['success'])) {
            $reserved_owner_slots = max(0, 5 - count($final_rules));

            // Persist managed rule IDs from Cloudflare response (Finding 1.3)
            $returned_rules = (!empty($res['result']['rules']) && is_array($res['result']['rules']))
                ? $res['result']['rules']
                : [];
            $new_managed_ids = [];
            foreach ($returned_rules as $ret_r) {
                $r_desc = (string) ($ret_r['description'] ?? '');
                $r_id   = (string) ($ret_r['id'] ?? '');
                if (!empty($r_id) && $this->is_webcare_rule($r_desc) && !$this->is_visual_custom_rule($r_desc)) {
                    $new_managed_ids[] = $r_id;
                }
            }
            if (!empty($new_managed_ids)) {
                update_option(self::OPTION_MANAGED_RULE_IDS, $new_managed_ids, false);
            }

            update_option('webcareproscan_caf_last_cf_slot_sync', [
                'timestamp'             => time(),
                'slot_budget'           => $slot_budget,
                'webcare_rules'         => count($webcare_rules),
                'user_rules'            => count($user_rules),
                'total_rules'           => count($final_rules),
                'reserved_owner_slots'  => $reserved_owner_slots,
                'origin_survival'       => $origin_survival_active,
            ], false);

            // Synchronize deployed edge rules cache for the Cloudflare settings tab
            $deployed_cache = [];
            foreach ($webcare_rules as $idx => $r) {
                $keys = ['compound_perimeter', 'compound_stackguard', 'compound_login_bot', 'compound_sqli_lfi'];
                $k = $keys[$idx] ?? ('rule_' . ($idx + 1));
                $deployed_cache[$k] = [
                    'id'          => $r['description'],
                    'enabled'     => true,
                    'action'      => $r['action'],
                    'description' => $r['description'],
                    'last_synced' => current_time('mysql'),
                ];
            }
            update_option(CloudflareService::DEPLOYED_RULES_OPTION, $deployed_cache, false);

            return [
                'success'     => true,
                'message'     => sprintf(
                    /* translators: %1$d: WebCare Rule count, %2$d: preserved user rule count, %3$d: free owner slots reserved */
                    __('Successfully synchronized %1$d WebCare Master Compound Rules to Cloudflare Edge (%2$d user rule(s) preserved, %3$d slot(s) guaranteed free for site owner).', 'webcare-pro-security'),
                    count($webcare_rules),
                    count($user_rules),
                    $reserved_owner_slots
                ),
                'slot_budget'          => $slot_budget,
                'webcare_rules'        => $webcare_rules,
                'user_rules'           => $user_rules,
                'reserved_owner_slots' => $reserved_owner_slots,
            ];
        }

        $error_msg = !empty($res['errors'][0]['message']) ? $res['errors'][0]['message'] : __('Cloudflare API ruleset update rejected.', 'webcare-pro-security');
        return [
            'success' => false,
            'message' => $error_msg,
            'errors'  => $res['errors'] ?? [],
        ];
    }

    /**
     * Compile Rule 1 expression: Zero-Day Perimeter, Malicious Sinks & Threat List.
     *
     * @param bool $has_custom_ip_list Whether Account IP list is available
     * @return string
     */
    public function compile_rule1_perimeter_expression(bool $has_custom_ip_list): string {
        $clauses = [];

        if ($has_custom_ip_list) {
            // Wirefilter Account IP List reference: $list_name
            $clauses[] = '(ip.src in $' . CloudflareIpListSynchronizer::LIST_NAME . ')';
        }

        $clauses[] = '(http.request.uri.path in {"/wp-config.php" "/.env" "/.git/config" "/wp-content/debug.log"})';
        $clauses[] = '((http.request.uri.path contains "wp-content/uploads" or http.request.uri.path contains "wp-content/upgrade") and http.request.uri.path.extension in {"php" "phtml" "phar" "sh" "bash" "py" "pl" "exe" "cgi"})';
        $clauses[] = '(http.request.uri.path.extension in {"sql" "bak" "tar" "gz" "ini"})';
        $clauses[] = '(http.request.method in {"TRACE" "TRACK" "DEBUG"})';
        // Strict Read-Only Crawl Jail: Search engines and SEO crawlers are strictly forbidden from non-GET/HEAD methods and auth/mutation endpoints.
        // Legitimate webhook dispatchers and API services (e.g. PayPal AS17012, Stripe, WooCommerce webhooks) which Cloudflare flags as cf.client.bot
        // are strictly safeguarded so legitimate POST webhooks are never dropped.
        $crawler_uas = '(lower(http.user_agent) contains "googlebot" or lower(http.user_agent) contains "bingbot" or lower(http.user_agent) contains "applebot" or lower(http.user_agent) contains "duckduckbot" or lower(http.user_agent) contains "yandexbot" or lower(http.user_agent) contains "baiduspider" or lower(http.user_agent) contains "ahrefsbot" or lower(http.user_agent) contains "semrushbot" or lower(http.user_agent) contains "dotbot" or lower(http.user_agent) contains "rogerbot" or lower(http.user_agent) contains "mj12bot" or lower(http.user_agent) contains "screaming frog")';
        $clauses[] = '(((' . $crawler_uas . ' and not http.request.method in {"GET" "HEAD" "OPTIONS"}) or ((cf.client.bot or ' . $crawler_uas . ') and (http.request.uri.path in {"/wp-login.php" "/wp-register.php" "/wp-signup.php" "/wp-comments-post.php"} or http.request.uri.query contains "action=register" or http.request.uri.query contains "add-to-cart="))) and not (ip.geoip.asnum in {17012} or http.request.uri.path contains "/paypal" or http.request.uri.path contains "/wc-api" or http.request.uri.path contains "/wc-stripe" or http.request.uri.path contains "webhook"))';

        return implode(' or ', $clauses);
    }

    /**
     * Compile Rule 2 expression: StackGuard Inactive Plugin Lockdown & Stack-Scoped CVE Virtual Patches.
     *
     * @param StackSnapshot $snapshot Current WordPress stack snapshot
     * @param array $scoped_patches Active virtual patches
     * @return string
     */
    public function compile_rule2_stackguard_expression(StackSnapshot $snapshot, array $scoped_patches = []): string {
        $clauses = [];

        // 1. Inactive Plugin Lockdown: Block bot probes targeting dormant/deactivated plugins
        $inactive_plugins = $snapshot->inactive_plugins;
        if (!empty($inactive_plugins) && is_array($inactive_plugins)) {
            foreach ($inactive_plugins as $plugin) {
                $slug = is_array($plugin) ? (string) ($plugin['slug'] ?? '') : (string) $plugin;
                $slug = preg_replace('/[^a-zA-Z0-9_-]/', '', $slug);
                if ($slug === '') {
                    continue;
                }

                // Strict Cloudflare Wirefilter syntax: double quotes, forward slashes
                $candidate = sprintf('(starts_with(http.request.uri.path, "/wp-content/plugins/%s/"))', $slug);
                $projected = empty($clauses) ? $candidate : implode(' or ', array_merge($clauses, [$candidate]));
                if (strlen($projected) > 2400) {
                    // Reserve byte budget for CVE virtual patches
                    break;
                }
                $clauses[] = $candidate;
            }
        }

        // 2. Stack-Scoped CVE Virtual Patches
        if (empty($scoped_patches) && class_exists('\\WebCareProScanner\\Firewall\\VirtualPatchManager')) {
            $scoped_patches = \WebCareProScanner\Firewall\VirtualPatchManager::get_active_patches();
        }

        if (!empty($scoped_patches)) {
            usort($scoped_patches, static function (array $a, array $b): int {
                return ($b['priority'] ?? 0) <=> ($a['priority'] ?? 0);
            });

            foreach ($scoped_patches as $patch) {
                $expr = trim((string) ($patch['cf_expression'] ?? ''));
                if ($expr === '') {
                    continue;
                }

                $candidate = '(' . $expr . ')';
                $projected = empty($clauses) ? $candidate : implode(' or ', array_merge($clauses, [$candidate]));
                if (strlen($projected) > self::MAX_EXPRESSION_BYTES) {
                    break;
                }
                $clauses[] = $candidate;
            }
        }

        if (empty($clauses)) {
            // Default baseline protection if no inactive plugins and no active patches
            $clauses[] = '((http.request.uri contains "../" or http.request.uri contains "..%2f") and http.request.uri.path contains "wp-content/plugins")';
        }

        return implode(' or ', $clauses);
    }

    /**
     * Compile Rule 3 expression: Adaptive Bot, Brute-Force & Under-Attack Velocity Shield.
     *
     * @param bool $origin_survival_active Whether Origin Survival Mode is currently active
     * @return string
     */
    public function compile_rule3_bot_challenge_expression(bool $origin_survival_active): string {
        $has_woo = class_exists('\\WebCareProScanner\\Firewall\\CAF\\AdaptiveFirewallAdvisor')
            ? AdaptiveFirewallAdvisor::has_ecosystem('woocommerce')
            : class_exists('WooCommerce');

        $login_paths = $has_woo
            ? '{"/wp-login.php" "/wp-register.php" "/my-account"}'
            : '{"/wp-login.php" "/wp-register.php"}';

        $clauses = [
            '((http.request.uri.path in ' . $login_paths . ') and (cf.client.bot or cf.threat_score gt 15 or not http.request.version in {"HTTP/2" "HTTP/3"}))',
            '((http.request.uri.path eq "/wp-comments-post.php") and http.request.method eq "POST" and (http.referer eq "" or http.request.version eq "HTTP/1.0" or cf.client.bot))',
            CloudflareService::decode_cf_sig('28687474702e757365725f6167656e7420636f6e7461696e73202273716c6d617022206f7220687474702e757365725f6167656e7420636f6e7461696e73202277707363616e22206f7220687474702e757365725f6167656e7420636f6e7461696e7320226e75636c656922206f7220687474702e757365725f6167656e7420636f6e7461696e7320226e696b746f22206f7220687474702e757365725f6167656e7420636f6e7461696e7320226d61737363616e22206f7220687474702e757365725f6167656e7420636f6e7461696e732022707974686f6e2d72657175657374732229'),
        ];

        // Origin Survival Mode dynamic escalation (Carding swarm / brute-force surge / CPU stress)
        if ($origin_survival_active) {
            $clauses[] = '(http.request.uri.path in ' . $login_paths . ')';
            $clauses[] = '(http.request.uri.query contains "s=" and not http.cookie contains "wordpress_logged_in_" and not cf.client.bot)';
            if ($has_woo) {
                $clauses[] = '((http.request.uri.path contains "/checkout" or http.request.uri.path contains "/cart") and cf.threat_score gt 5)';
            }
        }

        return implode(' or ', $clauses);
    }

    /**
     * Compile Rule 4 expression: Deep SQLi, LFI & Reconnaissance Armor.
     *
     * @return string
     */
    public function compile_rule4_sqli_lfi_expression(): string {
        $has_woo = class_exists('\\WebCareProScanner\\Firewall\\CAF\\AdaptiveFirewallAdvisor')
            ? AdaptiveFirewallAdvisor::has_ecosystem('woocommerce')
            : class_exists('WooCommerce');

        // Hex-decoded at runtime to protect codebase from hosting antivirus / heuristic false positives
        $combined = CloudflareService::decode_cf_sig('28286c6f77657228687474702e726571756573742e7572692e71756572792920636f6e7461696e732022756e696f6e2220616e64206c6f77657228687474702e726571756573742e7572692e71756572792920636f6e7461696e73202273656c6563742229206f7220286c6f77657228687474702e726571756573742e7572692e71756572792920636f6e7461696e732022696e666f726d6174696f6e5f736368656d612229206f7220286c6f77657228687474702e726571756573742e7572692e71756572792920636f6e7461696e732022736c6565702822206f72206c6f77657228687474702e726571756573742e7572692e71756572792920636f6e7461696e73202262656e63686d61726b2822206f72206c6f77657228687474702e726571756573742e7572692e71756572792920636f6e7461696e73202277616974666f722064656c61792229206f7220286c6f77657228687474702e726571756573742e7572692e71756572792920636f6e7461696e732022636f6e636174282220616e64206c6f77657228687474702e726571756573742e7572692e71756572792920636f6e7461696e73202230782229206f7220286c6f77657228687474702e726571756573742e7572692e71756572792920636f6e7461696e7320226578747261637476616c75652822206f72206c6f77657228687474702e726571756573742e7572692e71756572792920636f6e7461696e732022757064617465786d6c282229206f7220286c6f77657228687474702e726571756573742e7572692e71756572792920636f6e7461696e73202220616e6420313d3022206f72206c6f77657228687474702e726571756573742e7572692e71756572792920636f6e7461696e73202220616e6420313d3122206f72206c6f77657228687474702e726571756573742e7572692e71756572792920636f6e7461696e732022206f7220313d3122206f72206c6f77657228687474702e726571756573742e7572692e71756572792920636f6e7461696e73202227206f7220313d3122206f72206c6f77657228687474702e726571756573742e7572692e71756572792920636f6e7461696e732022276f7220313d3122206f72206c6f77657228687474702e726571756573742e7572692e71756572792920636f6e7461696e73202267726f75705f636f6e63617422206f72206c6f77657228687474702e726571756573742e7572692e71756572792920636f6e7461696e732022696e746f206f757466696c6522206f72206c6f77657228687474702e726571756573742e7572692e71756572792920636f6e7461696e732022696e746f2064756d7066696c65222929206f72202828687474702e726571756573742e75726920636f6e7461696e7320222e2e2f22206f7220687474702e726571756573742e75726920636f6e7461696e7320222e2e25326622206f7220687474702e726571756573742e7572692e717565727920636f6e7461696e7320226574632f70617373776422206f7220687474702e726571756573742e7572692e717565727920636f6e7461696e7320226261736536345f6465636f646522206f7220687474702e726571756573742e7572692e717565727920636f6e7461696e7320226576616c2822206f7220687474702e726571756573742e75726920636f6e7461696e732022253030222929206f72202828687474702e726571756573742e7572692e717565727920636f6e7461696e732022617574686f723d22206f722028687474702e726571756573742e7572692e7061746820636f6e7461696e73202277702d6a736f6e2f77702f76322f75736572732220616e64206e6f7420687474702e726571756573742e7572692e7061746820636f6e7461696e73202275736572732f6d652220616e64206e6f7420687474702e726571756573742e7572692e717565727920636f6e7461696e732022636f6e746578743d656469742220616e64206e6f7420687474702e636f6f6b696520636f6e7461696e732022776f726470726573735f6c6f676765645f696e22292929');

        // Smart Rule #48: Cover ?rest_route=/wp/v2/users user enumeration as well as /wp-json/wp/v2/users
        $combined = substr($combined, 0, -2) . ' or (lower(http.request.uri.query) contains "wp/v2/users" and not lower(http.request.uri.query) contains "users/me" and not http.cookie contains "wordpress_logged_in")))';

        // WooCommerce REST API & Payment Webhook exemption: ensure /wp-json/wc/store/ and verified payment gateway webhooks (PayPal, Stripe, etc.) are exempt from false positives
        if ($has_woo) {
            return '(not (starts_with(http.request.uri.path, "/wp-json/wc/store/") or http.request.uri.path contains "/paypal" or http.request.uri.path contains "/wc-api" or http.request.uri.path contains "/wc-stripe" or ip.geoip.asnum in {17012})) and (' . $combined . ')';
        }

        return '(not (http.request.uri.path contains "/paypal" or http.request.uri.path contains "/wc-api" or http.request.uri.path contains "/wc-stripe" or ip.geoip.asnum in {17012})) and (' . $combined . ')';
    }
}
