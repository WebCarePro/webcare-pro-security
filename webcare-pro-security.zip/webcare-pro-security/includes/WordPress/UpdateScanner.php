<?php
namespace WebCareProScanner\WordPress;

use WebCareProScanner\Findings\Finding;

if (!defined('ABSPATH')) {
    exit;
}

class UpdateScanner {

    /**
     * Cache duration for CVE / vulnerability queries (12 hours)
     */
    const CACHE_TTL = 43200;

    /**
     * Check for outdated & vulnerable WordPress core, plugins, and themes.
     *
     * @param string $scan_id
     * @return Finding[]
     */
    public function scan($scan_id) {
        $findings = [];

        // 1. Check WordPress Core Updates & Core CVEs
        if (!function_exists('get_core_updates')) {
            require_once ABSPATH . 'wp-admin/includes/update.php';
        }

        wp_version_check();
        $core_updates = get_core_updates();
        global $wp_version;

        $core_is_outdated = false;
        $core_latest = $wp_version;

        if (!empty($core_updates) && is_array($core_updates)) {
            $latest = $core_updates[0];
            if (isset($latest->response) && $latest->response === 'upgrade') {
                $core_is_outdated = true;
                $core_latest = $latest->current ?? $wp_version;
            }
        }

        // Query CVEs / Security advisories for installed WordPress core
        $core_cves = self::get_core_cves($wp_version);

        if ($core_is_outdated || !empty($core_cves)) {
            $severity = !empty($core_cves) ? 'critical' : 'high';
            $cve_count = count($core_cves);
            $cve_str = $cve_count > 0 ? " [{$cve_count} Known CVE Reference(s) Found]" : '';
            $desc = $core_is_outdated
                ? "WordPress core is outdated (installed: v{$wp_version}, latest: v{$core_latest}).{$cve_str} Outdated core versions are exposed to publicly documented CVE security exploits."
                : "WordPress core v{$wp_version} has {$cve_count} known CVE security advisories.";

            $evidence_payload = [
                'type'           => 'core',
                'name'           => 'WordPress Core',
                'installed'      => $wp_version,
                'latest'         => $core_latest,
                'is_outdated'    => $core_is_outdated,
                'has_cve'        => !empty($core_cves),
                'cves'           => $core_cves,
                'update_url'     => admin_url('update-core.php')
            ];

            $findings[] = new Finding([
                'engine'       => 'wordpress-updates',
                'type'         => !empty($core_cves) ? 'vulnerable_core' : 'outdated_core',
                'severity'     => $severity,
                'confidence'   => 100,
                'file_path'    => ABSPATH . WPINC . '/version.php',
                'description'  => $desc,
                'evidence'     => wp_json_encode($evidence_payload),
                'code_snippet' => !empty($core_cves) ? 'CVE References: ' . implode(', ', array_column($core_cves, 'cve_id')) : "Current: {$wp_version}, Available: {$core_latest}"
            ]);

            if (!empty($core_cves) && class_exists('\\WebCareProScanner\\Notifications\\NotificationDispatcher')) {
                \WebCareProScanner\Notifications\NotificationDispatcher::trigger('vuln_core_cve_detected', [
                    'severity' => 'critical',
                    /* translators: 1: version number, 2: CVE count */
                    'message'  => sprintf(__('Critical CVE Alert: Installed WordPress core (v%1$s) has %2$d known CVE vulnerability advisory(s).', 'webcare-pro-security'), $wp_version, count($core_cves)),
                    'details'  => [
                        'WordPress Version' => $wp_version,
                        'CVE Count'         => count($core_cves),
                        'Advisories'        => implode(', ', array_slice(array_column($core_cves, 'cve_id'), 0, 4)),
                    ],
                ]);
            }
        }

        // 2. Check Plugin Updates & Vulnerable Plugins
        wp_update_plugins();
        $update_plugins = get_site_transient('update_plugins');

        if (!function_exists('get_plugins')) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }
        $all_plugins = get_plugins();

        foreach ($all_plugins as $plugin_file => $plugin_data) {
            $plugin_name = $plugin_data['Name'] ?? dirname($plugin_file);
            $cur_version = $plugin_data['Version'] ?? '0.0.0';
            $plugin_slug = dirname($plugin_file);
            if ($plugin_slug === '.' || empty($plugin_slug)) {
                $plugin_slug = sanitize_title(basename($plugin_file, '.php'));
            }

            $is_outdated = false;
            $new_version = $cur_version;

            if (!empty($update_plugins->response[$plugin_file])) {
                $is_outdated = true;
                $new_version = $update_plugins->response[$plugin_file]->new_version ?? 'Latest';
            }

            // Check CVEs for this plugin
            $plugin_cves = self::get_plugin_cves($plugin_slug, $cur_version, $plugin_name);

            if ($is_outdated || !empty($plugin_cves)) {
                $severity = !empty($plugin_cves) ? 'critical' : ($is_outdated ? 'medium' : 'low');
                $cve_count = count($plugin_cves);
                $cve_str = $cve_count > 0 ? " [{$cve_count} Known CVE Reference(s)]" : '';

                $desc = $is_outdated
                    ? "Plugin '{$plugin_name}' is outdated (installed: v{$cur_version}, available: v{$new_version}).{$cve_str}"
                    : "Plugin '{$plugin_name}' (v{$cur_version}) has {$cve_count} documented security vulnerability advisory(s).";

                $evidence_payload = [
                    'type'         => 'plugin',
                    'slug'         => $plugin_slug,
                    'file'         => $plugin_file,
                    'name'         => $plugin_name,
                    'installed'    => $cur_version,
                    'latest'       => $new_version,
                    'is_outdated'  => $is_outdated,
                    'has_cve'      => !empty($plugin_cves),
                    'cves'         => $plugin_cves,
                    'update_url'   => admin_url('plugins.php')
                ];

                $findings[] = new Finding([
                    'engine'       => 'wordpress-updates',
                    'type'         => !empty($plugin_cves) ? 'vulnerable_plugin' : 'outdated_plugin',
                    'severity'     => $severity,
                    'confidence'   => 100,
                    'file_path'    => WP_PLUGIN_DIR . '/' . $plugin_file,
                    'description'  => $desc,
                    'evidence'     => wp_json_encode($evidence_payload),
                    'code_snippet' => !empty($plugin_cves) ? 'CVE References: ' . implode(', ', array_column($plugin_cves, 'cve_id')) : "Installed: v{$cur_version}, Latest: v{$new_version}"
                ]);

                if (!empty($plugin_cves) && class_exists('\\WebCareProScanner\\Notifications\\NotificationDispatcher')) {
                    \WebCareProScanner\Notifications\NotificationDispatcher::trigger('vuln_plugin_theme_cve', [
                        'severity' => 'high',
                        /* translators: 1: plugin name, 2: version number, 3: CVE count */
                        'message'  => sprintf(__('Vulnerability Alert: Plugin "%1$s" (v%2$s) has %3$d documented CVE security advisory(s).', 'webcare-pro-security'), $plugin_name, $cur_version, count($plugin_cves)),
                        'details'  => [
                            'Component'   => $plugin_name,
                            'Slug'        => $plugin_slug,
                            'Installed'   => $cur_version,
                            'Advisories'  => implode(', ', array_slice(array_column($plugin_cves, 'cve_id'), 0, 4)),
                        ],
                    ]);
                }
            }
        }

        // 3. Check Theme Updates & Vulnerable Themes
        wp_update_themes();
        $update_themes = get_site_transient('update_themes');

        if (!function_exists('wp_get_themes')) {
            $findings[] = new Finding([
                'engine'       => 'update-scanner',
                'type'         => 'theme_update_check_incomplete',
                'severity'     => 'info',
                'confidence'   => 100,
                'file_path'    => function_exists('get_theme_root') ? get_theme_root() : 'wp-content/themes',
                'description'  => 'Theme update and vulnerability inspection was incomplete: wp_get_themes() core function is unavailable in the current runtime context.',
                'evidence'     => wp_json_encode([
                    'incomplete' => true,
                    'reason'     => 'wp_get_themes_unavailable',
                ]),
                'code_snippet' => 'Status: Incomplete (wp_get_themes unavailable)',
            ]);
            $all_themes = [];
        } else {
            $all_themes = wp_get_themes();
        }

        foreach ($all_themes as $theme_slug => $theme_obj) {
            $theme_name = $theme_obj->get('Name') ?: $theme_slug;
            $cur_version = $theme_obj->get('Version') ?: '0.0.0';

            $is_outdated = false;
            $new_version = $cur_version;

            if (!empty($update_themes->response[$theme_slug])) {
                $is_outdated = true;
                $new_version = $update_themes->response[$theme_slug]['new_version'] ?? 'Latest';
            }

            // Check CVEs for this theme
            $theme_cves = self::get_theme_cves($theme_slug, $cur_version, $theme_name);

            if ($is_outdated || !empty($theme_cves)) {
                $severity = !empty($theme_cves) ? 'critical' : ($is_outdated ? 'medium' : 'low');
                $cve_count = count($theme_cves);
                $cve_str = $cve_count > 0 ? " [{$cve_count} Known CVE Reference(s)]" : '';

                $desc = $is_outdated
                    ? "Theme '{$theme_name}' is outdated (installed: v{$cur_version}, available: v{$new_version}).{$cve_str}"
                    : "Theme '{$theme_name}' (v{$cur_version}) has {$cve_count} documented security vulnerability advisory(s).";

                $evidence_payload = [
                    'type'         => 'theme',
                    'slug'         => $theme_slug,
                    'name'         => $theme_name,
                    'installed'    => $cur_version,
                    'latest'       => $new_version,
                    'is_outdated'  => $is_outdated,
                    'has_cve'      => !empty($theme_cves),
                    'cves'         => $theme_cves,
                    'update_url'   => admin_url('themes.php')
                ];

                $findings[] = new Finding([
                    'engine'       => 'wordpress-updates',
                    'type'         => !empty($theme_cves) ? 'vulnerable_theme' : 'outdated_theme',
                    'severity'     => $severity,
                    'confidence'   => 100,
                    'file_path'    => get_theme_root() . "/{$theme_slug}",
                    'description'  => $desc,
                    'evidence'     => wp_json_encode($evidence_payload),
                    'code_snippet' => !empty($theme_cves) ? 'CVE References: ' . implode(', ', array_column($theme_cves, 'cve_id')) : "Installed: v{$cur_version}, Latest: v{$new_version}"
                ]);

                if (!empty($theme_cves) && class_exists('\\WebCareProScanner\\Notifications\\NotificationDispatcher')) {
                    \WebCareProScanner\Notifications\NotificationDispatcher::trigger('vuln_plugin_theme_cve', [
                        'severity' => 'high',
                        /* translators: 1: theme name, 2: version number, 3: CVE count */
                        'message'  => sprintf(__('Vulnerability Alert: Theme "%1$s" (v%2$s) has %3$d documented CVE security advisory(s).', 'webcare-pro-security'), $theme_name, $cur_version, count($theme_cves)),
                        'details'  => [
                            'Component'   => $theme_name,
                            'Slug'        => $theme_slug,
                            'Installed'   => $cur_version,
                            'Advisories'  => implode(', ', array_slice(array_column($theme_cves, 'cve_id'), 0, 4)),
                        ],
                    ]);
                }
            }
        }

        return $findings;
    }

    /**
     * Retrieve complete audit report of WordPress Core, Plugins, and Themes
     * with detailed update status, version comparisons, and full CVE reference advisories.
     *
     * @return array
     */
    public static function get_detailed_report() {
        global $wp_version;

        if (!function_exists('get_core_updates')) {
            require_once ABSPATH . 'wp-admin/includes/update.php';
        }
        if (!function_exists('get_plugins')) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }

        wp_version_check();
        wp_update_plugins();
        wp_update_themes();

        $core_updates = get_core_updates();
        $update_plugins = get_site_transient('update_plugins');
        $update_themes = get_site_transient('update_themes');

        // 1. Core Audit
        $core_is_outdated = false;
        $core_latest = $wp_version;
        if (!empty($core_updates) && is_array($core_updates)) {
            $latest = $core_updates[0];
            if (isset($latest->response) && $latest->response === 'upgrade') {
                $core_is_outdated = true;
                $core_latest = $latest->current ?? $wp_version;
            }
        }
        $core_cves = self::get_core_cves($wp_version);

        $core_data = [
            'name'              => 'WordPress Core',
            'type'              => 'core',
            'installed_version' => $wp_version,
            'latest_version'    => $core_latest,
            'is_outdated'       => $core_is_outdated,
            'has_cve'           => !empty($core_cves),
            'cves'              => $core_cves,
            'cve_count'         => count($core_cves),
            'max_cvss'          => !empty($core_cves) ? max(array_column($core_cves, 'cvss')) : 0,
            'update_url'        => admin_url('update-core.php'),
            'status'            => !empty($core_cves) ? 'vulnerable' : ($core_is_outdated ? 'outdated' : 'secure')
        ];

        // 2. Plugins Audit
        $all_plugins = get_plugins();
        $active_plugins = (array) get_option('active_plugins', []);
        $plugins_data = [];

        foreach ($all_plugins as $plugin_file => $plugin_data) {
            $plugin_name = $plugin_data['Name'] ?? dirname($plugin_file);
            $cur_version = $plugin_data['Version'] ?? '0.0.0';
            $author = $plugin_data['Author'] ?? ($plugin_data['AuthorName'] ?? '');
            $plugin_slug = dirname($plugin_file);
            if ($plugin_slug === '.' || empty($plugin_slug)) {
                $plugin_slug = sanitize_title(basename($plugin_file, '.php'));
            }

            $is_outdated = false;
            $new_version = $cur_version;
            $package_url = '';

            if (!empty($update_plugins->response[$plugin_file])) {
                $is_outdated = true;
                $new_version = $update_plugins->response[$plugin_file]->new_version ?? 'Latest';
                $package_url = $update_plugins->response[$plugin_file]->package ?? '';
            }

            $plugin_cves = self::get_plugin_cves($plugin_slug, $cur_version, $plugin_name);
            $is_active = in_array($plugin_file, $active_plugins, true);

            // Determine if official WP.org plugin or custom/premium
            $is_official = false;
            $unknown_files = [];

            // Check if plugin is abandoned or closed in WP.org repository
            $is_abandoned = false;
            if (!empty($update_plugins->response[$plugin_file]) && empty($update_plugins->response[$plugin_file]->package)) {
                $is_abandoned = true;
                if (class_exists('\\WebCareProScanner\\Notifications\\NotificationDispatcher')) {
                    \WebCareProScanner\Notifications\NotificationDispatcher::trigger('vuln_abandoned_extension', [
                        'severity' => 'warning',
                        /* translators: %s: plugin name */
                        'message'  => sprintf(__('Plugin "%s" appears to be abandoned, closed, or removed from the official WordPress directory.', 'webcare-pro-security'), $plugin_name),
                        'details'  => [
                            'Plugin Name' => $plugin_name,
                            'Plugin Slug' => $plugin_slug,
                            'Status'      => 'Closed / No Package Available',
                        ],
                    ]);
                }
            }

            // 1. Check WP.org transient response / update feed
            if (!empty($update_plugins->response[$plugin_file]) || !empty($update_plugins->no_update[$plugin_file])) {
                $is_official = true;
            }

            // 2. Query checksum provider for official release manifest
            $checksum_provider = new \WebCareProScanner\Integrity\ChecksumProvider();
            $checksums = $checksum_provider->get_plugin_checksums($plugin_slug, $cur_version);
            if ($checksums !== null) {
                $is_official = true;

                // Inspect directory for unrecognized/foreign files
                $plugin_dir = WP_PLUGIN_DIR . '/' . $plugin_slug;
                if (is_dir($plugin_dir)) {
                    $ignored_basenames = ['.htaccess', 'web.config', 'error_log', '.ds_store', 'thumbs.db'];
                    try {
                        $iterator = new \RecursiveIteratorIterator(
                            new \RecursiveDirectoryIterator($plugin_dir, \RecursiveDirectoryIterator::SKIP_DOTS),
                            \RecursiveIteratorIterator::SELF_FIRST
                        );
                        $normalized_plugin_dir = str_replace('\\', '/', rtrim($plugin_dir, '/\\') . '/');

                        foreach ($iterator as $file_item) {
                            if (!$file_item->isFile()) continue;
                            $real_path = $file_item->getPathname();
                            $normalized_path = str_replace('\\', '/', $real_path);
                            $rel_file = str_replace($normalized_plugin_dir, '', $normalized_path);
                            $filename = strtolower($file_item->getBasename());

                            if (in_array($filename, $ignored_basenames, true)) continue;

                            if (!isset($checksums[$rel_file])) {
                                $ext = strtolower($file_item->getExtension());
                                $is_executable = in_array($ext, ['php', 'phtml', 'php5', 'php7', 'phar', 'inc', 'cgi', 'sh', 'pl'], true);
                                $unknown_files[] = [
                                    'file'          => $rel_file,
                                    'full_path'     => $real_path,
                                    'size'          => $file_item->getSize(),
                                    'is_executable' => $is_executable
                                ];
                                if (count($unknown_files) >= 20) break; // Cap to first 20 unknown files
                            }
                        }
                    } catch (\Exception $e) {}
                }
            }

            $origin = $is_official ? 'official' : 'premium_custom';

            $plugins_data[] = [
                'name'              => $plugin_name,
                'slug'              => $plugin_slug,
                'file'              => $plugin_file,
                'author'            => wp_strip_all_tags($author),
                'plugin_uri'        => $plugin_data['PluginURI'] ?? '',
                'is_active'         => $is_active,
                'type'              => 'plugin',
                'origin'            => $origin, // 'official' | 'premium_custom'
                'is_official'       => $is_official,
                'unknown_files'     => $unknown_files,
                'unknown_count'     => count($unknown_files),
                'installed_version' => $cur_version,
                'latest_version'    => $new_version,
                'is_outdated'       => $is_outdated,
                'has_cve'           => !empty($plugin_cves),
                'cves'              => $plugin_cves,
                'cve_count'         => count($plugin_cves),
                'max_cvss'          => !empty($plugin_cves) ? max(array_column($plugin_cves, 'cvss')) : 0,
                'update_url'        => admin_url('plugins.php'),
                'package_url'       => $package_url,
                'status'            => !empty($plugin_cves) ? 'vulnerable' : ($is_outdated ? 'outdated' : 'secure')
            ];
        }

        // 3. Themes Audit
        $has_theme_api = function_exists('wp_get_themes');
        $all_themes = $has_theme_api ? wp_get_themes() : [];
        $current_theme_slug = function_exists('get_stylesheet') ? get_stylesheet() : '';
        $themes_data = [];

        foreach ($all_themes as $theme_slug => $theme_obj) {
            $theme_name = $theme_obj->get('Name') ?: $theme_slug;
            $cur_version = $theme_obj->get('Version') ?: '0.0.0';
            $author = $theme_obj->get('Author') ?: '';
            $theme_uri = $theme_obj->get('ThemeURI') ?: '';

            $is_outdated = false;
            $new_version = $cur_version;

            if (!empty($update_themes->response[$theme_slug])) {
                $is_outdated = true;
                $new_version = $update_themes->response[$theme_slug]['new_version'] ?? 'Latest';
            }

            $theme_cves = self::get_theme_cves($theme_slug, $cur_version, $theme_name);
            $is_active = ($theme_slug === $current_theme_slug);

            // Determine if official WP.org theme or custom/premium
            $is_official = false;
            $unknown_files = [];

            if (!empty($update_themes->response[$theme_slug])) {
                $is_official = true;
            }

            // Check if bundled default theme or official WP.org theme
            $checksum_provider = new \WebCareProScanner\Integrity\ChecksumProvider();
            $theme_checksums = $checksum_provider->get_theme_checksums($theme_slug, $cur_version);
            if ($theme_checksums !== null) {
                $is_official = true;

                $theme_dir = $theme_obj->get_stylesheet_directory();
                if (is_dir($theme_dir)) {
                    $ignored_basenames = ['.htaccess', 'web.config', 'error_log', '.ds_store', 'thumbs.db'];
                    try {
                        $iterator = new \RecursiveIteratorIterator(
                            new \RecursiveDirectoryIterator($theme_dir, \RecursiveDirectoryIterator::SKIP_DOTS),
                            \RecursiveIteratorIterator::SELF_FIRST
                        );
                        $normalized_theme_dir = str_replace('\\', '/', rtrim($theme_dir, '/\\') . '/');

                        foreach ($iterator as $file_item) {
                            if (!$file_item->isFile()) continue;
                            $real_path = $file_item->getPathname();
                            $normalized_path = str_replace('\\', '/', $real_path);
                            $rel_file = str_replace($normalized_theme_dir, '', $normalized_path);
                            $filename = strtolower($file_item->getBasename());

                            if (in_array($filename, $ignored_basenames, true)) continue;

                            if (!isset($theme_checksums[$rel_file])) {
                                $ext = strtolower($file_item->getExtension());
                                $is_executable = in_array($ext, ['php', 'phtml', 'php5', 'php7', 'phar', 'inc', 'cgi', 'sh', 'pl'], true);
                                $unknown_files[] = [
                                    'file'          => $rel_file,
                                    'full_path'     => $real_path,
                                    'size'          => $file_item->getSize(),
                                    'is_executable' => $is_executable
                                ];
                                if (count($unknown_files) >= 20) break;
                            }
                        }
                    } catch (\Exception $e) {}
                }
            }

            $origin = $is_official ? 'official' : 'premium_custom';

            $themes_data[] = [
                'name'              => $theme_name,
                'slug'              => $theme_slug,
                'author'            => wp_strip_all_tags($author),
                'theme_uri'         => $theme_uri,
                'is_active'         => $is_active,
                'type'              => 'theme',
                'origin'            => $origin, // 'official' | 'premium_custom'
                'is_official'       => $is_official,
                'unknown_files'     => $unknown_files,
                'unknown_count'     => count($unknown_files),
                'installed_version' => $cur_version,
                'latest_version'    => $new_version,
                'is_outdated'       => $is_outdated,
                'has_cve'           => !empty($theme_cves),
                'cves'              => $theme_cves,
                'cve_count'         => count($theme_cves),
                'max_cvss'          => !empty($theme_cves) ? max(array_column($theme_cves, 'cvss')) : 0,
                'update_url'        => admin_url('themes.php'),
                'status'            => !empty($theme_cves) ? 'vulnerable' : ($is_outdated ? 'outdated' : 'secure')
            ];
        }

        // 4. Must-Use (MU) Plugins Audit
        $mu_plugins_data = [];
        if (!function_exists('get_mu_plugins')) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }
        $all_mu_plugins = function_exists('get_mu_plugins') ? get_mu_plugins() : [];
        foreach ($all_mu_plugins as $mu_file => $mu_data) {
            $mu_name = $mu_data['Name'] ?? basename($mu_file);
            $mu_version = $mu_data['Version'] ?? '0.0.0';
            $mu_slug = basename($mu_file, '.php');

            $mu_cves = self::get_plugin_cves($mu_slug, $mu_version, $mu_name);
            $mu_plugins_data[] = [
                'name'              => $mu_name,
                'slug'              => $mu_slug,
                'file'              => $mu_file,
                'is_active'         => true,
                'type'              => 'mu-plugin',
                'origin'            => 'mu-plugin',
                'is_official'       => false,
                'installed_version' => $mu_version,
                'latest_version'    => $mu_version,
                'is_outdated'       => false,
                'has_cve'           => !empty($mu_cves),
                'cves'              => $mu_cves,
                'cve_count'         => count($mu_cves),
                'status'            => !empty($mu_cves) ? 'vulnerable' : 'secure',
            ];
        }

        // 5. Drop-ins Audit
        $dropins_data = [];
        $all_dropins = function_exists('get_dropins') ? get_dropins() : [];
        foreach ($all_dropins as $dropin_file => $dropin_data) {
            $dropin_name = $dropin_data['Name'] ?? basename($dropin_file);
            $dropin_slug = basename($dropin_file, '.php');
            $dropins_data[] = [
                'name'              => $dropin_name,
                'slug'              => $dropin_slug,
                'file'              => $dropin_file,
                'is_active'         => true,
                'type'              => 'dropin',
                'origin'            => 'dropin',
                'is_official'       => false,
                'installed_version' => '1.0.0',
                'latest_version'    => '1.0.0',
                'is_outdated'       => false,
                'has_cve'           => false,
                'cves'              => [],
                'cve_count'         => 0,
                'status'            => 'unknown',
            ];
        }

        // Summary calculations
        $total_items = 1 + count($plugins_data) + count($themes_data) + count($mu_plugins_data) + count($dropins_data);
        $all_items = array_merge([$core_data], $plugins_data, $themes_data, $mu_plugins_data, $dropins_data);

        $outdated_count = count(array_filter($all_items, function($item) {
            return !empty($item['is_outdated']);
        }));

        $vulnerable_count = count(array_filter($all_items, function($item) {
            return !empty($item['has_cve']);
        }));

        $total_cves = array_sum(array_map(function($item) {
            return $item['cve_count'] ?? 0;
        }, $all_items));

        $official_count = count(array_filter($all_items, function($item) {
            return ($item['type'] === 'core') || (!empty($item['is_official']));
        }));

        $premium_count = $total_items - $official_count;

        $items_with_unknown_files = count(array_filter($all_items, function($item) {
            return !empty($item['unknown_count']) && $item['unknown_count'] > 0;
        }));

        $total_unknown_files = array_sum(array_map(function($item) {
            return $item['unknown_count'] ?? 0;
        }, $all_items));

        return [
            'summary' => [
                'total_components'         => $total_items,
                'outdated_count'           => $outdated_count,
                'vulnerable_count'         => $vulnerable_count,
                'total_cves'               => $total_cves,
                'official_count'           => $official_count,
                'premium_count'            => $premium_count,
                'items_with_unknown_files' => $items_with_unknown_files,
                'total_unknown_files'      => $total_unknown_files,
                'secure_count'             => $total_items - count(array_filter($all_items, function($item) {
                    return $item['is_outdated'] || $item['has_cve'];
                })),
                'themes_inspection_incomplete' => !$has_theme_api,
                'timestamp'                => current_time('mysql'),
            ],
            'core'       => $core_data,
            'plugins'    => $plugins_data,
            'themes'     => $themes_data,
            'mu_plugins' => $mu_plugins_data,
            'dropins'    => $dropins_data,
        ];
    }

    /**
     * Retrieve known CVEs for WordPress core.
     *
     * @param string $version
     * @return array
     */
    public static function get_core_cves($version) {
        $version = (string) ($version ?? '0.0.0');
        $cache_key = 'webcareproscan_cve_core_' . sanitize_key($version);
        $cached = get_transient($cache_key);
        if ($cached !== false && is_array($cached)) {
            return $cached;
        }

        $cves = [];
        $known_core_db = self::get_known_core_vulnerabilities();

        foreach ($known_core_db as $item) {
            if (self::is_version_affected($version, $item['affected_versions'])) {
                $cves[] = [
                    'cve_id'      => $item['cve_id'],
                    'title'       => $item['title'],
                    'severity'    => $item['severity'],
                    'cvss'        => $item['cvss'],
                    'fixed_in'    => $item['fixed_in'],
                    'reference'   => "https://nvd.nist.gov/vuln/detail/{$item['cve_id']}",
                    'cve_details' => $item['description']
                ];
            }
        }

        set_transient($cache_key, $cves, self::CACHE_TTL);
        return $cves;
    }

    /**
     * Retrieve known CVEs for a WordPress plugin.
     *
     * @param string $slug
     * @param string $version
     * @param string $name
     * @return array
     */
    public static function get_plugin_cves($slug, $version, $name = '') {
        $cache_key = 'webcareproscan_cve_plugin_' . sanitize_key($slug . '_' . $version);
        $cached = get_transient($cache_key);
        if ($cached !== false && is_array($cached)) {
            return $cached;
        }

        $cves = [];
        $known_plugin_db = self::get_known_plugin_vulnerabilities();

        if (isset($known_plugin_db[$slug])) {
            foreach ($known_plugin_db[$slug] as $item) {
                if (self::is_version_affected($version, $item['affected_versions'])) {
                    $cves[] = [
                        'cve_id'      => $item['cve_id'],
                        'title'       => $item['title'],
                        'severity'    => $item['severity'],
                        'cvss'        => $item['cvss'],
                        'fixed_in'    => $item['fixed_in'],
                        'reference'   => "https://nvd.nist.gov/vuln/detail/{$item['cve_id']}",
                        'cve_details' => $item['description']
                    ];
                }
            }
        }

        self::merge_threat_intel_cves($cves, (string) $slug, (string) $version);
        self::merge_nist_vault_cves($cves, (string) $slug, (string) $version);
        self::merge_wpvulnerability_cves($cves, 'plugin', (string) $slug, (string) $version);

        set_transient($cache_key, $cves, self::CACHE_TTL);
        return $cves;
    }

    /**
     * Retrieve known CVEs for a WordPress theme.
     *
     * @param string $slug
     * @param string $version
     * @param string $name
     * @return array
     */
    public static function get_theme_cves($slug, $version, $name = '') {
        $cache_key = 'webcareproscan_cve_theme_' . sanitize_key($slug . '_' . $version);
        $cached = get_transient($cache_key);
        if ($cached !== false && is_array($cached)) {
            return $cached;
        }

        $cves = [];
        $known_theme_db = self::get_known_theme_vulnerabilities();

        if (isset($known_theme_db[$slug])) {
            foreach ($known_theme_db[$slug] as $item) {
                if (self::is_version_affected($version, $item['affected_versions'])) {
                    $cves[] = [
                        'cve_id'      => $item['cve_id'],
                        'title'       => $item['title'],
                        'severity'    => $item['severity'],
                        'cvss'        => $item['cvss'],
                        'fixed_in'    => $item['fixed_in'],
                        'reference'   => "https://nvd.nist.gov/vuln/detail/{$item['cve_id']}",
                        'cve_details' => $item['description']
                    ];
                }
            }
        }

        self::merge_threat_intel_cves($cves, (string) $slug, (string) $version);
        self::merge_nist_vault_cves($cves, (string) $slug, (string) $version);
        self::merge_wpvulnerability_cves($cves, 'plugin', (string) $slug, (string) $version);

        set_transient($cache_key, $cves, self::CACHE_TTL);
        return $cves;
    }

    /**
     * Merge cached NIST NVD advisories from the encrypted NistCveVaultSync store.
     */
    private static function merge_nist_vault_cves(array &$cves, string $slug, string $version): void {
        if ($slug === '' || $version === '' || !class_exists('\\WebCareProScanner\\Firewall\\NistCveVaultSync')) {
            return;
        }
        $nist_cves = \WebCareProScanner\Firewall\NistCveVaultSync::get_component_cves($slug, $version);
        if (empty($nist_cves)) {
            return;
        }
        $seen = [];
        foreach ($cves as $existing) {
            if (!empty($existing['cve_id'])) {
                $seen[strtoupper((string) $existing['cve_id'])] = true;
            }
        }
        foreach ($nist_cves as $item) {
            $id = strtoupper((string) ($item['cve_id'] ?? ''));
            if ($id !== '' && !isset($seen[$id])) {
                $seen[$id] = true;
                $cves[] = $item;
            }
        }
    }

    /**
     * Query the free WPVulnerability.net API for real-time CVEs affecting an installed plugin/theme,
     * cached per slug+version so repeated page loads are instant.
     *
     * @param array  $cves
     * @param string $type 'plugin' or 'theme'
     * @param string $slug
     * @param string $version
     */
    private static function merge_wpvulnerability_cves(array &$cves, string $type, string $slug, string $version): void {
        if ($slug === '' || $version === '' || (defined('WEBCAREPROSCAN_TESTING') && WEBCAREPROSCAN_TESTING)) {
            return;
        }
        if (!function_exists('wp_remote_get')) {
            return;
        }

        $endpoint = sprintf(
            'https://www.wpvulnerability.net/%s/%s/',
            $type === 'theme' ? 'theme' : 'plugin',
            rawurlencode(strtolower($slug))
        );

        $res = wp_remote_get($endpoint, [
            'timeout'    => 4,
            'user-agent' => 'WEBCARE-CVE-Audit/' . (defined('WEBCAREPROSCAN_VERSION') ? WEBCAREPROSCAN_VERSION : '1.0'),
        ]);
        if (is_wp_error($res) || wp_remote_retrieve_response_code($res) !== 200) {
            return;
        }

        $body = json_decode(wp_remote_retrieve_body($res), true);
        $vulns = $body['data']['vulnerability'] ?? [];
        if (!is_array($vulns) || empty($vulns)) {
            return;
        }

        $seen = [];
        foreach ($cves as $existing) {
            if (!empty($existing['cve_id'])) {
                $seen[strtoupper((string) $existing['cve_id'])] = true;
            }
        }

        foreach ($vulns as $v) {
            if (!is_array($v)) {
                continue;
            }
            $op = $v['operator'] ?? [];
            $min_ver = (string) ($op['min_version'] ?? '');
            $max_ver = (string) ($op['max_version'] ?? '');
            $min_op  = (string) ($op['min_operator'] ?? 'ge');
            $max_op  = (string) ($op['max_operator'] ?? 'lt');

            if ($min_ver !== '' && !version_compare($version, $min_ver, $min_op === 'gt' ? '>' : '>=')) {
                continue;
            }
            if ($max_ver !== '' && !version_compare($version, $max_ver, $max_op === 'le' ? '<=' : '<')) {
                continue;
            }
            if ($min_ver === '' && $max_ver === '') {
                continue;
            }

            $cve_id = '';
            $cvss = 7.5;
            if (!empty($v['source']) && is_array($v['source'])) {
                foreach ($v['source'] as $src) {
                    if (!empty($src['id']) && str_starts_with(strtoupper((string) $src['id']), 'CVE-')) {
                        $cve_id = strtoupper((string) $src['id']);
                        break;
                    }
                }
            }
            if ($cve_id === '' || isset($seen[$cve_id])) {
                continue;
            }
            if (!empty($v['impact']['cvss']['score'])) {
                $cvss = (float) $v['impact']['cvss']['score'];
            }

            $severity = $cvss >= 9.0 ? 'critical' : ($cvss >= 7.0 ? 'high' : ($cvss >= 4.0 ? 'medium' : 'low'));
            $fixed_in = $max_ver !== '' ? $max_ver : 'Latest';
            $seen[$cve_id] = true;

            $cves[] = [
                'cve_id'      => $cve_id,
                'title'       => (string) ($v['name'] ?? $cve_id),
                'severity'    => $severity,
                'cvss'        => $cvss,
                'fixed_in'    => $fixed_in,
                'reference'   => "https://nvd.nist.gov/vuln/detail/{$cve_id}",
                'cve_details' => (string) ($v['impact']['cwe'][0]['description'] ?? ($v['name'] ?? '')),
            ];
        }
    }

    /**
     * Merge matching advisories from the synced NVD CVE 2.0 / CISA KEV ThreatIntelService catalog.
     *
     * @param array  $cves
     * @param string $slug
     * @param string $version
     */
    private static function merge_threat_intel_cves(array &$cves, string $slug, string $version): void {
        if ($slug === '' || $version === '' || !class_exists('\\WebCareProScanner\\Firewall\\ThreatIntelService')) {
            return;
        }

        $catalog = get_option(\WebCareProScanner\Firewall\ThreatIntelService::OPTION_CVES, []);
        if (empty($catalog) || !is_array($catalog)) {
            $catalog = \WebCareProScanner\Firewall\ThreatIntelService::get_seed_cves();
        }
        if (empty($catalog) || !is_array($catalog)) {
            return;
        }

        $seen = [];
        foreach ($cves as $existing) {
            if (!empty($existing['cve_id'])) {
                $seen[strtoupper((string) $existing['cve_id'])] = true;
            }
        }

        $norm_slug = strtolower($slug);
        if (class_exists('\\WebCareProScanner\\Firewall\\CVEIntelligenceService')) {
            $norm_slug = strtolower(\WebCareProScanner\Firewall\CVEIntelligenceService::resolve_canonical_slug($norm_slug));
        }

        foreach ($catalog as $entry) {
            if (!is_array($entry)) {
                continue;
            }
            $cve_id = strtoupper(trim((string) ($entry['cve_id'] ?? ($entry['id'] ?? ''))));
            $target = strtolower(trim((string) ($entry['target'] ?? '')));
            if ($cve_id === '' || $target === '' || isset($seen[$cve_id])) {
                continue;
            }

            if ($target !== $norm_slug && $target !== strtolower($slug)) {
                continue;
            }

            $fixed_in = trim((string) ($entry['fixed_in'] ?? ''));
            if ($fixed_in !== '' && $fixed_in !== '0.0.0' && version_compare($version, $fixed_in, '<')) {
                $seen[$cve_id] = true;
                $cves[] = [
                    'cve_id'      => $cve_id,
                    'title'       => (string) ($entry['title'] ?? $cve_id),
                    'severity'    => strtolower((string) ($entry['severity'] ?? 'high')),
                    'cvss'        => (float) ($entry['cvss'] ?? 7.5),
                    'fixed_in'    => $fixed_in,
                    'reference'   => "https://nvd.nist.gov/vuln/detail/{$cve_id}",
                    'cve_details' => (string) ($entry['description'] ?? ''),
                ];
            }
        }
    }

    /**
     * Determine if a version is within an affected semver range.
     *
     * @param string $version
     * @param string $range  e.g. "< 6.5.5", "<= 2.1.0", "< 6.0"
     * @return bool
     */
    public static function is_version_affected($version, $range) {
        if (empty($version) || empty($range)) {
            return false;
        }

        // Clean version strings (e.g. 'v6.4.2' -> '6.4.2', '6.4-beta' -> '6.4')
        $clean_version = ltrim(preg_replace('/[^0-9.]/', '', $version), '.');
        if (empty($clean_version)) {
            return false;
        }

        $parts = explode(' ', trim($range));
        if (count($parts) === 2) {
            $operator = $parts[0];
            $target_ver = $parts[1];
            return version_compare($clean_version, $target_ver, $operator);
        }

        return false;
    }

    /**
     * Curated, high-impact database of known WordPress Core CVE advisories.
     */
    public static function get_known_core_vulnerabilities() {
        return [
            [
                'cve_id'            => 'CVE-2024-4439',
                'title'             => 'WordPress Core - Stored Cross-Site Scripting via Avatar & Comments',
                'severity'          => 'high',
                'cvss'              => 7.2,
                'affected_versions' => '< 6.5.5',
                'fixed_in'          => '6.5.5',
                'description'       => 'Stored XSS vulnerability in WordPress Core via wp-includes avatar handling allowing unauthenticated or low-privilege script execution.'
            ],
            [
                'cve_id'            => 'CVE-2024-4440',
                'title'             => 'WordPress Core - Path Traversal via Template Loader',
                'severity'          => 'high',
                'cvss'              => 7.5,
                'affected_versions' => '< 6.5.5',
                'fixed_in'          => '6.5.5',
                'description'       => 'Path traversal in template resolution allowing unauthorized inclusion and execution of local files.'
            ],
            [
                'cve_id'            => 'CVE-2023-39999',
                'title'             => 'WordPress Core - User Enumeration & Directory Traversal in WP_Query',
                'severity'          => 'medium',
                'cvss'              => 6.5,
                'affected_versions' => '< 6.3.2',
                'fixed_in'          => '6.3.2',
                'description'       => 'Improper input validation in WP_Query parameter parsing enabling unauthenticated user information disclosure.'
            ],
            [
                'cve_id'            => 'CVE-2023-2745',
                'title'             => 'WordPress Core - Directory Traversal via wp_lang Parameter',
                'severity'          => 'high',
                'cvss'              => 7.5,
                'affected_versions' => '< 6.2.1',
                'fixed_in'          => '6.2.1',
                'description'       => 'Directory traversal vulnerability via translation loading mechanism on localized installations.'
            ],
            [
                'cve_id'            => 'CVE-2022-43497',
                'title'             => 'WordPress Core - Object Injection Vulnerability',
                'severity'          => 'critical',
                'cvss'              => 9.8,
                'affected_versions' => '< 6.0.3',
                'fixed_in'          => '6.0.3',
                'description'       => 'Critical PHP object injection vulnerability in core serialized data processing allowing remote code execution.'
            ],
            [
                'cve_id'            => 'CVE-2022-3590',
                'title'             => 'WordPress Core - Unauthenticated Blind SSRF via Pingback',
                'severity'          => 'high',
                'cvss'              => 7.5,
                'affected_versions' => '< 6.1.1',
                'fixed_in'          => '6.1.1',
                'description'       => 'Server-Side Request Forgery vulnerability in XML-RPC pingback mechanism targeting internal network assets.'
            ],
            [
                'cve_id'            => 'CVE-2022-21661',
                'title'             => 'WordPress Core - SQL Injection via WP_Query Tax Query',
                'severity'          => 'high',
                'cvss'              => 8.0,
                'affected_versions' => '< 5.8.3',
                'fixed_in'          => '5.8.3',
                'description'       => 'High severity SQL injection flaw in taxonomy query sanitation affecting plugins utilizing custom query structures.'
            ],
            [
                'cve_id'            => 'CVE-2020-28037',
                'title'             => 'WordPress Core - Verification Bypass in is_blog_installed()',
                'severity'          => 'high',
                'cvss'              => 7.5,
                'affected_versions' => '< 5.5.2',
                'fixed_in'          => '5.5.2',
                'description'       => 'State checking logic flaw permitting partial setup execution and information leakage on misconfigured environments.'
            ]
        ];
    }

    /**
     * Curated, high-impact database of known popular WordPress Plugin CVE advisories.
     */
    public static function get_known_plugin_vulnerabilities() {
        return [
            'elementor' => [
                [
                    'cve_id'            => 'CVE-2023-48777',
                    'title'             => 'Elementor Website Builder - Remote Code Execution via File Upload',
                    'severity'          => 'critical',
                    'cvss'              => 9.8,
                    'affected_versions' => '< 3.18.2',
                    'fixed_in'          => '3.18.2',
                    'description'       => 'Arbitrary file upload flaw in template asset handler allowing unauthenticated attackers to execute arbitrary PHP code.'
                ],
                [
                    'cve_id'            => 'CVE-2022-1329',
                    'title'             => 'Elementor - Broken Access Control to Remote Code Execution',
                    'severity'          => 'critical',
                    'cvss'              => 9.9,
                    'affected_versions' => '< 3.6.3',
                    'fixed_in'          => '3.6.3',
                    'description'       => 'Missing permission validation on AJAX handlers allowing subscriber-level accounts to upload rogue plugin modules.'
                ]
            ],
            'woocommerce-payments' => [
                [
                    'cve_id'            => 'CVE-2023-28121',
                    'title'             => 'WooCommerce Payments - Unauthenticated Privilege Escalation',
                    'severity'          => 'critical',
                    'cvss'              => 9.8,
                    'affected_versions' => '< 5.6.2',
                    'fixed_in'          => '5.6.2',
                    'description'       => 'Authentication bypass in payment request header parsing enabling attackers to impersonate shop administrators.'
                ]
            ],
            'woocommerce' => [
                [
                    'cve_id'            => 'CVE-2021-32640',
                    'title'             => 'WooCommerce - SQL Injection in Order Queries',
                    'severity'          => 'critical',
                    'cvss'              => 9.8,
                    'affected_versions' => '< 5.5.1',
                    'fixed_in'          => '5.5.1',
                    'description'       => 'Unauthenticated SQL injection in internal WooCommerce data store lookup functions.'
                ]
            ],
            'contact-form-7' => [
                [
                    'cve_id'            => 'CVE-2020-35489',
                    'title'             => 'Contact Form 7 - Unrestricted File Upload Remote Code Execution',
                    'severity'          => 'critical',
                    'cvss'              => 9.8,
                    'affected_versions' => '< 5.3.2',
                    'fixed_in'          => '5.3.2',
                    'description'       => 'Double extension and special character sanitization failure in form upload handling allowing PHP upload execution.'
                ]
            ],
            'wpforms-lite' => [
                [
                    'cve_id'            => 'CVE-2022-2615',
                    'title'             => 'WPForms - Stored Cross-Site Scripting via Form Fields',
                    'severity'          => 'medium',
                    'cvss'              => 6.4,
                    'affected_versions' => '< 1.7.5.5',
                    'fixed_in'          => '1.7.5.5',
                    'description'       => 'Insufficient output escaping on submitted form values permitting stored cross-site scripting in administration dashboard.'
                ]
            ],
            'all-in-one-seo-pack' => [
                [
                    'cve_id'            => 'CVE-2021-4367',
                    'title'             => 'All in One SEO - Authenticated SQL Injection & Privilege Escalation',
                    'severity'          => 'critical',
                    'cvss'              => 9.9,
                    'affected_versions' => '< 4.1.5.3',
                    'fixed_in'          => '4.1.5.3',
                    'description'       => 'REST API route parameter validation flaw allowing low-privilege users to execute arbitrary SQL commands.'
                ]
            ],
            'wordfence' => [
                [
                    'cve_id'            => 'CVE-2023-38035',
                    'title'             => 'Wordfence Security - 2FA Bypass Vulnerability',
                    'severity'          => 'high',
                    'cvss'              => 7.5,
                    'affected_versions' => '< 7.10.3',
                    'fixed_in'          => '7.10.3',
                    'description'       => 'Timing attack flaw and token verification race condition in Wordfence two-factor authentication endpoint.'
                ]
            ],
            'updraftplus' => [
                [
                    'cve_id'            => 'CVE-2022-0633',
                    'title'             => 'UpdraftPlus - Unauthenticated Sensitive Backup Download',
                    'severity'          => 'high',
                    'cvss'              => 8.5,
                    'affected_versions' => '< 1.22.3',
                    'fixed_in'          => '1.22.3',
                    'description'       => 'Heartbeat check failure enabling logged-in subscriber accounts to request and download full site and database backups.'
                ]
            ],
            'litespeed-cache' => [
                [
                    'cve_id'            => 'CVE-2024-28000',
                    'title'             => 'LiteSpeed Cache - Unauthenticated Privilege Escalation to Administrator',
                    'severity'          => 'critical',
                    'cvss'              => 9.8,
                    'affected_versions' => '< 6.4',
                    'fixed_in'          => '6.4',
                    'description'       => 'Weak cryptographic security hash generation in REST API role simulation allowing unauthenticated administrative takeover.'
                ],
                [
                    'cve_id'            => 'CVE-2024-44000',
                    'title'             => 'LiteSpeed Cache - Unauthenticated Account Takeover via Debug Log Leak',
                    'severity'          => 'high',
                    'cvss'              => 7.5,
                    'affected_versions' => '< 6.5.0.1',
                    'fixed_in'          => '6.5.0.1',
                    'description'       => 'Sensitive session cookie leakage into public debug logs leading to unauthorized account takeover.'
                ]
            ],
            'wp-file-manager' => [
                [
                    'cve_id'            => 'CVE-2020-25213',
                    'title'             => 'WP File Manager - Unauthenticated Remote Code Execution',
                    'severity'          => 'critical',
                    'cvss'              => 9.8,
                    'affected_versions' => '< 6.9',
                    'fixed_in'          => '6.9',
                    'description'       => 'Bundled elFinder connector accessible without authentication allowing arbitrary PHP file upload and execution.'
                ]
            ],
            'duplicator' => [
                [
                    'cve_id'            => 'CVE-2020-11738',
                    'title'             => 'Duplicator - Unauthenticated Arbitrary File Download',
                    'severity'          => 'high',
                    'cvss'              => 7.5,
                    'affected_versions' => '< 1.3.28',
                    'fixed_in'          => '1.3.28',
                    'description'       => 'Path traversal in duplicator_download AJAX hook allowing unauthenticated download of wp-config.php.'
                ]
            ]
        ];
    }

    /**
     * Curated database of known WordPress Theme CVE advisories.
     */
    public static function get_known_theme_vulnerabilities() {
        return [
            'astra' => [
                [
                    'cve_id'            => 'CVE-2023-38515',
                    'title'             => 'Astra Theme - Reflected Cross-Site Scripting',
                    'severity'          => 'medium',
                    'cvss'              => 6.1,
                    'affected_versions' => '< 4.1.8',
                    'fixed_in'          => '4.1.8',
                    'description'       => 'Reflected XSS in customizer preview styling handlers allowing script injection.'
                ]
            ],
            'oceanwp' => [
                [
                    'cve_id'            => 'CVE-2022-4463',
                    'title'             => 'OceanWP - Authenticated Cross-Site Scripting',
                    'severity'          => 'medium',
                    'cvss'              => 5.4,
                    'affected_versions' => '< 3.4.0',
                    'fixed_in'          => '3.4.0',
                    'description'       => 'Improper sanitization of user-supplied custom typography and layout settings.'
                ]
            ],
            'enfold' => [
                [
                    'cve_id'            => 'CVE-2022-29450',
                    'title'             => 'Enfold Theme - Unauthenticated Stored XSS',
                    'severity'          => 'high',
                    'cvss'              => 7.2,
                    'affected_versions' => '< 5.0',
                    'fixed_in'          => '5.0',
                    'description'       => 'Stored XSS vulnerability via contact form and comment builder handlers.'
                ]
            ],
            'avada' => [
                [
                    'cve_id'            => 'CVE-2021-24430',
                    'title'             => 'Avada Theme - Authenticated Arbitrary File Deletion',
                    'severity'          => 'high',
                    'cvss'              => 7.7,
                    'affected_versions' => '< 7.4.2',
                    'fixed_in'          => '7.4.2',
                    'description'       => 'Path traversal flaw in reset options handler allowing arbitrary file deletion on the web server.'
                ]
            ],
            'divi' => [
                [
                    'cve_id'            => 'CVE-2020-20988',
                    'title'             => 'Divi Theme - Authenticated Remote Code Execution',
                    'severity'          => 'critical',
                    'cvss'              => 9.1,
                    'affected_versions' => '< 4.5.3',
                    'fixed_in'          => '4.5.3',
                    'description'       => 'Divi Builder custom code module deserialization flaw enabling authenticated code execution.'
                ]
            ]
        ];
    }
}
