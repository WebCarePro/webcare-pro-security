<?php
namespace WebCareProScanner\WordPress;

use WebCareProScanner\Findings\Finding;
use WebCareProScanner\Malware\HeuristicEngine;
use WebCareProScanner\Filesystem\PathValidator;
use WebCareProScanner\Remediation\RemediationManager;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * PersistenceScanner
 *
 * Comprehensive Self-Healing & Multi-Persistence Malware Hunter for WordPress:
 * 1. Must-Use Plugins (mu-plugins) AST Token Analysis & Stealth Loaders
 * 2. Standard & Rogue PHP Drop-Ins in wp-content/ (db.php, object-cache.php, etc.)
 * 3. Database Autoloaded Malicious Payloads, Transients & EtherHiding Anchors
 * 4. Orphan & Rogue Scheduled wp-cron Tasks
 * 5. Resurrection Sentinel: Detects when remediated files are re-created by hidden loops
 * 6. 1-Click Surgical Neutralization & Safety Rollback Vault
 */
class PersistenceScanner {

    private $heuristic_engine;

    // Standard recognized WordPress drop-in files
    private $recognized_dropins = [
        'advanced-cache.php'   => 'Advanced caching engine',
        'object-cache.php'     => 'External object cache',
        'db.php'               => 'Custom database class',
        'db-error.php'         => 'Custom database error template',
        'sunrise.php'          => 'Multisite domain mapping',
        'blog-deleted.php'     => 'Custom blog deleted template',
        'blog-inactive.php'    => 'Custom blog inactive template',
        'blog-suspended.php'   => 'Custom blog suspended template',
        'maintenance.php'      => 'Custom maintenance page',
        'php-error.php'        => 'Custom PHP error template',
        'fatal-error-handler.php' => 'Fatal error handler',
        'index.php'            => 'Directory browsing placeholder',
    ];

    public function __construct() {
        $this->heuristic_engine = new HeuristicEngine();
    }

    /**
     * Calculate Shannon Entropy on a string to identify encrypted/obfuscated binary payloads.
     *
     * @param string $string
     * @return float
     */
    public static function calculate_shannon_entropy(string $string): float {
        $len = strlen($string);
        if ($len === 0) {
            return 0.0;
        }
        $freq = count_chars($string, 1);
        $entropy = 0.0;
        foreach ($freq as $count) {
            $p = $count / $len;
            $entropy -= $p * log($p, 2);
        }
        return $entropy;
    }

    /**
     * Inspect persistence locations during standard background/manual scans.
     * Returns standard Finding objects for the scanner findings table.
     *
     * @param string $scan_id
     * @return Finding[]
     */
    public function scan($scan_id) {
        $findings = [];
        $audit = $this->audit_full();

        // 1. Convert MU-Plugin issues to Findings
        foreach ($audit['mu_plugins'] as $mu) {
            if ($mu['status'] === 'malicious') {
                $findings[] = new Finding([
                    'engine'      => 'wordpress-persistence',
                    'type'        => 'malicious_mu_plugin',
                    'severity'    => 'critical',
                    'confidence'  => 95,
                    'file_path'   => $mu['path'],
                    'description' => sprintf(
                        /* translators: 1: filename, 2: threat summary */
                        __('Malicious Must-Use (MU) plugin detected: %1$s. %2$s', 'webcare-pro-security'),
                        $mu['filename'],
                        $mu['threat_summary']
                    ),
                    'evidence'    => $mu['evidence'] ?? ('File: ' . $mu['filename']),
                    'code_snippet'=> $mu['snippet'] ?? null,
                ]);
            } elseif ($mu['status'] === 'warning') {
                $findings[] = new Finding([
                    'engine'      => 'wordpress-persistence',
                    'type'        => 'mu_plugin_warning',
                    'severity'    => 'medium',
                    'confidence'  => 85,
                    'file_path'   => $mu['path'],
                    'description' => sprintf(
                        /* translators: %s: filename */
                        __('Must-Use plugin "%s" contains suspicious code or hidden includes.', 'webcare-pro-security'),
                        $mu['filename']
                    ),
                    'evidence'    => $mu['threat_summary'],
                ]);
            }
        }

        // 2. Convert Drop-In issues to Findings
        foreach ($audit['dropins'] as $drop) {
            if ($drop['is_unexpected']) {
                $findings[] = new Finding([
                    'engine'      => 'wordpress-persistence',
                    'type'        => 'unexpected_wp_content_file',
                    'severity'    => 'high',
                    'confidence'  => 90,
                    'file_path'   => $drop['path'],
                    'description' => sprintf(
                        /* translators: %s: filename */
                        __('Unexpected PHP file directly in wp-content/ root: "%s". Common webshell or malware drop location.', 'webcare-pro-security'),
                        $drop['filename']
                    ),
                    'evidence'    => 'File: ' . $drop['filename'],
                ]);
            } elseif ($drop['status'] === 'malicious') {
                $findings[] = new Finding([
                    'engine'      => 'wordpress-persistence',
                    'type'        => 'malicious_dropin',
                    'severity'    => 'critical',
                    'confidence'  => 95,
                    'file_path'   => $drop['path'],
                    'description' => sprintf(
                        /* translators: 1: filename, 2: threat summary */
                        __('Malicious PHP drop-in detected: %1$s. %2$s', 'webcare-pro-security'),
                        $drop['filename'],
                        $drop['threat_summary']
                    ),
                    'evidence'    => $drop['evidence'] ?? ('Drop-in: ' . $drop['filename']),
                    'code_snippet'=> $drop['snippet'] ?? null,
                ]);
            } elseif ($drop['status'] === 'unauthorized') {
                $findings[] = new Finding([
                    'engine'      => 'wordpress-persistence',
                    'type'        => 'unauthorized_dropin',
                    'severity'    => 'medium',
                    'confidence'  => 85,
                    'file_path'   => $drop['path'],
                    'description' => sprintf(
                        /* translators: %s: filename */
                        __('Drop-in file "%s" is active, but no matching caching/database plugin was detected in active plugins.', 'webcare-pro-security'),
                        $drop['filename']
                    ),
                    'evidence'    => 'Drop-in: ' . $drop['filename'],
                ]);
            }
        }

        // 3. Convert Autoload & Transient Database Anchors to Findings
        foreach ($audit['autoload_options'] as $opt) {
            $findings[] = new Finding([
                'engine'      => 'database-persistence',
                'type'        => 'db_autoload_malware_anchor',
                'severity'    => $opt['severity'] ?? 'critical',
                'confidence'  => 95,
                'file_path'   => 'wp_options:' . $opt['option_name'],
                'description' => sprintf(
                    /* translators: 1: option name, 2: reason */
                    __('Database persistence anchor in autoloaded option "%1$s": %2$s', 'webcare-pro-security'),
                    $opt['option_name'],
                    $opt['reason']
                ),
                'evidence'    => 'Option: ' . $opt['option_name'] . ' (Size: ' . $opt['size_formatted'] . ')',
                'code_snippet'=> $opt['snippet'] ?? null,
            ]);
        }

        // 4. Convert Rogue Cron Tasks to Findings
        foreach ($audit['cron_tasks'] as $cron) {
            if ($cron['severity'] === 'critical' || $cron['severity'] === 'high') {
                $findings[] = new Finding([
                    'engine'      => 'system-cron',
                    'type'        => 'malicious_cron_hook',
                    'severity'    => $cron['severity'],
                    'confidence'  => 90,
                    'file_path'   => 'cron:hook:' . $cron['hook'],
                    'description' => sprintf(
                        /* translators: 1: cron hook name, 2: reason */
                        __('Suspicious scheduled cron task "%1$s": %2$s', 'webcare-pro-security'),
                        $cron['hook'],
                        $cron['reason']
                    ),
                    'evidence'    => 'Hook: ' . $cron['hook'] . ' | Next run: ' . $cron['next_run_human'],
                ]);
            }
        }

        // 5. Convert Resurrection / Self-Healing Loops to Findings
        foreach ($audit['resurrections'] as $res) {
            $findings[] = new Finding([
                'engine'      => 'self-healing-loop',
                'type'        => 'self_healing_malware_resurrection',
                'severity'    => 'critical',
                'confidence'  => 99,
                'file_path'   => $res['file_path'],
                'description' => sprintf(
                    /* translators: 1: original action, 2: timeline */
                    __('Self-Healing Malware Loop Detected! File was previously neutralized via WebCare (%1$s), but was resurrected/re-injected %2$s.', 'webcare-pro-security'),
                    $res['original_action'],
                    $res['timeline_human']
                ),
                'evidence'    => sprintf(
                    'Neutralized: %s | Re-infected: %s (%s later)',
                    $res['remediated_at'],
                    $res['current_mtime_human'],
                    $res['diff_human']
                ),
            ]);
        }

        // 6. Convert Rogue Server Pre-Loaders to Findings
        foreach ($audit['server_preloaders'] as $pre) {
            if ($pre['severity'] === 'critical' || $pre['severity'] === 'high') {
                $findings[] = new Finding([
                    'engine'      => 'server-preloader',
                    'type'        => 'rogue_server_preloader',
                    'severity'    => $pre['severity'],
                    'confidence'  => 95,
                    'file_path'   => $pre['target_file'],
                    'description' => $pre['description'],
                    'evidence'    => 'Directive: ' . $pre['directive'],
                ]);
            }
        }

        return $findings;
    }

    /**
     * Deep Audit of all Persistence Vectors.
     * Returns a rich, structured payload for live dashboard cards, forensic inspection, and 1-click remediation.
     *
     * @return array
     */
    public function audit_full(): array {
        $mu_plugins = $this->audit_mu_plugins();
        $dropins = $this->audit_dropins();
        $autoload_options = $this->audit_database_autoload();
        $cron_tasks = $this->audit_cron_tasks();
        $resurrections = $this->audit_resurrections();
        $server_preloaders = $this->audit_server_preloaders();
        $system_crons = $this->audit_system_crons();

        $insecure_mu = 0;
        foreach ($mu_plugins as $m) {
            if ($m['status'] === 'malicious' || $m['status'] === 'warning') {
                $insecure_mu++;
            }
        }

        $insecure_dropins = 0;
        foreach ($dropins as $d) {
            if ($d['status'] === 'malicious' || $d['status'] === 'unauthorized' || $d['is_unexpected']) {
                $insecure_dropins++;
            }
        }

        $insecure_crons = 0;
        foreach ($cron_tasks as $c) {
            if ($c['severity'] === 'critical' || $c['severity'] === 'high') {
                $insecure_crons++;
            }
        }

        $insecure_preloaders = count(array_filter($server_preloaders, fn($p) => $p['severity'] === 'critical' || $p['severity'] === 'high'));

        $total_threats = $insecure_mu + $insecure_dropins + count($autoload_options) + $insecure_crons + count($resurrections) + $insecure_preloaders;

        return [
            'success'                 => true,
            'is_healthy'              => ($total_threats === 0),
            'total_threats'           => $total_threats,
            'kpis' => [
                'mu_plugins_count'    => count($mu_plugins),
                'mu_threats_count'    => $insecure_mu,
                'dropins_count'       => count($dropins),
                'dropin_threats_count'=> $insecure_dropins,
                'autoload_threats'    => count($autoload_options),
                'cron_threats_count'  => $insecure_crons,
                'resurrections_count' => count($resurrections),
                'preloader_threats'   => $insecure_preloaders,
            ],
            'mu_plugins'              => $mu_plugins,
            'dropins'                 => $dropins,
            'autoload_options'        => $autoload_options,
            'cron_tasks'              => $cron_tasks,
            'resurrections'           => $resurrections,
            'server_preloaders'       => $server_preloaders,
            'system_crons'            => $system_crons,
        ];
    }

    /**
     * Vector 6: Audit Server-Level Pre-Loader Directives (auto_prepend_file, .user.ini, .htaccess)
     *
     * @return array
     */
    public function audit_server_preloaders(): array {
        $findings = [];

        // 1. auto_prepend_file & auto_append_file from INI
        $auto_prepend = ini_get('auto_prepend_file');
        if (!empty($auto_prepend)) {
            $norm = wp_normalize_path($auto_prepend);
            // Verify if official security tool or baseline
            $verification = class_exists('\\WebCareProScanner\\SupplyChain\\SbomSentinelEngine')
                ? \WebCareProScanner\SupplyChain\SbomSentinelEngine::verify_prepend_target($auto_prepend)
                : ['is_recognized' => false, 'is_trusted' => false, 'provider' => '', 'label' => '', 'risk_level' => 'high'];

            $is_webcare = str_contains($norm, 'micro-waf-compiled.php') || str_contains($norm, 'webcare-pro-security');
            $is_trusted = $is_webcare || !empty($verification['is_trusted']);
            $exists = file_exists($auto_prepend);

            $findings[] = [
                'type'        => 'ini_auto_prepend',
                'directive'   => 'auto_prepend_file',
                'target_file' => $auto_prepend,
                'is_webcare'      => $is_webcare,
                'is_trusted'  => $is_trusted,
                'provider'    => $verification['provider'] ?? '',
                'file_exists' => $exists,
                'severity'    => $is_trusted ? 'clean' : ($exists ? 'critical' : 'high'),
                'description' => $is_trusted
                    ? (!empty($verification['description']) ? $verification['description'] : __('Legitimate security pre-loader engine active.', 'webcare-pro-security'))
                    : ($exists
                        ? sprintf(
                            /* translators: %s: target file path */
                            __('Unknown PHP pre-loader active in auto_prepend_file: "%s". This file runs before any WordPress code boots.', 'webcare-pro-security'),
                            $auto_prepend
                        )
                        : sprintf(
                            /* translators: %s: target file path */
                            __('auto_prepend_file references a missing file: "%s".', 'webcare-pro-security'),
                            $auto_prepend
                        )),
            ];
        }

        $auto_append = ini_get('auto_append_file');
        if (!empty($auto_append)) {
            $exists = file_exists($auto_append);
            $findings[] = [
                'type'        => 'ini_auto_append',
                'directive'   => 'auto_append_file',
                'target_file' => $auto_append,
                'is_webcare'      => false,
                'file_exists' => $exists,
                'severity'    => 'critical',
                'description' => sprintf(
                    /* translators: %s: target file path */
                    __('Stealth post-execution pre-loader configured in auto_append_file: "%s". Executes after all WordPress scripts terminate.', 'webcare-pro-security'),
                    $auto_append
                ),
            ];
        }

        // 2. Scan root .user.ini for rogue preloaders
        $user_ini = ABSPATH . '.user.ini';
        if (file_exists($user_ini)) {
            $content = @file_get_contents($user_ini) ?: '';
            if (preg_match_all('/^\s*(auto_prepend_file|auto_append_file)\s*=\s*["\']?([^"\'\r\n]+)/m', $content, $matches, PREG_SET_ORDER)) {
                foreach ($matches as $m) {
                    $directive = $m[1];
                    $target = trim($m[2]);
                    $norm = wp_normalize_path($target);
                    $is_webcare = str_contains($norm, 'micro-waf-compiled.php') || str_contains($norm, 'webcare-pro-security');

                    $verification = class_exists('\\WebCareProScanner\\SupplyChain\\SbomSentinelEngine')
                        ? \WebCareProScanner\SupplyChain\SbomSentinelEngine::verify_prepend_target($target)
                        : ['is_recognized' => false, 'is_trusted' => false, 'provider' => '', 'label' => ''];

                    $is_trusted = ($directive === 'auto_prepend_file') && ($is_webcare || !empty($verification['is_trusted']));

                    if (!$is_trusted) {
                        $findings[] = [
                            'type'        => 'user_ini_preloader',
                            'directive'   => '.user.ini:' . $directive,
                            'target_file' => $target,
                            'is_webcare'      => false,
                            'file_exists' => file_exists($target),
                            'severity'    => 'critical',
                            'description' => sprintf(
                                /* translators: 1: directive, 2: target */
                                __('Root .user.ini declares rogue preloader "%1$s = %2$s".', 'webcare-pro-security'),
                                $directive,
                                $target
                            ),
                        ];
                    }
                }
            }
        }

        // 3. Scan root .htaccess for php_value auto_prepend_file
        $htaccess = ABSPATH . '.htaccess';
        if (file_exists($htaccess)) {
            $content = @file_get_contents($htaccess) ?: '';
            if (preg_match_all('/^\s*php_value\s+(auto_prepend_file|auto_append_file)\s+["\']?([^"\'\r\n]+)/mi', $content, $matches, PREG_SET_ORDER)) {
                foreach ($matches as $m) {
                    $directive = $m[1];
                    $target = trim($m[2]);
                    $norm = wp_normalize_path($target);
                    $is_webcare = str_contains($norm, 'micro-waf-compiled.php') || str_contains($norm, 'webcare-pro-security');

                    $verification = class_exists('\\WebCareProScanner\\SupplyChain\\SbomSentinelEngine')
                        ? \WebCareProScanner\SupplyChain\SbomSentinelEngine::verify_prepend_target($target)
                        : ['is_recognized' => false, 'is_trusted' => false, 'provider' => '', 'label' => ''];

                    $is_trusted = ($directive === 'auto_prepend_file') && ($is_webcare || !empty($verification['is_trusted']));

                    if (!$is_trusted) {
                        $findings[] = [
                            'type'        => 'htaccess_preloader',
                            'directive'   => '.htaccess:php_value ' . $directive,
                            'target_file' => $target,
                            'is_webcare'      => false,
                            'file_exists' => file_exists($target),
                            'severity'    => 'critical',
                            'description' => sprintf(
                                /* translators: 1: directive, 2: target */
                                __('Root .htaccess injects preloader directive "php_value %1$s %2$s".', 'webcare-pro-security'),
                                $directive,
                                $target
                            ),
                        ];
                    }
                }
            }
        }

        return $findings;
    }

    /**
     * Vector 7: Audit Server System Crontab Accessibility
     *
     * @return array
     */
    public function audit_system_crons(): array {
        $paths = [
            '/etc/crontab',
            '/etc/cron.d',
            '/etc/cron.daily',
            '/etc/cron.hourly',
            '/var/spool/cron/crontabs',
            '/var/spool/cron',
        ];

        $checked = [];
        $accessible = false;

        foreach ($paths as $p) {
            if (@file_exists($p)) {
                $is_readable = @is_readable($p);
                if ($is_readable) {
                    $accessible = true;
                }
                $checked[] = [
                    'path'        => $p,
                    'exists'      => true,
                    'readable'    => $is_readable,
                ];
            }
        }

        return [
            'is_accessible'   => $accessible,
            'is_restricted'   => !$accessible,
            'notice'          => $accessible
                ? __('Server-level system crontab paths detected and accessible for inspection.', 'webcare-pro-security')
                : __('Server-level system crontab paths (/var/spool/cron, /etc/crontab) are restricted by hosting isolation (open_basedir/chroot). WordPress-level scheduled tasks are actively audited.', 'webcare-pro-security'),
            'checked_paths'   => $checked,
        ];
    }

    /**
     * Vector 1: Audit Must-Use Plugins (mu-plugins)
     */
    private function audit_mu_plugins(): array {
        $results = [];
        $mu_dir = defined('WPMU_PLUGIN_DIR') ? WPMU_PLUGIN_DIR : WP_CONTENT_DIR . '/mu-plugins';

        if (!is_dir($mu_dir)) {
            return $results;
        }

        $files = [];
        try {
            $mu_iter = new \RecursiveIteratorIterator(
                new \RecursiveDirectoryIterator($mu_dir, \FilesystemIterator::SKIP_DOTS),
                \RecursiveIteratorIterator::SELF_FIRST,
                \RecursiveIteratorIterator::CATCH_GET_CHILD
            );
            foreach ($mu_iter as $mu_item) {
                if ($mu_item->isFile() && strtolower($mu_item->getExtension()) === 'php') {
                    $files[] = $mu_item->getPathname();
                }
            }
        } catch (\Throwable $e) {
            $files = glob($mu_dir . '/*.php') ?: [];
        }
        foreach ($files as $file) {
            $filename = basename($file);
            $content = @file_get_contents($file) ?: '';
            $fsize = @filesize($file) ?: 0;
            $mtime = @filemtime($file) ?: 0;

            $status = 'clean';
            $threat_summary = '';
            $evidence = '';
            $snippet = '';

            // Run AST token analysis
            $ast = $this->analyze_php_tokens($content, $file);
            if ($ast['is_malicious']) {
                $status = 'malicious';
                $threat_summary = $ast['reason'];
                $snippet = $ast['snippet'];
                $evidence = $ast['evidence'];
            } elseif ($ast['is_suspicious']) {
                $status = 'warning';
                $threat_summary = $ast['reason'];
                $snippet = $ast['snippet'];
                $evidence = $ast['evidence'];
            } else {
                // Run heuristic detector as second pass
                $heuristics = $this->heuristic_engine->scan_file($file, 'audit_' . time());
                if (!empty($heuristics)) {
                    $first = reset($heuristics);
                    $status = 'malicious';
                    $threat_summary = $first->description;
                    $snippet = $first->code_snippet;
                    $evidence = $first->evidence;
                }
            }

            $results[] = [
                'filename'       => $filename,
                'path'           => wp_normalize_path($file),
                'relative_path'  => 'wp-content/mu-plugins/' . $filename,
                'size'           => $fsize,
                'size_formatted' => size_format($fsize),
                'mtime'          => $mtime,
                'modified_human' => human_time_diff($mtime, time()) . ' ago',
                'status'         => $status,
                'threat_summary' => $threat_summary ?: __('Legitimate Must-Use plugin.', 'webcare-pro-security'),
                'snippet'        => $snippet,
                'evidence'       => $evidence,
            ];
        }

        return $results;
    }

    /**
     * Vector 2: Audit Drop-Ins & wp-content Loose Files
     */
    private function audit_dropins(): array {
        $results = [];
        $wp_content_files = glob(WP_CONTENT_DIR . '/*.php') ?: [];

        // Check active caching & db plugins to verify legitimate drop-in ownership
        $active_plugins = (array) get_option('active_plugins', []);
        $active_plugins_str = strtolower(implode(' ', $active_plugins));

        $has_caching_plugin = (
            strpos($active_plugins_str, 'redis') !== false ||
            strpos($active_plugins_str, 'memcached') !== false ||
            strpos($active_plugins_str, 'litespeed') !== false ||
            strpos($active_plugins_str, 'w3-total-cache') !== false ||
            strpos($active_plugins_str, 'wp-super-cache') !== false ||
            strpos($active_plugins_str, 'wp-rocket') !== false ||
            strpos($active_plugins_str, 'speedycache') !== false ||
            strpos($active_plugins_str, 'wp-fastest-cache') !== false ||
            strpos($active_plugins_str, 'wp-optimize') !== false ||
            strpos($active_plugins_str, 'breeze') !== false ||
            strpos($active_plugins_str, 'hummingbird') !== false ||
            strpos($active_plugins_str, 'sg-cachepress') !== false ||
            strpos($active_plugins_str, 'nitropack') !== false ||
            strpos($active_plugins_str, 'flying-press') !== false ||
            strpos($active_plugins_str, 'cache-enabler') !== false ||
            strpos($active_plugins_str, 'autoptimize') !== false ||
            strpos($active_plugins_str, 'powered-cache') !== false
        );

        $has_db_plugin = (
            strpos($active_plugins_str, 'query-monitor') !== false ||
            strpos($active_plugins_str, 'ludicrousdb') !== false ||
            strpos($active_plugins_str, 'hyperdb') !== false
        );

        foreach ($wp_content_files as $file) {
            $filename = basename($file);
            $content = @file_get_contents($file) ?: '';
            $fsize = @filesize($file) ?: 0;
            $mtime = @filemtime($file) ?: 0;

            $is_recognized = isset($this->recognized_dropins[$filename]);
            $is_unexpected = !$is_recognized;
            $status = 'clean';
            $threat_summary = '';
            $snippet = '';
            $evidence = '';

            if ($is_unexpected) {
                $status = 'malicious';
                $threat_summary = __('Unexpected PHP file located in wp-content root. High probability of webshell drop.', 'webcare-pro-security');
            }

            // AST Token Check
            $ast = $this->analyze_php_tokens($content, $file);
            if ($ast['is_malicious']) {
                $status = 'malicious';
                $threat_summary = $ast['reason'];
                $snippet = $ast['snippet'];
                $evidence = $ast['evidence'];
            } elseif ($ast['is_suspicious'] && $status !== 'malicious') {
                $status = 'warning';
                $threat_summary = $ast['reason'];
                $snippet = $ast['snippet'];
                $evidence = $ast['evidence'];
            } else {
                // Run full HeuristicEngine on drop-ins (catches backdoored object-cache.php / db.php / advanced-cache.php even when a caching plugin is active!)
                $drop_heuristics = $this->heuristic_engine->scan_file($file, 'dropin_' . time());
                if (!empty($drop_heuristics)) {
                    $first_drop = reset($drop_heuristics);
                    $status = 'malicious';
                    $threat_summary = $first_drop->description;
                    $snippet = $first_drop->code_snippet;
                    $evidence = $first_drop->evidence;
                }
            }

            // Verify legitimate plugin backing
            if ($status === 'clean') {
                if ($filename === 'object-cache.php' && !$has_caching_plugin) {
                    $status = 'unauthorized';
                    $threat_summary = __('object-cache.php is present, but no active Redis, Memcached, or Object Cache plugin is enabled.', 'webcare-pro-security');
                } elseif ($filename === 'db.php' && !$has_db_plugin) {
                    $status = 'unauthorized';
                    $threat_summary = __('db.php drop-in is present, but Query Monitor, LudicrousDB, or HyperDB are not enabled in active plugins.', 'webcare-pro-security');
                } elseif ($filename === 'advanced-cache.php' && !defined('WP_CACHE') && !$has_caching_plugin) {
                    $status = 'unauthorized';
                    $threat_summary = __('advanced-cache.php is present, but WP_CACHE is not enabled in wp-config.php and no caching plugin is active.', 'webcare-pro-security');
                }
            }

            $results[] = [
                'filename'       => $filename,
                'path'           => wp_normalize_path($file),
                'relative_path'  => 'wp-content/' . $filename,
                'purpose'        => $this->recognized_dropins[$filename] ?? __('Unrecognized loose file', 'webcare-pro-security'),
                'is_unexpected'  => $is_unexpected,
                'size'           => $fsize,
                'size_formatted' => size_format($fsize),
                'mtime'          => $mtime,
                'modified_human' => human_time_diff($mtime, time()) . ' ago',
                'status'         => $status,
                'threat_summary' => $threat_summary ?: __('Standard WordPress Drop-in.', 'webcare-pro-security'),
                'snippet'        => $snippet,
                'evidence'       => $evidence,
            ];
        }

        return $results;
    }

    /**
     * Vector 3: Audit Database Autoload & Transient Persistence Anchors
     */
    private function audit_database_autoload(): array {
        global $wpdb;
        $flagged = [];

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $rows = $wpdb->get_results(
            "SELECT option_id, option_name, option_value FROM {$wpdb->options} 
             WHERE autoload IN ('yes', 'on', 'true') 
                OR option_name LIKE '_transient_%' 
                OR option_name LIKE '_site_transient_%'
             ORDER BY option_id DESC 
             LIMIT 400",
            ARRAY_A
        ) ?: [];

        foreach ($rows as $row) {
            $name = $row['option_name'];
            $val = $row['option_value'];
            if (empty($val) || !is_string($val)) {
                continue;
            }

            // Skip WebCare's own internal analysis, FIM diffs, and security caches
            if (strpos($name, 'webcare_') !== false || strpos($name, 'webcareproscan_') !== false) {
                continue;
            }

            $len = strlen($val);
            if ($len < 20) {
                continue;
            }

            $reason = '';
            $severity = 'critical';
            $snippet = '';

            // 1. Direct PHP executable tags inside database option
            $is_rss_feed_transient = (str_starts_with($name, '_site_transient_feed_') || str_starts_with($name, '_transient_feed_'));
            if (preg_match('/<\?(php|=|xml)/i', $val)) {
                $reason = __('Embedded PHP executable tag found inside database option value.', 'webcare-pro-security');
                $snippet = substr($val, 0, 160);
            }
            // 2. Evaluators inside option string (require PHP syntax inside call to avoid prose false positives)
            elseif (
                !$is_rss_feed_transient &&
                preg_match('/(?<![a-zA-Z0-9_])@?(?:eval|assert|create_function|passthru|system)\s*\(\s*(?:\$|[\'"]|@?[a-z_][a-z0-9_]*\s*\()/i', $val)
            ) {
                $reason = __('Direct dynamic evaluator execution construct detected in option value.', 'webcare-pro-security');
                $snippet = substr($val, 0, 160);
            }
            // 3. EtherHiding / Balada Web3 IPFS C2 injection patterns
            elseif (preg_match('/(eth\.limo|ipfs\.io|cloudflare-ipfs\.com|rentry\.co|pastebin\.com\/raw\/|bsc-dataseed)/i', $val)) {
                $reason = __('EtherHiding or decentralized Web3/IPFS C2 payload URL detected in database option.', 'webcare-pro-security');
                $snippet = substr($val, 0, 160);
            }
            // 4. Obfuscated Base64 script injection in options
            elseif (preg_match('/<script[^>]*>[\s\S]*?(eval\s*\(|atob\s*\(|String\.fromCharCode)[\s\S]*?<\/script>/i', $val)) {
                $reason = __('Obfuscated client-side JavaScript execution payload stored in database option.', 'webcare-pro-security');
                $snippet = substr($val, 0, 160);
            }
            // 5. High-Entropy Base64 / Hex blob check on large string fields
            elseif ($len > 180 && !is_serialized($val)) {
                // Check if continuous block of alphanumeric characters has high entropy
                if (preg_match('/[a-zA-Z0-9\/+=]{150,}/', $val, $matches)) {
                    $entropy = self::calculate_shannon_entropy($matches[0]);
                    if ($entropy > 5.3) {
                        $decoded = @base64_decode($matches[0], true);
                        if ($decoded && (strpos($decoded, '<?php') !== false || strpos($decoded, 'eval') !== false || strpos($decoded, 'curl') !== false)) {
                            /* translators: %.2f: entropy score */
                            $reason = sprintf(__('High-entropy base64 blob (Entropy: %.2f) decoding to executable PHP/C2 instructions.', 'webcare-pro-security'), $entropy);
                            $snippet = substr($matches[0], 0, 120) . '...';
                        }
                    }
                }
            }

            if (!empty($reason)) {
                $flagged[] = [
                    'option_id'      => (int) $row['option_id'],
                    'option_name'    => $name,
                    'size'           => $len,
                    'size_formatted' => size_format($len),
                    'severity'       => $severity,
                    'reason'         => $reason,
                    'snippet'        => $snippet,
                ];
            }
        }

        return $flagged;
    }

    /**
     * Vector 4: Audit Scheduled wp-cron Tasks
     */
    private function audit_cron_tasks(): array {
        $flagged = [];
        $cron_array = _get_cron_array();
        if (empty($cron_array) || !is_array($cron_array)) {
            return $flagged;
        }

        global $wp_filter;

        $core_safe_hooks = [
            'wp_version_check',
            'wp_update_plugins',
            'wp_update_themes',
            'recovery_mode_clean_expired_keys',
            'wp_scheduled_delete',
            'delete_expired_transients',
            'wp_privacy_delete_old_export_files',
            'wp_https_detection',
            'wp_site_health_scheduled_check',
            'webcareproscan_scheduled_scan_event',
        ];

        $now = time();

        foreach ($cron_array as $timestamp => $hooks) {
            if (!is_array($hooks)) {
                continue;
            }

            foreach ($hooks as $hook => $schedules) {
                if (in_array($hook, $core_safe_hooks, true) || str_starts_with($hook, 'webcareproscan_') || str_starts_with($hook, 'webcare_')) {
                    continue;
                }

                $has_callback = isset($wp_filter[$hook]);
                $severity = 'info';
                $reason = '';

                // 1. Orphan cron hook: Scheduled to run repeatedly, but callback function no longer exists
                if (!$has_callback) {
                    // Check if hook name looks generated or suspicious (hex hash or random chars)
                    if (preg_match('/^[a-f0-9]{16,64}$/i', $hook) || preg_match('/(temp|cache_check|update_sys|wpc_[0-9a-f]{6,})/i', $hook)) {
                        $severity = 'high';
                        $reason = __('Orphaned cron hook with suspicious generated name and no active callback function in WordPress.', 'webcare-pro-security');
                    }
                } else {
                    // 2. Hook exists - inspect callback functions for rogue closures or file locations
                    $callbacks = $wp_filter[$hook]->callbacks ?? [];
                    foreach ($callbacks as $priority => $handlers) {
                        foreach ($handlers as $id => $handler) {
                            $func = $handler['function'] ?? null;
                            if ($func instanceof \Closure) {
                                try {
                                    $ref = new \ReflectionFunction($func);
                                    $file = wp_normalize_path($ref->getFileName() ?: '');
                                    if (strpos($file, '/wp-content/uploads/') !== false || strpos($file, '/tmp/') !== false) {
                                        $severity = 'critical';
                                        /* translators: %s: file basename */
                                        $reason = sprintf(__('Cron hook executes an anonymous Closure defined inside uploads or temp directory: %s', 'webcare-pro-security'), basename($file));
                                    }
                                } catch (\Throwable $e) {
                                    // pass
                                }
                            }
                        }
                    }
                }

                if (!empty($reason)) {
                    $next_run_sec = max(0, $timestamp - $now);
                    $flagged[] = [
                        'hook'            => $hook,
                        'timestamp'       => $timestamp,
                        'next_run_human'  => human_time_diff($now, $timestamp) . ($timestamp > $now ? ' from now' : ' ago'),
                        'has_callback'    => $has_callback,
                        'severity'        => $severity,
                        'reason'          => $reason,
                    ];
                }
            }
        }

        return $flagged;
    }

    /**
     * Vector 5: Audit Resurrection Sentinel (Self-Healing Loop Tracker)
     */
    private function audit_resurrections(): array {
        $resurrections = [];
        $backups = get_option('webcareproscan_remediation_backups', []);
        if (empty($backups) || !is_array($backups)) {
            return $resurrections;
        }

        $now = time();

        foreach ($backups as $id => $record) {
            $orig_path = $record['original_path'] ?? '';
            $created_at = $record['created_at'] ?? '';
            $action_type = $record['action_type'] ?? '';

            if (empty($orig_path) || empty($created_at)) {
                continue;
            }

            $created_time = strtotime($created_at);
            if (!$created_time || ($now - $created_time) > (14 * DAY_IN_SECONDS)) {
                // Monitor for 14 days after remediation
                continue;
            }

            if (file_exists($orig_path)) {
                $mtime = @filemtime($orig_path);

                // If file was stripped or restored, but was edited again AFTER remediation timestamp
                if ($mtime && $mtime > ($created_time + 10)) {
                    $content = @file_get_contents($orig_path) ?: '';
                    $ast = $this->analyze_php_tokens($content, $orig_path);

                    if ($ast['is_malicious'] || $ast['is_suspicious']) {
                        $diff = $mtime - $created_time;
                        $resurrections[] = [
                            'backup_id'            => $id,
                            'file_path'            => wp_normalize_path($orig_path),
                            'filename'             => basename($orig_path),
                            'original_action'      => $action_type,
                            'remediated_at'        => $created_at,
                            'current_mtime'        => $mtime,
                            'current_mtime_human'  => gmdate('Y-m-d H:i:s', $mtime) . ' UTC',
                            'timeline_human'       => human_time_diff($created_time, $mtime) . ' after cleanup',
                            'diff_human'           => human_time_diff($created_time, $mtime),
                            'threat_reason'        => $ast['reason'],
                        ];
                    }
                }
            }
        }

        return $resurrections;
    }

    /**
     * Parse PHP tokens to detect malicious constructs, stealth include wrappers, and backdoors.
     *
     * @param string $content
     * @param string $file_path
     * @return array
     */
    private function analyze_php_tokens(string $content, string $file_path = ''): array {
        $result = [
            'is_malicious'  => false,
            'is_suspicious' => false,
            'reason'        => '',
            'snippet'       => '',
            'evidence'      => '',
        ];

        if (empty($content) || !function_exists('token_get_all')) {
            return $result;
        }

        try {
            $tokens = @token_get_all($content);
        } catch (\ParseError $e) {
            return $result;
        }

        $dangerous_funcs = ['eval', 'assert', 'passthru', 'system', 'exec', 'shell_exec', 'proc_open', 'popen'];
        $obfuscation_funcs = ['base64_decode', 'gzinflate', 'gzuncompress', 'str_rot13', 'convert_uudecode'];

        $count = count($tokens);
        for ($i = 0; $i < $count; $i++) {
            $tok = $tokens[$i];

            if (is_array($tok)) {
                $type = $tok[0];
                $str = strtolower($tok[1]);

                // 1. eval / assert execution
                if ($type === T_EVAL || ($type === T_STRING && in_array($str, $dangerous_funcs, true))) {
                    // Check next non-whitespace tokens to see what is evaluated
                    $next_code = '';
                    for ($j = $i + 1; $j < min($count, $i + 15); $j++) {
                        $ntok = $tokens[$j];
                        $next_code .= is_array($ntok) ? $ntok[1] : $ntok;
                    }

                    if (preg_match('/(base64_decode|gzinflate|gzuncompress|\$_POST|\$_GET|\$_REQUEST|\$GLOBALS)/i', $next_code)) {
                        $result['is_malicious'] = true;
                        /* translators: %s: function name */
                        $result['reason'] = sprintf(__('Critical Backdoor: %s executing dynamic encoded payload.', 'webcare-pro-security'), strtoupper($str));
                        $result['snippet'] = substr($tok[1] . $next_code, 0, 140);
                        $result['evidence'] = "Construct: {$tok[1]}";
                        return $result;
                    }

                    $result['is_suspicious'] = true;
                    /* translators: %s: function name */
                    $result['reason'] = sprintf(__('Suspicious dynamic function call: %s()', 'webcare-pro-security'), $tok[1]);
                    $result['snippet'] = substr($tok[1] . $next_code, 0, 100);
                }

                // 2. Stealth include/require pointing to uploads, cache, or temp
                if ($type === T_INCLUDE || $type === T_INCLUDE_ONCE || $type === T_REQUIRE || $type === T_REQUIRE_ONCE) {
                    $next_code = '';
                    for ($j = $i + 1; $j < min($count, $i + 25); $j++) {
                        $ntok = $tokens[$j];
                        $ntext = is_array($ntok) ? $ntok[1] : $ntok;
                        if ($ntext === ';' || (is_array($ntok) && $ntok[0] === T_CLOSE_TAG)) {
                            break;
                        }
                        $next_code .= $ntext;
                    }

                    // Exempt official Redis object-cache and caching drop-ins including legitimate plugin .php loaders
                    $is_redis_dropin = (strpos($file_path, 'object-cache.php') !== false && preg_match('/\b(predis|redis)\b/i', $next_code));
                    $is_cache_dropin_plugin = (
                        strpos($file_path, 'advanced-cache.php') !== false &&
                        preg_match('/\.php[\'"]/i', $next_code) &&
                        !preg_match('#(?:[/\\\\\'"](?:uploads|tmp)[/\\\\]|\.(?:ico|png|jpe?g|gif|webp|txt|css|woff2?)[\'"])#i', $next_code)
                    );

                    if (
                        !$is_redis_dropin &&
                        !$is_cache_dropin_plugin &&
                        preg_match('#(?:[/\\\\\'"](?:uploads|wp-content/cache|cache|tmp)[/\\\\]|\.(?:ico|png|jpe?g|gif|webp|txt|css|woff2?)[\'"])#i', $next_code)
                    ) {
                        $result['is_malicious'] = true;
                        $result['reason'] = __('Stealth Loader: Drop-in or MU-plugin includes a hidden payload from uploads, cache, or disguised image file.', 'webcare-pro-security');
                        $result['snippet'] = substr($tok[1] . ' ' . $next_code, 0, 140);
                        $result['evidence'] = "Stealth include: {$next_code}";
                        return $result;
                    }
                }

                // 3. EtherHiding / Web3 Decentralized C2 pattern
                if ($type === T_CONSTANT_ENCAPSED_STRING) {
                    if (preg_match('/(eth\.limo|ipfs\.io|cloudflare-ipfs\.com|rentry\.co|pastebin\.com\/raw\/|bsc-dataseed)/i', $tok[1])) {
                        $result['is_malicious'] = true;
                        $result['reason'] = __('EtherHiding / Decentralized Web3 C2 endpoint detected in string literal.', 'webcare-pro-security');
                        $result['snippet'] = substr($tok[1], 0, 120);
                        $result['evidence'] = "C2 URL: {$tok[1]}";
                        return $result;
                    }
                }

                // 4. Early HTTP header or WordPress redirect in drop-in/mu-plugin
                if ($type === T_STRING && in_array($str, ['header', 'wp_redirect', 'wp_safe_redirect'], true)) {
                    $next_code = '';
                    for ($j = $i + 1; $j < min($count, $i + 35); $j++) {
                        $ntok = $tokens[$j];
                        $next_code .= is_array($ntok) ? $ntok[1] : $ntok;
                    }

                    if ($str === 'header' && preg_match('/location\s*:/i', $next_code)) {
                        $home_host = wp_parse_url(home_url(), PHP_URL_HOST) ?: '';
                        if (preg_match('/location\s*:\s*https?:\/\/([^\/\'"\s]+)/i', $next_code, $loc_m)) {
                            $dest_host = strtolower($loc_m[1]);
                            if ($home_host && $dest_host !== strtolower($home_host) && !str_ends_with($dest_host, '.' . strtolower($home_host))) {
                                $result['is_malicious'] = true;
                                /* translators: %s: external redirect hostname */
                                $result['reason'] = sprintf(__('Early External HTTP Redirect: Drop-in or MU-plugin executes pre-WordPress Location header redirect to external host "%s".', 'webcare-pro-security'), $dest_host);
                                $result['snippet'] = substr($tok[1] . $next_code, 0, 160);
                                $result['evidence'] = "Hostile early redirect: {$tok[1]}{$next_code}";
                                return $result;
                            }
                        } elseif (preg_match('/location\s*:\s*[\'"]?\s*\.\s*\$/i', $next_code) || preg_match('/(\$_GET|\$_POST|\$_REQUEST|\$url|\$dest|\$target)/i', $next_code)) {
                            $result['is_suspicious'] = true;
                            $result['reason'] = __('Dynamic HTTP Location header redirect found in pre-WordPress boot stage.', 'webcare-pro-security');
                            $result['snippet'] = substr($tok[1] . $next_code, 0, 140);
                            $result['evidence'] = "Dynamic redirect: {$tok[1]}{$next_code}";
                        }
                    } elseif (($str === 'wp_redirect' || $str === 'wp_safe_redirect') && !empty($file_path)) {
                        $base_name = basename($file_path);
                        if (in_array($base_name, ['db.php', 'object-cache.php', 'advanced-cache.php', 'sunrise.php'], true)) {
                            $result['is_malicious'] = true;
                            /* translators: %s: drop-in filename */
                            $result['reason'] = sprintf(__('Early wp_redirect() inside drop-in "%s". Drop-ins run before WordPress routing and must never execute redirects.', 'webcare-pro-security'), $base_name);
                            $result['snippet'] = substr($tok[1] . $next_code, 0, 140);
                            $result['evidence'] = "Early wp_redirect in drop-in: {$base_name}";
                            return $result;
                        }
                    }
                }

                // 5. Output Buffer Redirect Injectors (ob_start with HTML replacement)
                if ($type === T_STRING && $str === 'ob_start') {
                    $next_code = '';
                    for ($j = $i + 1; $j < min($count, $i + 45); $j++) {
                        $ntok = $tokens[$j];
                        $next_code .= is_array($ntok) ? $ntok[1] : $ntok;
                    }
                    if (preg_match('/(?:http-equiv=["\']?refresh|location\.replace|location\.href\s*=|window\.location)/i', $content)) {
                        $result['is_malicious'] = true;
                        $result['reason'] = __('Output Buffer Redirect Injector: ob_start() paired with DOM or meta-refresh redirect manipulation.', 'webcare-pro-security');
                        $result['snippet'] = substr($tok[1] . $next_code, 0, 150);
                        $result['evidence'] = "ob_start redirect injection in {$file_path}";
                        return $result;
                    }
                }

                // 6. Remote C2 Redirect Fetchers (wp_remote_get / curl_exec feeding Location redirect)
                if ($type === T_STRING && in_array($str, ['curl_exec', 'wp_remote_get', 'file_get_contents'], true)) {
                    if (preg_match('/(?:header\s*\(\s*[\'"]Location:|\bwp_redirect\s*\()/i', $content)) {
                        $base_name = basename($file_path);
                        if (in_array($base_name, ['db.php', 'object-cache.php', 'advanced-cache.php', 'sunrise.php'], true) || str_contains($file_path, 'mu-plugins')) {
                            $result['is_malicious'] = true;
                            /* translators: %s: filename */
                            $result['reason'] = sprintf(__('Remote C2 Redirect Fetcher: Remote HTTP request paired with Location header redirect in %s.', 'webcare-pro-security'), $base_name ?: 'file');
                            $result['snippet'] = substr($tok[1], 0, 120);
                            $result['evidence'] = "Remote C2 redirect fetcher in {$base_name}";
                            return $result;
                        }
                    }
                }
            }
        }

        return $result;
    }

    /**
     * Surgically neutralize an individual persistence finding.
     *
     * @param string $type dropin | mu_plugin | autoload_option | cron_hook | resurrected_file
     * @param string $id Target identifier (path, option_name, or cron hook name)
     * @return array
     */
    public function neutralize_item(string $type, string $id): array {
        switch ($type) {
            case 'dropin':
            case 'mu_plugin':
            case 'resurrected_file':
                $file = realpath($id);
                if (!$file && file_exists(ABSPATH . ltrim($id, '/\\'))) {
                    $file = realpath(ABSPATH . ltrim($id, '/\\'));
                }
                if (!$file || !file_exists($file)) {
                    return ['success' => false, 'message' => __('Target file not found on disk.', 'webcare-pro-security')];
                }
                if (!PathValidator::is_inside_root($file, ABSPATH)) {
                    return ['success' => false, 'message' => __('Security restriction: File is outside WordPress root.', 'webcare-pro-security')];
                }

                // Generate encrypted vault backup first
                $remediation = new RemediationManager();
                $backup = $remediation->create_file_backup($file, 'persistence_neutralize');
                if (!$backup['success']) {
                    return ['success' => false, 'message' => __('Could not generate encrypted safety backup. Neutralization aborted.', 'webcare-pro-security')];
                }

                // Delete or rename file
                $quarantined_name = $file . '.webcare-quarantined-' . time();
                global $wp_filesystem;
                $moved = false;
                if ($wp_filesystem) {
                    $moved = $wp_filesystem->move($file, $quarantined_name);
                }
                if ($moved || wp_delete_file($file)) {
                    return [
                        'success'   => true,
                        'message'   => sprintf(
                            /* translators: %s: file basename */
                            __('Persistence anchor "%s" neutralized. Encrypted safety backup created.', 'webcare-pro-security'),
                            basename($file)
                        ),
                        'backup_id' => $backup['backup_id'],
                    ];
                }
                return ['success' => false, 'message' => __('Filesystem write permission denied. Could not remove file.', 'webcare-pro-security')];

            case 'autoload_option':
                global $wpdb;
                $opt_name = sanitize_text_field($id);

                // Prevent accidental neutralization of critical core configuration options
                $protected_options = ['siteurl', 'home', 'active_plugins', 'admin_email', 'blogname', 'blogdescription', 'users_can_register', 'default_role', 'template', 'stylesheet'];
                if (in_array(strtolower($opt_name), $protected_options, true)) {
                    return ['success' => false, 'message' => __('Action Blocked: Critical system configuration options cannot be deleted.', 'webcare-pro-security')];
                }

                // Backup option value to backups option
                $val = get_option($opt_name);
                $backups = get_option('webcareproscan_remediation_backups', []);
                $b_id = 'opt_' . substr(md5($opt_name . time()), 0, 12);
                $backups[$b_id] = [
                    'id'            => $b_id,
                    'original_path' => 'wp_options:' . $opt_name,
                    'backup_file'   => $opt_name,
                    'action_type'   => 'db_autoload_cleaned',
                    'created_at'    => current_time('mysql'),
                    'size'          => is_string($val) ? strlen($val) : 0,
                    'backup_data'   => $val,
                ];
                update_option('webcareproscan_remediation_backups', $backups, false);

                delete_option($opt_name);
                if (is_multisite()) {
                    if (current_user_can('manage_network_options')) {
                        delete_site_option($opt_name);
                    }
                } else {
                    delete_site_option($opt_name);
                }

                return [
                    'success'   => true,
                    /* translators: %s: option name */
                    'message'   => sprintf(__('Malicious autoload option "%s" deleted from database. Snapshot saved to vault.', 'webcare-pro-security'), $opt_name),
                    'backup_id' => $b_id,
                ];

            case 'cron_hook':
                $hook = sanitize_text_field($id);
                $cleared = wp_clear_scheduled_hook($hook);
                return [
                    'success' => true,
                    /* translators: %s: cron hook name */
                    'message' => sprintf(__('Scheduled cron hook "%s" cleared from WordPress crontab.', 'webcare-pro-security'), $hook),
                    'cleared' => $cleared,
                ];

            default:
                return ['success' => false, 'message' => __('Invalid persistence item type.', 'webcare-pro-security')];
        }
    }

    /**
     * 1-Click Mass Neutralization: Purges all confirmed malicious persistence anchors.
     *
     * @return array
     */
    public function neutralize_all(): array {
        $audit = $this->audit_full();
        $cleaned = 0;
        $failed = 0;
        $details = [];

        // 1. Drop-ins
        foreach ($audit['dropins'] as $d) {
            if ($d['status'] === 'malicious' || $d['is_unexpected']) {
                $res = $this->neutralize_item('dropin', $d['path']);
                if ($res['success']) {
                    $cleaned++;
                    $details[] = "Purged Drop-in: {$d['filename']}";
                } else {
                    $failed++;
                }
            }
        }

        // 2. MU-Plugins
        foreach ($audit['mu_plugins'] as $m) {
            if ($m['status'] === 'malicious') {
                $res = $this->neutralize_item('mu_plugin', $m['path']);
                if ($res['success']) {
                    $cleaned++;
                    $details[] = "Purged MU-Plugin: {$m['filename']}";
                } else {
                    $failed++;
                }
            }
        }

        // 3. Database Autoload Options
        foreach ($audit['autoload_options'] as $o) {
            $res = $this->neutralize_item('autoload_option', $o['option_name']);
            if ($res['success']) {
                $cleaned++;
                $details[] = "Deleted Option: {$o['option_name']}";
            } else {
                $failed++;
            }
        }

        // 4. Rogue Cron Hooks
        foreach ($audit['cron_tasks'] as $c) {
            if ($c['severity'] === 'critical' || $c['severity'] === 'high') {
                $res = $this->neutralize_item('cron_hook', $c['hook']);
                if ($res['success']) {
                    $cleaned++;
                    $details[] = "Cleared Cron: {$c['hook']}";
                } else {
                    $failed++;
                }
            }
        }

        // 5. Resurrected Files
        foreach ($audit['resurrections'] as $r) {
            $res = $this->neutralize_item('resurrected_file', $r['file_path']);
            if ($res['success']) {
                $cleaned++;
                $details[] = "Re-neutralized: {$r['filename']}";
            } else {
                $failed++;
            }
        }

        return [
            'success'        => true,
            'message'        => sprintf(
                /* translators: 1: number of cleaned anchors, 2: number of failed anchors */
                __('Persistence Neutralization Complete: Cleaned %1$d anchors, %2$d failed. Safety snapshots saved to vault.', 'webcare-pro-security'),
                $cleaned,
                $failed
            ),
            'cleaned_count'  => $cleaned,
            'failed_count'   => $failed,
            'details'        => $details,
        ];
    }
}
