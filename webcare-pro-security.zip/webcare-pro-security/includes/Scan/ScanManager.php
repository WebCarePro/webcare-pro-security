<?php
namespace WebCareProScanner\Scan;

use WebCareProScanner\Resource\ResourceMonitor;
use WebCareProScanner\Filesystem\DirectoryWalker;
use WebCareProScanner\Filesystem\FileScanner;
use WebCareProScanner\Findings\FindingsRepository;

if (!defined('ABSPATH')) {
    exit;
}

class ScanManager {

    private DirectoryWalker $directory_walker;
    private FileScanner $file_scanner;
    private FindingsRepository $repository;

    public function __construct() {
        $this->directory_walker = new DirectoryWalker();
        $this->file_scanner = new FileScanner();
        $this->repository = new FindingsRepository();
    }

    /**
     * Run a streaming batch of the filesystem scan with hierarchical cursor,
     * memory guardrails, abort safety, and bulk persistence.
     *
     * @param string|int $scan_id
     * @param int $batch_size
     * @return array
     */
    public function run_filesystem_batch($scan_id, $batch_size = 25): array {
        $scan_id_str = (string) $scan_id;
        $state = ScanState::load($scan_id_str);
        $monitor = new ResourceMonitor(70, 18, 'balanced'); // 70% dynamic memory safety ceiling

        // Abort requested check before starting chunk
        if ($state->is_abort_requested()) {
            $state->set_status('aborted');
            $state->save();
            return $this->build_response($state, [], 0, true);
        }

        if ($state->get_status() === 'queued') {
            $state->set_status('running');
        }

        $cursor = $state->get_cursor();
        $current_phase = $cursor['phase'] ?? 'plugins';
        $adaptive_batch_size = $monitor->get_adaptive_batch_size($batch_size);

        if ($current_phase === 'cache_executables') {
            $cache_scan_meta = [];
            $cached_files = $cursor['cache_files'] ?? null;
            if ($cached_files === null) {
                $cached_files = $this->directory_walker->scan_cache_dirs_for_executables(ABSPATH, 5, $cache_scan_meta);
                $state->set_meta_key('cache_scan_truncated', !empty($cache_scan_meta['truncated']));
                $state->set_meta_key('cache_scan_errors', max(0, (int) ($cache_scan_meta['traversal_errors'] ?? 0)));
                $state->set_meta_key('cache_scan_depth_limited', max(0, (int) ($cache_scan_meta['depth_limited'] ?? 0)));
                $state->set_meta_key('cache_scan_complete', !empty($cache_scan_meta['complete']));
            }
            $cached_files = is_array($cached_files) ? array_slice($cached_files, 0, 500) : [];
            $offset = (int) ($cursor['cache_offset'] ?? 0);
            $files = array_slice($cached_files, $offset, $adaptive_batch_size);
            $new_offset = $offset + count($files);
            $exhausted = $new_offset >= count($cached_files);
            $new_cursor = [
                'phase'        => 'cache_executables',
                'cache_files'  => $cached_files,
                'cache_offset' => $new_offset,
            ];
        } else {
            $root_dir = $this->phase_root($current_phase);
            $batch = $this->directory_walker->get_batch($root_dir, $cursor, $adaptive_batch_size);
            $files = $batch['files'] ?? [];
            $new_cursor = $batch['cursor'] ?? $cursor;
            $exhausted = !empty($batch['exhausted']);
        }

        $findings = [];
        $file_rows = [];
        $issue_rows = [];
        $files_scanned = 0;

        foreach ($files as $file) {
            // Guardrail checks & adaptive breathing before each file
            if ($monitor->throttle_and_check() || $state->is_abort_requested()) {
                break;
            }

            $file_findings = $this->file_scanner->scan_file($file, $scan_id_str);
            $has_unignored_threat = false;

            if (!empty($file_findings)) {
                foreach ($file_findings as $finding) {
                    $item = method_exists($finding, 'to_array') ? $finding->to_array() : (array) $finding;
                    if (class_exists('\\WebCareProScanner\\Findings\\WhitelistManager')) {
                        $matched_rule = \WebCareProScanner\Findings\WhitelistManager::match_finding($item);
                        if ($matched_rule !== null) {
                            $item['status'] = 'ignored';
                            $item['whitelisted'] = true;
                            $item['whitelist_rule'] = $matched_rule;
                        } else {
                            $item['status'] = 'open';
                            $has_unignored_threat = true;
                        }
                    } else {
                        $item['status'] = 'open';
                        $has_unignored_threat = true;
                    }
                    $findings[] = $item;
                    $issue_rows[] = $item;
                }
            }

            $file_rows[] = [
                'file_path' => $file,
                'file_size' => @filesize($file) ?: 0,
                'status'    => $has_unignored_threat ? 'threat' : 'clean',
            ];

            $files_scanned++;

            // Memory hygiene: force GC every 10 files
            if ($files_scanned % 10 === 0) {
                if (function_exists('gc_collect_cycles')) {
                    gc_collect_cycles();
                }
            }
        }

        // Multi-row bulk persistence
        if (!empty($file_rows)) {
            $this->repository->persist_batch((int) $scan_id, $file_rows, $issue_rows);
        }

        // Update progress & cursor
        $open_issues_count = 0;
        foreach ($issue_rows as $ir) {
            if (($ir['status'] ?? 'open') === 'open') {
                $open_issues_count++;
            }
        }

        $state->increment_scanned($files_scanned);
        $state->add_issues($open_issues_count);
        $state->set_cursor($new_cursor);
        $state->set_memory_peak(memory_get_peak_usage(true));

        // Phase progression
        $is_complete = false;
        if ($exhausted && $files_scanned < $batch_size) {
            $next_phase = $this->next_phase($current_phase);
            if ($next_phase === null) {
                $state->set_status('completed');
                $is_complete = true;
            } else {
                $state->set_cursor([
                    'phase'     => $next_phase,
                    'dir_stack' => [],
                    'last_file' => null,
                ]);
            }
        }

        $state->save();

        return $this->build_response($state, $findings, $files_scanned, $is_complete);
    }

    private function build_response(ScanState $state, array $findings, int $files_scanned, bool $is_complete): array {
        $scan_meta = $state->get_meta();
        $cache_scan_truncated = !empty($scan_meta['cache_scan_truncated']);
        $cache_scan_errors = max(0, (int) ($scan_meta['cache_scan_errors'] ?? 0));
        $cache_scan_depth_limited = max(0, (int) ($scan_meta['cache_scan_depth_limited'] ?? 0));
        $cache_scan_complete = array_key_exists('cache_scan_complete', $scan_meta)
            ? (bool) $scan_meta['cache_scan_complete']
            : null;
        $warnings = [];

        if ($cache_scan_truncated) {
            $warnings[] = __('Cache executable inspection reached its resource budget; some cache entries may remain unscanned.', 'webcare-pro-security');
        }
        if ($cache_scan_errors > 0) {
            $warnings[] = __('Cache executable inspection could not access one or more cache directories; findings may be incomplete.', 'webcare-pro-security');
        }
        if ($cache_scan_depth_limited > 0) {
            $warnings[] = __('Cache executable inspection excluded one or more subdirectories at the recursion-depth limit; those subtrees were not inspected.', 'webcare-pro-security');
        }

        return [
            'scan_id'                => $state->get_scan_id(),
            'engine'                 => 'filesystem',
            'status'                 => $state->get_status(),
            'cursor'                 => $state->get_cursor(),
            'files_scanned_in_batch' => $files_scanned,
            'total_scanned_so_far'   => $state->get_offset(),
            'is_complete'            => $is_complete,
            'memory_peak_mb'         => round($state->get_memory_peak() / 1024 / 1024, 2),
            'cache_scan_truncated'   => $cache_scan_truncated,
            'cache_scan_errors'      => $cache_scan_errors,
            'cache_scan_depth_limited' => $cache_scan_depth_limited,
            'cache_scan_complete'    => $cache_scan_complete,
            'warnings'               => $warnings,
            'findings'               => array_map(function ($f) {
                return method_exists($f, 'to_array') ? $f->to_array() : (array) $f;
            }, $findings),
        ];
    }

    private function phase_root(string $phase): string {
        $uploads = wp_upload_dir();
        return match ($phase) {
            'plugins'           => WP_PLUGIN_DIR,
            'themes'            => get_theme_root(),
            'mu'                => WPMU_PLUGIN_DIR,
            'uploads'           => untrailingslashit($uploads['basedir']),
            'core'              => ABSPATH,
            'cache_executables' => WP_CONTENT_DIR,
            default             => ABSPATH,
        };
    }

    private function next_phase(string $current): ?string {
        $order = ['plugins', 'themes', 'mu', 'core', 'uploads', 'cache_executables'];
        $idx = array_search($current, $order, true);
        if ($idx === false || !isset($order[$idx + 1])) {
            return null;
        }
        return $order[$idx + 1];
    }
}
